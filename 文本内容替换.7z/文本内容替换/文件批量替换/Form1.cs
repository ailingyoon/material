﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace 文件批量替换
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<string> listExt = new List<string>();
        private void button1_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                txtpath.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        int n = 0;
        void GoProcFile(string path)
        {
            int i = 0;
            foreach (var f in Directory.GetFiles(path))
            {
                string czm = Path.GetExtension(f);
                if (CheckExt(czm))
                {
                    string str = string.Empty;
                    if(radioButtonLine.Checked==true)
                    {
                       str= ReplaceFileByLine(f);
                    }
                    else
                    {
                       str= ReadFileByALL(f);
                    }
                    int ck = str.IndexOf(tbxOld.Text);
                    if(ck>=0)
                    {
                        str = str.Replace(tbxOld.Text, tbxNew.Text);
                        StreamWriter sw = new StreamWriter(f, false);
                        sw.WriteLine(str);
                        sw.Close();

                        n++;
                        listViewLog.Items.Add(new ListViewItem(f, i));
                        i = i + 1;
                    }

                }
            }
            //如果处理子文件夹
            if (checkBox1.Checked)
            {
                foreach (var dir in Directory.GetDirectories(path))
                {
                    GoProcFile(dir);
                }

            }
        }

        /// <summary>
        /// 检查扩展名
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        private bool CheckExt(string s)
        {
            foreach(string str in listExt)
            {
                if(str.ToUpper()==s.ToUpper())
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 一行一行读
        /// </summary>
        /// <param name="f"></param>
        private string ReplaceFileByLine(string f)
        {
            
            StringBuilder sb = new StringBuilder();
            //StreamReader sr = new StreamReader(f, Encoding.GetEncoding("gb2312"));
            StreamReader sr = new StreamReader(f, Encoding.GetEncoding("UTF8"));
            string sCon = sr.ReadLine();
            while (!string.IsNullOrEmpty(sCon))
            {
                sb.Append(sr.ReadLine());
            }
            sr.Close();
            return sb.ToString();
        }


        /// <summary>
        /// 一次全读出来
        /// </summary>
        /// <param name="s"></param>
        private string ReadFileByALL(string s)
        {
            StreamReader sr = new StreamReader(s, false);
           string str = sr.ReadToEnd();
            sr.Close();
            return str;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //txtExt.Text = ".cs;.xml;.csproj;.config;.aspx;.htm;.html;.js;.css;.csproj;";
            txtExt.Text = ".sql;.txt;";
            foreach (string ext in txtExt.Text.Split(';'))
            {
                if(!string.IsNullOrEmpty(ext))
                {
                    listExt.Add(ext);
                }
            }
        }


        private void btnStart_Click(object sender, EventArgs e)
        {
            if (listExt.Count == 0)
            {
                errorProvider1.SetError(txtExt, "不为空,格式:.txt;.htm;.html;");
                return;
            }

            //验证
            errorProvider1.SetError(txtpath, "");
            if (txtpath.Text.Length == 0)
            {
                errorProvider1.SetError(txtpath, "不为空!");
                txtpath.Focus();
                return;
            }

            errorProvider1.SetError(txtExt, "");
            if (txtpath.Text.Length == 0)
            {
                errorProvider1.SetError(txtExt, "不为空!");
                txtExt.Focus();
                return;
            }

            errorProvider1.SetError(tbxOld, "");
            if (tbxOld.Text.Length == 0)
            {
                errorProvider1.SetError(tbxOld, "不为空!");
                tbxOld.Focus();
                return;
            }

            n = 0;
            //处理文件
            GoProcFile(txtpath.Text);
            tbxMsg.Text = "完成!共处理" + n + "个文件!";
            n = 0;
        }
    }
}
