﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
   public class clsClaimAttribute
    {

public String Delete_CLAIMATTRIBUTE = @"
USE @QNXT
select ca.* into BDU_TEMP.EDI.[@EXCEL_ca]
from @QNXT..CLAIMATTRIBUTE ca (nolock) JOIN [BDU_TEMP].[EDI].[@EXCEL] tem 
on ca.claimid=tem.claimid and ca.attributeid=tem.attributeid 

delete ca
from @QNXT..CLAIMATTRIBUTE ca (nolock) JOIN [BDU_TEMP].[EDI].[@EXCEL] tem 
on ca.claimid=tem.claimid and ca.attributeid=tem.attributeid
 
select  ca.attributeid, Count(1) 
from @QNXT..CLAIMATTRIBUTE ca (nolock) JOIN [BDU_TEMP].[EDI].[@EXCEL] tem 
on ca.claimid=tem.claimid and ca.attributeid=tem.attributeid
group by  ca.attributeid
";


public String NotAdjust_Settlement = @"
USE @QNXT
delete from  [BDU_Temp].[EDI].[@EXCEL] where claimid='' OR claimid is null ;
delete from  [BDU_Temp].[EDI].[@EXCEL] where 
claimid in  ( 
SELECT s.claimid  From [BDU_Temp].[EDI].[@EXCEL] s  
left join @QNXT..claim c (nolock)
On s.claimid = c.claimid Where c.claimid Is Null)

--Claimattribute Insert

declare @attid varchar(15);
select @attid=attributeid from @QNXT..qattribute 
where [description] like 'Do not adjust - Settlement agreement%' 
 
declare @cid varchar(15)='WO' + substring('@WO', 10, 6) + '###';
/* if no term date in excel , then termdate = '2078-12-31'*/
Insert into  @QNXT..claimattribute
(claimid,attributeid,effdate,thevalue,termdate,createid,createdate,updateid,lastupdate)	
Select  distinct s.claimid 
, attributeid = @attid
, effdate =cast(s.effdate as date)
, thevalue = s.value
, termdate =cast('2078-12-31' as date)
, createid = @cid
, createdate = getdate ()
, updateid =@cid
, lastupdate = getdate ()
From @QNXT..claimattribute ca (nolock)
Right Join [BDU_Temp].[EDI].[@EXCEL] s 
On ca.claimid = s.claimid 
And  cast(ca.effdate as date) = cast(s.effdate as date)
And ca.attributeid =@attid 
Where ca.claimid Is Null 
 
select count(*) from  @QNXT..claimattribute
where attributeid = @attid
and updateid =@cid

 select ca.thevalue, tem.value , ca.effdate, ca.termdate
 FROM QNXT..claimattribute ca (NOLOCK)  join [BDU_TEMP].[EDI].[@EXCEL] AS tem
 ON ca.claimid = tem.claimid WHERE ca.attributeid = tem.attrid

";


        public string Add_Update_Attribute = @"
USE @QNXT 

print '----Any claims already with active Attributeid- CZ00069514 and matching data- Okay to remove from request';
declare @varAttrId varchar(15) ='CZ00069514';
SELECT ca.*   INTO  [BDU_TEMP].[EDI].[@EXCEL_ca1]
FROM  @QNXT..claimattribute ca (NOLOCK)
Inner join [BDU_TEMP].[EDI].[@EXCEL] AS s
ON ca.claimid =s.claimid
join  @QNXT..claim clm on clm.claimid = ca.claimid
WHERE ca.attributeid = @varAttrId  AND cast(ca.EFFDATE as date)=cast(clm.startdate as date)

delete ca
FROM  @QNXT..claimattribute ca (NOLOCK)
Inner join [BDU_TEMP].[EDI].[@EXCEL_ca1] AS s
ON ca.claimid =s.claimid and ca.attributeid =s.attributeid and  cast(ca.EFFDATE as date) = cast(s.EFFDATE  as date)

print '----BACKUP ALREADY EXISTING RECORDS ';
SELECT ca.* into [BDU_TEMP].[EDI].[@EXCEL_ca2]
FROM @QNXT..claimattribute ca (NOLOCK)
Inner join [BDU_TEMP].[EDI].[@EXCEL] AS s
ON ca.claimid = s.claimid
WHERE ca.attributeid = s.attrid ;
 
print  '----update existing  claimattribute'
declare @varID varchar(12)='WO'+substring('@WO',10,6)+'###';
Update ca
set  effdate =cast(s.effdate as date),
  thevalue= s.value,
  termdate= cast(s.termdate as date),
  createid = @varID,
  createdate = getdate(),
  updateid = @varID,
  lastupdate = getdate() 
FROM @QNXT..claimattribute ca (NOLOCK)
Inner join [BDU_TEMP].[EDI].[@EXCEL] AS s
ON ca.claimid = s.claimid WHERE ca.attributeid = s.attrid

print '----INSERT NEW claimattribute'
declare @varID2 varchar(12)='WO'+substring('@WO',10,6)+'###';
INSERT into  @QNXT..claimattribute  (claimid, attributeid, effdate, thevalue, termdate, createid, createdate, updateid, lastupdate)
SELECT DISTINCT   s.claimid,  s.attrid ,  cast(s.effdate as date),  s.Value ,
  cast(s.termdate as date),@varID2,getdate(),@varID2, getdate()
FROM [BDU_TEMP].[EDI].[@EXCEL] AS s
JOIN @QNXT..CLAIM CLM ON CLM.claimid = s.claimid
LEFT  JOIN @QNXT..claimattribute as ca on ca.claimid = s.claimid 
AND  cast(ca.effdate as date)=cast(s.effectivedate as date)
AND ca.attributeid = s.attrid
WHERE ca.claimid IS NULL 

 select ca.thevalue, tem.value , ca.effdate, ca.termdate
 FROM QNXT..claimattribute ca (NOLOCK)  join [BDU_TEMP].[EDI].[@EXCEL] AS tem
 ON ca.claimid = tem.claimid WHERE ca.attributeid = tem.attrid
";

    }
}
