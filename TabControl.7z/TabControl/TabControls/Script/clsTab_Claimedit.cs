﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
    public class clsTab_Claimedit
    {

 public string Deny915_Reason97_RevcodeNotLike= @"
 ----------------------------------------------------------------------
PRINT 'INSERT deny 915 claim EDITs where claimdetail.revcode <> ‘08%’'
-----------------------------------------------------------------------
SELECT ce.* INTO BDU_Temp.EDI.[@EXCEL_ce]
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
JOIN @QNXT..claimdetail cd (NOLOCK)
ON cd.claimid = tem.claimid
WHERE ce.ruleid IN ( '915')
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND cd.REVCODE NOT like '@REVCODE%' AND ce.reason<>'@reasonID' 

UPDATE ce SET status = 'DENY', clearby = 'PHX\EDIUser', cleardate = getdate(), state = 'MANUAL', reason = '@reasonID'
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem  ON tem.claimid = ce.claimid
JOIN @QNXT..claim clm (NOLOCK)  ON clm.claimid = tem.claimid
JOIN @QNXT..claimdetail cd (NOLOCK) ON cd.claimid = tem.claimid
WHERE ce.ruleid IN ( '915')
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND cd.REVCODE NOT like '@REVCODE%' AND ce.reason<>'@reasonID' 


Select a.* into #CTE1 
from @QNXT..claimdetail a join BDU_Temp.EDI.[@EXCEL] tem
on a.claimid= tem.claimid  where a.REVCODE not like '@REVCODE%' 

INSERT INTO @QNXT..claimedit (claimid, claimline, ruleid, status, reason, state)
SELECT DISTINCT tem.claimid, tem.claimline, '915', 'DENY', '@reasonID', 'MANUAL' 
FROM @QNXT..claimedit ce (NOLOCK)
RIGHT JOIN #CTE1 tem 
ON tem.claimid = ce.claimid
AND tem.claimline = ce.claimline
AND ruleid IN ('915') AND ce.status = 'DENY' AND ce.reason = '@reasonID'
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE ce.claimid IS NULL AND ce.claimline IS NULL
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND tem.claimline IS NOT NULL
";

  public string OKAY_PEND_and111 = @"
------------------------------------------------------
PRINT 'Claimedit to OKAY if PEND and 111'
------------------------------------------------------
SELECT ce.*
INTO BDU_TEMP.EDI.[@EXCEL_ce3]
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid  
WHERE  ce.ruleid IN ('111') AND ce.status='PEND'

UPDATE ce
SET status = 'OKAY',clearby = 'PHX\EDIUser',cleardate = GETDATE(), state = 'MANUAL'
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid  
WHERE  ce.ruleid IN ('111') AND ce.status='PEND'

SELECT status,ruleid, COUNT(*)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem 
ON tem.claimid = ce.claimid  
WHERE  ce.ruleid IN ('111') AND ce.status='OKAY'
GROUP BY status, ruleid
";

 public string OKAY_EDIT = @"
------------------------------------------------------
PRINT 'Claimedit to OKAY for several ruleid'
------------------------------------------------------
SELECT ce.*
INTO BDU_TEMP.EDI.[@EXCEL_ce3]
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid  
WHERE   ce.ruleid in (##)  

UPDATE ce
SET status = 'OKAY',clearby = 'PHX\EDIUser',cleardate = GETDATE(), state = 'MANUAL'
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid  
WHERE  ce.ruleid in (##)  

SELECT status,ruleid, COUNT(*)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem  ON tem.claimid = ce.claimid  
WHERE  ce.ruleid in (##)
GROUP BY status, ruleid
";

 public string InsertDeny915 = @"
--------------------------------------------------------------------------------
PRINT 'INSERT deny 915 claim EDITs'
--------------------------------------------------------------------------------
SELECT ce.* INTO BDU_Temp.EDI.[@EXCEL_ce]
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_Temp.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid AND tem.claimline = ce.claimline
JOIN @QNXT..claim clm (NOLOCK) ON clm.claimid = tem.claimid
WHERE ruleid IN ('915') AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

UPDATE ce 
SET status = 'DENY', clearby = 'PHX\EDIUser', cleardate = getdate(), state = 'MANUAL', reason = 'M119'
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_Temp.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid AND tem.claimline = ce.claimline
JOIN @QNXT..claim clm (NOLOCK) ON clm.claimid = tem.claimid
WHERE ruleid IN ('915') and clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

INSERT INTO @QNXT..claimedit(claimid, claimline, ruleid, status, reason, state)
SELECT distinct tem.claimid, tem.claimline,'915','DENY','M119', 'MANUAL' 
FROM @QNXT..claimedit ce (NOLOCK) right JOIN BDU_Temp.EDI.[@EXCEL] tem  ON tem.claimid = ce.claimid AND tem.claimline = ce.claimline
AND ruleid IN ('915') AND ce.status = 'DENY' AND ce.reason = 'M119'
JOIN @QNXT..claim clm (NOLOCK) ON clm.claimid = tem.claimid
WHERE ce.claimid IS NULL AND ce.claimline IS NULL and clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND tem.claimline IS NOT NULL

SELECT ce.status,ce.reason,COUNT(1)
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_Temp.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid AND tem.claimline = ce.claimline
JOIN @QNXT..claim clm (NOLOCK) ON clm.claimid = tem.claimid
WHERE ruleid IN ('915') AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
GROUP BY ce.status, ce.reason
";

 public string PEND913_claimline_0 = @"
----------------------------------------------------------------------------
PRINT 'Insert & update PEND edit 913 with claimline 0'
----------------------------------------------------------------------------
--Initial check
SELECT ce.status, COUNT(*)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem 
ON tem.claimid = ce.claimid
AND ce.ruleid IN ('913')
AND ce.claimline = '0'
GROUP BY ce.status

--Backup
SELECT ce.*
INTO BDU_TEMP.edi.[@EXCEL_ce]
FROM BDU_TEMP.edi.[@EXCEL] tem (NOLOCK) JOIN @QNXT..claim clm (NOLOCK)
ON tem.claimid = clm.claimid
JOIN @QNXT..claimedit ce (NOLOCK)  
ON clm.claimid = ce.claimid
AND ce.ruleid IN ('913') AND ce.claimline = '0' AND ce.status != 'PEND'

--Update
UPDATE ce SET status = 'PEND', state = 'MANUAL'
FROM BDU_TEMP.edi.[@EXCEL] tem (NOLOCK)
JOIN @QNXT..claim clm (NOLOCK) ON tem.claimid = clm.claimid
JOIN @QNXT..claimedit ce (NOLOCK) ON clm.claimid = ce.claimid
AND ce.ruleid IN ('913') AND ce.claimline = '0' AND ce.status != 'PEND'
 
--Insert 
INSERT INTO @QNXT..claimedit (claimid, claimline, status, ruleid, state)  
SELECT DISTINCT tem.ClaimID, '0','PEND', '913', 'MANUAL'  
FROM @QNXT..claimedit ce (NOLOCK)
RIGHT JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid
AND ce.ruleid IN ('913') AND ce.claimline = '0' WHERE ce.claimid IS NULL

--Count AFTER insert & update 
SELECT COUNT(1),ce.status 
FROM @QNXT..claimedit ce (NOLOCK)
RIGHT JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid
AND ce.ruleid IN ('913')
AND ce.claimline = '0'
GROUP BY ce.status
";
    }
}
