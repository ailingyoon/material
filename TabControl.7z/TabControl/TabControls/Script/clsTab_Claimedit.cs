﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
    public class clsTab_Claimedit
    {

 public string Update_primary_DSA= @"
---------------------------------------------------------------------
PRINT 'Update and insert primary reason FOR DSA'
---------------------------------------------------------------------
SELECT ce.*
INTO BDU_TEMP.edi.[@EXCEL_ce]
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid
JOIN @QNXT..claim clm (NOLOCK) ON clm.claimid = tem.claimid
WHERE ruleid IN ('915')
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

UPDATE ce
SET status = 'DENY', clearby = 'PHX\EDIUser', cleardate = GETDATE(), state = 'MANUAL', reason = 'DSA'
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.edi.[@EXCEL] tem  ON tem.claimid = ce.claimid
JOIN @QNXT..claim clm (NOLOCK) ON clm.claimid = tem.claimid
WHERE ruleid IN ('915')
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

INSERT INTO @QNXT..claimedit(claimid, claimline, ruleid, status, reason, state)
SELECT DISTINCT tem.claimid, 0,'915','DENY','DSA', 'MANUAL' 
FROM @QNXT..claimedit ce (NOLOCK) RIGHT JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid AND ruleid IN ('915')
AND ce.status = 'DENY'  AND ce.reason = 'DSA'
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE ce.claimid IS NULL
AND ce.claimline IS NULL
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
";


public string ClearAllEdit = @"
---------------------------------------------------------------------
PRINT 'Clear all edits'
---------------------------------------------------------------------
SELECT ce.*
INTO BDU_TEMP.edi.[@EXCEL_ce_1]
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem ON tem.claimid = ce.claimid

DELETE ce
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem ON tem.claimid = ce.claimid

SELECT ce.status, ce.ruleid, COUNT(*)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid
GROUP BY ce.status, ce.ruleid
";
public string ClearEdit_forPEND_913 = @"
---------------------------------------------------------------------
PRINT 'Clear   edits for PEND AND 913'
---------------------------------------------------------------------
SELECT ce.*
INTO BDU_TEMP.edi.[@EXCEL_ce_1]
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem ON tem.claimid = ce.claimid
WHERE ce.ruleid IN ( '913') AND ce.status = 'PEND'

DELETE ce
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem ON tem.claimid = ce.claimid
WHERE ce.ruleid IN ( '913') AND ce.status = 'PEND'

SELECT ce.status, ce.ruleid, COUNT(*)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid
WHERE ce.ruleid IN ( '913') AND ce.status = 'PEND'
GROUP BY ce.status, ce.ruleid
";

public string Deny915_Reason97_servcode_revcode = @"
 ----------------------------------------------------------------------
PRINT   'INSERT deny 915 claim EDITs  '
-----------------------------------------------------------------------
SELECT ce.*  INTO BDU_Temp.EDI.[@EXCEL_ce]
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
JOIN @QNXT..claimdetail cd (NOLOCK)
ON cd.claimid = tem.claimid
WHERE ce.ruleid IN ( '915')
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND cd.REVCODE NOT like '$$$' AND ce.reason<>'97' AND cd.servcode NOT IN (###)
 

UPDATE ce SET status = 'DENY', clearby = 'PHX\EDIUser', cleardate = getdate(), state = 'MANUAL', reason = '97'
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem  ON tem.claimid = ce.claimid
JOIN @QNXT..claim clm (NOLOCK)  ON clm.claimid = tem.claimid
JOIN @QNXT..claimdetail cd (NOLOCK) ON cd.claimid = tem.claimid
WHERE ce.ruleid IN ( '915')
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND cd.REVCODE NOT like '$$$' AND ce.reason<>'97' 


Select a.* into #CTE1 
from @QNXT..claimdetail a join BDU_Temp.EDI.[@EXCEL] tem
on a.claimid= tem.claimid  
where a.REVCODE not like '$$$' AND a.servcode NOT IN (###)

INSERT INTO @QNXT..claimedit (claimid, claimline, ruleid, status, reason, state)
SELECT DISTINCT tem.claimid, tem.claimline, '915', 'DENY', '97', 'MANUAL' 
FROM @QNXT..claimedit ce (NOLOCK)
RIGHT JOIN #CTE1 tem 
ON tem.claimid = ce.claimid
AND tem.claimline = ce.claimline
AND ruleid IN ('915') AND ce.status = 'DENY' AND ce.reason = '97'
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE ce.claimid IS NULL AND ce.claimline IS NULL  
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND tem.claimid IS NOT NULL  and  tem.claimline IS NOT NULL 
";


 public string Deny915_Reason97_RevcodeNotLike= @"
 ----------------------------------------------------------------------
PRINT 'INSERT deny 915 claim EDITs where claimdetail.revcode <> 08%'
-----------------------------------------------------------------------
SELECT ce.* INTO BDU_Temp.EDI.[@EXCEL_ce]
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
JOIN @QNXT..claimdetail cd (NOLOCK)
ON cd.claimid = tem.claimid
WHERE ce.ruleid IN ( '915')
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND cd.REVCODE NOT like '@REVCODE%' AND ce.reason<>'97' 

UPDATE ce SET status = 'DENY', clearby = 'PHX\EDIUser', cleardate = getdate(), state = 'MANUAL', reason = '97'
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem  ON tem.claimid = ce.claimid
JOIN @QNXT..claim clm (NOLOCK)  ON clm.claimid = tem.claimid
JOIN @QNXT..claimdetail cd (NOLOCK) ON cd.claimid = tem.claimid
WHERE ce.ruleid IN ( '915')
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND cd.REVCODE NOT like '@REVCODE%' AND ce.reason<>'97' 


Select a.* into #CTE1 
from @QNXT..claimdetail a join BDU_Temp.EDI.[@EXCEL] tem
on a.claimid= tem.claimid  where a.REVCODE not like '@REVCODE%' 

INSERT INTO @QNXT..claimedit (claimid, claimline, ruleid, status, reason, state)
SELECT DISTINCT tem.claimid, tem.claimline, '915', 'DENY', '97', 'MANUAL' 
FROM @QNXT..claimedit ce (NOLOCK)
RIGHT JOIN #CTE1 tem 
ON tem.claimid = ce.claimid
AND tem.claimline = ce.claimline
AND ruleid IN ('915') AND ce.status = 'DENY' AND ce.reason = '97'
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE ce.claimid IS NULL AND ce.claimline IS NULL  
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND tem.claimid IS NOT NULL AND tem.claimline IS NOT NULL
";

  public string OKAY_PEND_and111 = @"
------------------------------------------------------
PRINT 'Claimedit to OKAY if PEND and 111'
------------------------------------------------------
SELECT ce.*
INTO BDU_TEMP.EDI.[@EXCEL_ce2]
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid  
WHERE  ce.ruleid IN ('111') AND ce.status='PEND'

UPDATE ce
SET status = 'OKAY',clearby = 'PHX\EDIUser',cleardate = GETDATE(), state = 'MANUAL'
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid  
WHERE  ce.ruleid IN ('111') AND ce.status='PEND'

SELECT status,ruleid, COUNT(*)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem 
ON tem.claimid = ce.claimid  
WHERE  ce.ruleid IN ('111') AND ce.status='OKAY'
GROUP BY status, ruleid
";

public string H99_CLAIMS = @"
-----------------------------
PRINT 'EDITs Update'
-----------------------------
SELECT ce.* into BDU_Temp.EDI.[@EXCEL_ce1]
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem  ON tem.claimid = ce.claimid  AND  tem.claimline = ce.claimline 
AND ce.ruleid IN ('154','157','185','208','271','330','155')
AND (ce.status = [C154] OR ce.status = [C157] OR ce.status = [C185] OR ce.status = [C208] OR ce.status = [C271] OR ce.status = [C330] OR ce.status = [C155])

UPDATE ce SET ce.status = tem.direction, ce.clearby = 'PHX\EDIUser',ce.cleardate = getdate(), ce.state = 'MANUAL'
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_Temp.EDI.[@EXCEL] tem 
ON tem.claimid = ce.claimid  AND tem.claimline = ce.claimline 
AND ce.ruleid IN ('154','157','185','208','271','330','155')
AND (ce.status = [C154] OR ce.status = [C157] OR ce.status = [C185] OR ce.status = [C208] OR ce.status = [C271] OR ce.status = [C330]  OR ce.status = [C155]) 

SELECT ce.status, COUNT(*)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem  ON tem.claimid = ce.claimid AND  tem.claimline = ce.claimline 
AND ce.ruleid IN ('154','157','185','208','271','330','155')
AND (ce.status = [C154] OR ce.status = [C157] OR ce.status = [C185] OR ce.status = [C208] OR ce.status = [C271] OR ce.status = [C330]  OR ce.status = [C155])
GROUP BY ce.status, ce.ruleid
";

 public string OKAY_EDIT = @"
------------------------------------------------------
PRINT 'Claimedit to OKAY for several ruleid'
------------------------------------------------------
SELECT ce.*  INTO BDU_TEMP.EDI.[@EXCEL_ce2]
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid  
WHERE   ce.ruleid in (##)  

UPDATE ce
SET status = 'OKAY',clearby = 'PHX\EDIUser',cleardate = GETDATE(), state = 'MANUAL'
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid  
WHERE  ce.ruleid in (##)  

SELECT ce.status,ce.ruleid, COUNT(ce.claimid)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem  ON tem.claimid = ce.claimid  
WHERE  ce.ruleid in  (##)
GROUP BY  ce.status,ce.ruleid
";

public string OKAY_EDIT_913 = @"
------------------------------------------------------
PRINT 'Claimedit to OKAY for   ruleid 913'
------------------------------------------------------
SELECT ce.*  INTO BDU_TEMP.EDI.[@EXCEL_ce2]
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid  AND  '0' = ce.claimline 
WHERE   ce.ruleid in ('913')  

UPDATE ce
SET status = 'OKAY',clearby = 'PHX\EDIUser',cleardate = GETDATE(), state = 'MANUAL'
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid  AND  '0' = ce.claimline 
WHERE  ce.ruleid in ('913')  

SELECT ce.status,ce.ruleid, COUNT(ce.claimid)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem  ON tem.claimid = ce.claimid  AND '0' = ce.claimline 
WHERE  ce.ruleid in ('913')  
GROUP BY  ce.status,ce.ruleid
";

public string OKAY_EDIT_forPEND_Status = @"
------------------------------------------------------
PRINT 'Claimedit to OKAY  '
------------------------------------------------------
SELECT ce.*
INTO BDU_TEMP.EDI.[@EXCEL_ce3]
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid  
WHERE   ce.ruleid in (##)  AND ce.status = 'PEND'

UPDATE ce
SET status = 'OKAY',clearby = 'PHX\EDIUser',cleardate = GETDATE(), state = 'MANUAL'
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid  
WHERE  ce.ruleid in (##)  AND ce.status = 'PEND'

SELECT ce.status,ce.ruleid, COUNT(ce.claimid)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem  ON tem.claimid = ce.claimid  
WHERE  ce.ruleid in (##)   
GROUP BY  ce.status,ce.ruleid
";
public string OKAY_EDIT_for837 = @" 
-----------------------------------------------
PRINT 'Okay the claim EDIT AND retrofit IN 837'
-----------------------------------------------
SELECT ce.* INTO BDU_Temp.edi.[@EXCEL_ce4]
FROM @QNXT..claimedit ce (nolock)
JOIN BDU_Temp.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid  WHERE ruleid IN ('837')

UPDATE ce
SET ce.status = 'OKAY', ce.clearby = 'retrofit', ce.cleardate = getdate(), ce.state = 'MANUAL'
FROM @QNXT..claimedit ce (nolock)
JOIN BDU_Temp.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid  WHERE ruleid IN ('837')

SELECT ce.status, COUNT(ce.claimid)
FROM @QNXT..claimedit ce (nolock)
JOIN BDU_Temp.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid  WHERE ruleid IN ('837')
GROUP BY ce.status
";


public string OKAY_EDIT_at_EXCEL_Ruleid_Claimline = @"
        ------------------------------------------------------
PRINT 'Claimedit to OKAY for claimline and ruleid'
------------------------------------------------------
SELECT ce.*
INTO BDU_TEMP.EDI.[@EXCEL_ce4]
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid  and  tem.claimline = ce.claimline  where ce.ruleid =tem.ruleid

UPDATE ce
SET status = 'OKAY',clearby = 'PHX\EDIUser',cleardate = GETDATE(), state = 'MANUAL'
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid  and  tem.claimline = ce.claimline where ce.ruleid =tem.ruleid

SELECT ce.status,ce.ruleid, COUNT(ce.claimid)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem  ON tem.claimid = ce.claimid  
and  tem.claimline = ce.claimline  where ce.ruleid =tem.ruleid
GROUP BY  ce.status,ce.ruleid
";

 public string InsertDeny915 = @"
--------------------------------------------------------------------------------
PRINT 'INSERT deny 915 claim EDITs'
--------------------------------------------------------------------------------
SELECT ce.* INTO BDU_Temp.EDI.[@EXCEL_ce]
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_Temp.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid AND tem.claimline = ce.claimline
JOIN @QNXT..claim clm (NOLOCK) ON clm.claimid = tem.claimid
WHERE ruleid IN ('915') AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

UPDATE ce 
SET status = 'DENY', clearby = 'PHX\EDIUser', cleardate = getdate(), state = 'MANUAL', reason = 'M119'
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_Temp.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid AND tem.claimline = ce.claimline
JOIN @QNXT..claim clm (NOLOCK) ON clm.claimid = tem.claimid
WHERE ruleid IN ('915') and clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

INSERT INTO @QNXT..claimedit(claimid, claimline, ruleid, status, reason, state)
SELECT distinct tem.claimid, tem.claimline,'915','DENY','M119', 'MANUAL' 
FROM @QNXT..claimedit ce (NOLOCK) right JOIN BDU_Temp.EDI.[@EXCEL] tem  ON tem.claimid = ce.claimid AND tem.claimline = ce.claimline
AND ruleid IN ('915') AND ce.status = 'DENY' AND ce.reason = 'M119'
JOIN @QNXT..claim clm (NOLOCK) ON clm.claimid = tem.claimid
WHERE ce.claimid IS NULL AND ce.claimline IS NULL and clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND tem.claimline IS NOT NULL

SELECT ce.status,ce.reason,COUNT(1)
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_Temp.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid AND tem.claimline = ce.claimline
JOIN @QNXT..claim clm (NOLOCK) ON clm.claimid = tem.claimid
WHERE ruleid IN ('915') AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
GROUP BY ce.status, ce.reason
";

 public string PEND913_claimline_0 = @"
----------------------------------------------------------------------------
PRINT 'Insert PEND edit 913 with claimline 0'
----------------------------------------------------------------------------
----Initial check
SELECT ce.status, COUNT(*)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem 
ON tem.claimid = ce.claimid
AND ce.ruleid IN ('913')
AND ce.claimline = '0'
GROUP BY ce.status

----Backup
SELECT ce.*  INTO BDU_TEMP.edi.[@EXCEL_ce3]
FROM BDU_TEMP.edi.[@EXCEL] tem (NOLOCK) JOIN @QNXT..claim clm (NOLOCK)
ON tem.claimid = clm.claimid
JOIN @QNXT..claimedit ce (NOLOCK)  
ON clm.claimid = ce.claimid
AND ce.ruleid IN ('913') AND ce.claimline = '0' AND ce.status != 'PEND'

----Update
UPDATE ce SET status = 'PEND', state = 'MANUAL'
FROM BDU_TEMP.edi.[@EXCEL] tem (NOLOCK)
JOIN @QNXT..claim clm (NOLOCK) ON tem.claimid = clm.claimid
JOIN @QNXT..claimedit ce (NOLOCK) ON clm.claimid = ce.claimid
AND ce.ruleid IN ('913') AND ce.claimline = '0' AND ce.status != 'PEND'

--Verification
SELECT COUNT(*), ce.status 
FROM BDU_TEMP.EDI.[@EXCEL] tem (NOLOCK)
JOIN @QNXT..claim clm (NOLOCK) ON tem.claimid = clm.claimid
JOIN @QNXT..claimedit ce (NOLOCK) 
ON clm.claimid = ce.claimid  AND ce.ruleid IN ('913') AND ce.claimline = '0'
GROUP BY ce.status

--Count before insert
SELECT COUNT(1)
FROM @QNXT..claimedit ce (NOLOCK)
RIGHT JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
AND ce.ruleid IN ('913') AND ce.claimline = '0' 
WHERE ce.claimid IS NULL  AND tem.claimid IS NOT NULL
 
----Insert 
INSERT INTO @QNXT..claimedit (claimid, claimline, status, ruleid, state)  
SELECT DISTINCT tem.ClaimID, '0','PEND', '913', 'MANUAL'  
FROM @QNXT..claimedit ce (NOLOCK)
RIGHT JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid
AND ce.ruleid IN ('913') AND ce.claimline = '0' 
WHERE ce.claimid IS NULL  AND  tem.claimid IS NOT NULL
";
    }
}
