﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
    public class clsTab_Claim
    {
public string claimStatusToPEND = @"
----------------------------------------------------------------------------
PRINT 'Claim status to PEND' 
----------------------------------------------------------------------------
SELECT clm.* INTO BDU_Temp.edi.[@EXCEL_CLM]
FROM BDU_Temp.edi.[@EXCEL] tem  JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

UPDATE clm SET clm.status ='PEND'
FROM  @QNXT..claim clm (NOLOCK)  JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 

SELECT clm.status, COUNT(1), COUNT(DISTINCT clm.claimid)
FROM BDU_Temp.edi.[@EXCEL] tem  JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status
";

public string claimStatusToOPEN = @"
----------------------------------------------------------------------------
PRINT 'Claim status to PEND' 
----------------------------------------------------------------------------
SELECT clm.* INTO BDU_Temp.edi.[@EXCEL_CLM]
FROM BDU_Temp.edi.[@EXCEL] tem  JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

UPDATE clm SET clm.status ='OPEN'
FROM  @QNXT..claim clm (NOLOCK)  JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 

SELECT clm.status, COUNT(1), COUNT(DISTINCT clm.claimid)
FROM  @QNXT..claim clm (NOLOCK)  JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status
";

 public string  StatusToOPEN_ISLTC = @"
----------------------------------------------------------------------------
PRINT 'Claim status to OPEN, isltc to N' 
----------------------------------------------------------------------------
SELECT clm.* INTO BDU_Temp.edi.[@EXCEL_CLM]
FROM  @QNXT..claim clm (NOLOCK)  JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

UPDATE clm SET clm.status ='OPEN',clm.isltc = 'N'
FROM  @QNXT..claim clm (NOLOCK)  JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 

SELECT clm.status,clm.isltc, COUNT(1), COUNT(DISTINCT clm.claimid)
FROM  @QNXT..claim clm (NOLOCK)  JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status,clm.isltc
";


public string provid_affilationid = @"
----------------------------------------------------------------------------
PRINT 'Update claim status, provid and affilationid'
----------------------------------------------------------------------------
-- Backup
SELECT clm.*
INTO BDU_Temp.EDI.[@EXCEL_CLM1]
FROM @QNXT..claim clm (NOLOCK) 
JOIN BDU_Temp.EDI.[@EXCEL] tem ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
 
-- Update
UPDATE clm SET clm.status = 'OPEN', clm.provid = '##', clm.affiliationid = '##'
FROM @QNXT..claim clm (NOLOCK) JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

-- Verify
SELECT COUNT(*) as claimid, COUNT(DISTINCT clm.claimid) as disclaimid, clm.provid, clm.affiliationid, clm.status
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
GROUP BY clm.provid, clm.affiliationid, clm.status
";

 public string OPEN_eobreceived = @"
----------------------------------------------------------------------------
PRINT 'Claim status to OPEN and eobreceived'
----------------------------------------------------------------------------
-- Backup
SELECT clm.*
INTO BDU_Temp.EDI.[@EXCEL_CLM1]
FROM @QNXT..claim clm (NOLOCK) 
JOIN BDU_Temp.EDI.[@EXCEL] tem ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
 
-- Update
UPDATE clm SET clm.status = 'OPEN', clm.eobreceived  = 'Y'
FROM @QNXT..claim clm (NOLOCK) JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

-- Verify
select clm.status, clm.eobreceived, COUNT(*), COUNT(DISTINCT clm.claimid)
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
GROUP BY clm.status, clm.eobreceived
";

    }
}
