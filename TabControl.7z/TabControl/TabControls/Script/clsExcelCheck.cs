﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
    public static class clsExcelCheck
    {
public static string cExcelCheck = @"
print 'Validate Excel Data';
use BDU_Temp 

DELETE FROM  [BDU_Temp].[EDI].[@EXCEL] where claimid is null or claimid='' ;
DELETE FROM  [BDU_Temp].[EDI].[@EXCEL] WHERE  claimid IN  (SELECT t.claimid  FROM  [BDU_Temp].[EDI].[@EXCEL] t  
JOIN @QNXT..claim clm  (NOLOCK) ON clm.claimid = t.claimid  WHERE  clm.status IN ('PAID','DENIED','VOID','REVERSED'))
Declare @Multi int,@disClaim int;
SELECT @Multi=COUNT(1), @disClaim=COUNT(DISTINCT claimid)  FROM [BDU_TEMP].[EDI].[@EXCEL]; 
if (@Multi>@disClaim)
begin
  select distinct *  into  #@WO  FROM [BDU_Temp].[EDI].[@EXCEL] 
   truncate table [BDU_Temp].[EDI].[@EXCEL]; 
   insert into [BDU_Temp].[EDI].[@EXCEL]   select *  FROM  #@WO;
end
print 'Row #:' + cast(@disClaim as varchar);

"; 

    }
}
