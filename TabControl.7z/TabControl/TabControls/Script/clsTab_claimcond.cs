﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
    public class clsTab_claimcond
    {
 public string UpdateClaimcond = @"
USE @QNXT
------------------------------------------------------
PRINT 'Update and insert claimcond'
------------------------------------------------------ 
--Backup
SELECT cc.*
INTO BDU_TEMP.EDI.[@EXCEL_cc]
FROM @QNXT..claimcond cc(NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem ON cc.claimid = tem.claimid
JOIN @QNXT..claim clm ON tem.claimid = clm.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

--Update those that exist
UPDATE cc SET condcode = tem.condcode
FROM @QNXT..claimcond cc (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem ON cc.claimid = tem.claimid
JOIN @QNXT..claim clm ON tem.claimid = clm.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

--Verify
SELECT COUNT(*)
FROM @QNXT..claimcond cc (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem ON cc.claimid = tem.claimid
JOIN @QNXT..claim clm ON tem.claimid = clm.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

--Insert those that are missing
INSERT INTO @QNXT..claimcond(claimid, condcode)
SELECT DISTINCT tem.claimid, tem.condcode
FROM @QNXT..claimcond cd(NOLOCK)
RIGHT JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = cd.claimid WHERE cd.claimid IS NULL

--Final verify
SELECT COUNT(cc.claimid), COUNT(DISTINCT (cc.claimid))
FROM @QNXT..claimcond cc (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem ON cc.claimid = tem.claimid
JOIN @QNXT..claim clm ON tem.claimid = clm.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
";
    }
}
