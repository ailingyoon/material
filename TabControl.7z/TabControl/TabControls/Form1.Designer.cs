﻿namespace TabControls
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button8 = new System.Windows.Forms.Button();
            this.btnTodayMailed = new System.Windows.Forms.Button();
            this.btnCheckPlans = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnToScript = new System.Windows.Forms.Button();
            this.comboDateDone = new System.Windows.Forms.ComboBox();
            this.btnGetDONE = new System.Windows.Forms.Button();
            this.btnRemedy = new System.Windows.Forms.Button();
            this.btnAssignMe = new System.Windows.Forms.Button();
            this.bntSendCompare = new System.Windows.Forms.Button();
            this.btnNotWork = new System.Windows.Forms.Button();
            this.txtGetWO = new System.Windows.Forms.TextBox();
            this.btnWOavailable = new System.Windows.Forms.Button();
            this.txtWOSummary = new System.Windows.Forms.TextBox();
            this.txtWOdetail = new System.Windows.Forms.TextBox();
            this.btnUnWO = new System.Windows.Forms.Button();
            this.gvWO = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnShowOlder = new System.Windows.Forms.Button();
            this.txtOlderWO = new System.Windows.Forms.TextBox();
            this.btnClearDescription = new System.Windows.Forms.Button();
            this.txtTableName = new System.Windows.Forms.TextBox();
            this.txtPlans = new System.Windows.Forms.TextBox();
            this.btnSearchDesc = new System.Windows.Forms.Button();
            this.txtComp2 = new System.Windows.Forms.TextBox();
            this.txtComp1 = new System.Windows.Forms.TextBox();
            this.gvSummary = new System.Windows.Forms.DataGridView();
            this.btnSummaryCompare = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnWO1Compare = new System.Windows.Forms.Button();
            this.txtSearchWO = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnDeleteWOBackLog = new System.Windows.Forms.Button();
            this.txtDeleteWO = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.gvMail = new System.Windows.Forms.DataGridView();
            this.check = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnMaillist = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.comboPlans = new System.Windows.Forms.ComboBox();
            this.txtTableByPlans = new System.Windows.Forms.TextBox();
            this.btnPlansByWO = new System.Windows.Forms.Button();
            this.txtWOSetScript = new System.Windows.Forms.TextBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtRecItem2 = new System.Windows.Forms.TextBox();
            this.txtRecDesc2 = new System.Windows.Forms.TextBox();
            this.btnSaveRec = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRecItem1 = new System.Windows.Forms.TextBox();
            this.txtRecDesc1 = new System.Windows.Forms.TextBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.btnWrite = new System.Windows.Forms.Button();
            this.btnWriteOnHand = new System.Windows.Forms.Button();
            this.gvWrite = new System.Windows.Forms.DataGridView();
            this.SEL = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvWO)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvSummary)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvMail)).BeginInit();
            this.panel1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvWrite)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1115, 628);
            this.tabControl1.TabIndex = 1;
            this.tabControl1.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabControl1_DrawItem);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button8);
            this.tabPage1.Controls.Add(this.btnTodayMailed);
            this.tabPage1.Controls.Add(this.btnCheckPlans);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.btnToScript);
            this.tabPage1.Controls.Add(this.comboDateDone);
            this.tabPage1.Controls.Add(this.btnGetDONE);
            this.tabPage1.Controls.Add(this.btnRemedy);
            this.tabPage1.Controls.Add(this.btnAssignMe);
            this.tabPage1.Controls.Add(this.bntSendCompare);
            this.tabPage1.Controls.Add(this.btnNotWork);
            this.tabPage1.Controls.Add(this.txtGetWO);
            this.tabPage1.Controls.Add(this.btnWOavailable);
            this.tabPage1.Controls.Add(this.txtWOSummary);
            this.tabPage1.Controls.Add(this.txtWOdetail);
            this.tabPage1.Controls.Add(this.btnUnWO);
            this.tabPage1.Controls.Add(this.gvWO);
            this.tabPage1.Font = new System.Drawing.Font("SimSun", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1107, 602);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "----GetWO----";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(865, 547);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(87, 31);
            this.button8.TabIndex = 30;
            this.button8.Tag = "insert";
            this.button8.Text = "insert sub";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // btnTodayMailed
            // 
            this.btnTodayMailed.Location = new System.Drawing.Point(784, 547);
            this.btnTodayMailed.Name = "btnTodayMailed";
            this.btnTodayMailed.Size = new System.Drawing.Size(75, 31);
            this.btnTodayMailed.TabIndex = 29;
            this.btnTodayMailed.Text = "Mailed";
            this.btnTodayMailed.UseVisualStyleBackColor = true;
            this.btnTodayMailed.Click += new System.EventHandler(this.btnTodayMailed_Click);
            // 
            // btnCheckPlans
            // 
            this.btnCheckPlans.Location = new System.Drawing.Point(92, 562);
            this.btnCheckPlans.Name = "btnCheckPlans";
            this.btnCheckPlans.Size = new System.Drawing.Size(84, 31);
            this.btnCheckPlans.TabIndex = 28;
            this.btnCheckPlans.Text = "ChkPlans";
            this.btnCheckPlans.UseVisualStyleBackColor = true;
            this.btnCheckPlans.Click += new System.EventHandler(this.btnCheckPlans_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(682, 547);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 31);
            this.button2.TabIndex = 27;
            this.button2.Text = "OnHand";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnToScript
            // 
            this.btnToScript.Location = new System.Drawing.Point(371, 520);
            this.btnToScript.Name = "btnToScript";
            this.btnToScript.Size = new System.Drawing.Size(66, 26);
            this.btnToScript.TabIndex = 26;
            this.btnToScript.Text = "Script";
            this.btnToScript.UseVisualStyleBackColor = true;
            this.btnToScript.Click += new System.EventHandler(this.btnToScript_Click);
            // 
            // comboDateDone
            // 
            this.comboDateDone.FormattingEnabled = true;
            this.comboDateDone.Location = new System.Drawing.Point(450, 553);
            this.comboDateDone.Name = "comboDateDone";
            this.comboDateDone.Size = new System.Drawing.Size(102, 21);
            this.comboDateDone.TabIndex = 25;
            // 
            // btnGetDONE
            // 
            this.btnGetDONE.Location = new System.Drawing.Point(584, 547);
            this.btnGetDONE.Name = "btnGetDONE";
            this.btnGetDONE.Size = new System.Drawing.Size(71, 31);
            this.btnGetDONE.TabIndex = 24;
            this.btnGetDONE.Tag = "Done";
            this.btnGetDONE.Text = "Done";
            this.btnGetDONE.UseVisualStyleBackColor = true;
            this.btnGetDONE.Click += new System.EventHandler(this.btnGetDONE_Click);
            // 
            // btnRemedy
            // 
            this.btnRemedy.Location = new System.Drawing.Point(831, 507);
            this.btnRemedy.Name = "btnRemedy";
            this.btnRemedy.Size = new System.Drawing.Size(104, 34);
            this.btnRemedy.TabIndex = 22;
            this.btnRemedy.Text = "fromRemedy";
            this.btnRemedy.UseVisualStyleBackColor = true;
            this.btnRemedy.Click += new System.EventHandler(this.btnRemedy_Click);
            // 
            // btnAssignMe
            // 
            this.btnAssignMe.Location = new System.Drawing.Point(195, 547);
            this.btnAssignMe.Name = "btnAssignMe";
            this.btnAssignMe.Size = new System.Drawing.Size(71, 26);
            this.btnAssignMe.TabIndex = 21;
            this.btnAssignMe.Text = "已選";
            this.btnAssignMe.UseVisualStyleBackColor = true;
            this.btnAssignMe.Click += new System.EventHandler(this.btnAssignMe_Click);
            // 
            // bntSendCompare
            // 
            this.bntSendCompare.Location = new System.Drawing.Point(290, 520);
            this.bntSendCompare.Name = "bntSendCompare";
            this.bntSendCompare.Size = new System.Drawing.Size(66, 26);
            this.bntSendCompare.TabIndex = 20;
            this.bntSendCompare.Text = "Compare";
            this.bntSendCompare.UseVisualStyleBackColor = true;
            this.bntSendCompare.Click += new System.EventHandler(this.bntSendCompare_Click);
            // 
            // btnNotWork
            // 
            this.btnNotWork.Location = new System.Drawing.Point(195, 513);
            this.btnNotWork.Name = "btnNotWork";
            this.btnNotWork.Size = new System.Drawing.Size(66, 28);
            this.btnNotWork.TabIndex = 4;
            this.btnNotWork.Text = "NO";
            this.btnNotWork.UseVisualStyleBackColor = true;
            this.btnNotWork.Click += new System.EventHandler(this.btnNotWork_Click);
            // 
            // txtGetWO
            // 
            this.txtGetWO.Location = new System.Drawing.Point(269, 6);
            this.txtGetWO.Name = "txtGetWO";
            this.txtGetWO.Size = new System.Drawing.Size(168, 23);
            this.txtGetWO.TabIndex = 19;
            // 
            // btnWOavailable
            // 
            this.btnWOavailable.Location = new System.Drawing.Point(92, 513);
            this.btnWOavailable.Name = "btnWOavailable";
            this.btnWOavailable.Size = new System.Drawing.Size(84, 35);
            this.btnWOavailable.TabIndex = 3;
            this.btnWOavailable.Text = "Available";
            this.btnWOavailable.UseVisualStyleBackColor = true;
            this.btnWOavailable.Click += new System.EventHandler(this.btnWOavailable_Click);
            // 
            // txtWOSummary
            // 
            this.txtWOSummary.Location = new System.Drawing.Point(459, 5);
            this.txtWOSummary.Multiline = true;
            this.txtWOSummary.Name = "txtWOSummary";
            this.txtWOSummary.Size = new System.Drawing.Size(400, 27);
            this.txtWOSummary.TabIndex = 18;
            // 
            // txtWOdetail
            // 
            this.txtWOdetail.Font = new System.Drawing.Font("SimSun", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtWOdetail.Location = new System.Drawing.Point(8, 35);
            this.txtWOdetail.Multiline = true;
            this.txtWOdetail.Name = "txtWOdetail";
            this.txtWOdetail.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtWOdetail.Size = new System.Drawing.Size(1032, 285);
            this.txtWOdetail.TabIndex = 17;
            // 
            // btnUnWO
            // 
            this.btnUnWO.Location = new System.Drawing.Point(8, 514);
            this.btnUnWO.Name = "btnUnWO";
            this.btnUnWO.Size = new System.Drawing.Size(81, 38);
            this.btnUnWO.TabIndex = 16;
            this.btnUnWO.Text = "GetWO";
            this.btnUnWO.UseVisualStyleBackColor = true;
            this.btnUnWO.Click += new System.EventHandler(this.btnUnWO_Click);
            // 
            // gvWO
            // 
            this.gvWO.AllowUserToAddRows = false;
            this.gvWO.AllowUserToDeleteRows = false;
            this.gvWO.BackgroundColor = System.Drawing.Color.LightYellow;
            this.gvWO.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvWO.Location = new System.Drawing.Point(8, 326);
            this.gvWO.Name = "gvWO";
            this.gvWO.RowTemplate.Height = 24;
            this.gvWO.Size = new System.Drawing.Size(1032, 174);
            this.gvWO.TabIndex = 15;
            this.gvWO.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvWO_CellContentClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnShowOlder);
            this.tabPage2.Controls.Add(this.txtOlderWO);
            this.tabPage2.Controls.Add(this.btnClearDescription);
            this.tabPage2.Controls.Add(this.txtTableName);
            this.tabPage2.Controls.Add(this.txtPlans);
            this.tabPage2.Controls.Add(this.btnSearchDesc);
            this.tabPage2.Controls.Add(this.txtComp2);
            this.tabPage2.Controls.Add(this.txtComp1);
            this.tabPage2.Controls.Add(this.gvSummary);
            this.tabPage2.Controls.Add(this.btnSummaryCompare);
            this.tabPage2.Controls.Add(this.txtSearch);
            this.tabPage2.Controls.Add(this.btnWO1Compare);
            this.tabPage2.Controls.Add(this.txtSearchWO);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1107, 602);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "PreCompare";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnShowOlder
            // 
            this.btnShowOlder.Location = new System.Drawing.Point(606, 83);
            this.btnShowOlder.Name = "btnShowOlder";
            this.btnShowOlder.Size = new System.Drawing.Size(73, 32);
            this.btnShowOlder.TabIndex = 25;
            this.btnShowOlder.Text = "older WO";
            this.btnShowOlder.UseVisualStyleBackColor = true;
            this.btnShowOlder.Click += new System.EventHandler(this.btnShowOlder_Click);
            // 
            // txtOlderWO
            // 
            this.txtOlderWO.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOlderWO.Location = new System.Drawing.Point(331, 86);
            this.txtOlderWO.Name = "txtOlderWO";
            this.txtOlderWO.Size = new System.Drawing.Size(257, 29);
            this.txtOlderWO.TabIndex = 24;
            // 
            // btnClearDescription
            // 
            this.btnClearDescription.Location = new System.Drawing.Point(894, 6);
            this.btnClearDescription.Name = "btnClearDescription";
            this.btnClearDescription.Size = new System.Drawing.Size(60, 34);
            this.btnClearDescription.TabIndex = 23;
            this.btnClearDescription.Text = "clear";
            this.btnClearDescription.UseVisualStyleBackColor = true;
            this.btnClearDescription.Click += new System.EventHandler(this.btnClearDescription_Click);
            // 
            // txtTableName
            // 
            this.txtTableName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTableName.Location = new System.Drawing.Point(8, 94);
            this.txtTableName.Name = "txtTableName";
            this.txtTableName.Size = new System.Drawing.Size(299, 26);
            this.txtTableName.TabIndex = 22;
            // 
            // txtPlans
            // 
            this.txtPlans.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlans.Location = new System.Drawing.Point(8, 62);
            this.txtPlans.Name = "txtPlans";
            this.txtPlans.Size = new System.Drawing.Size(269, 26);
            this.txtPlans.TabIndex = 21;
            // 
            // btnSearchDesc
            // 
            this.btnSearchDesc.Location = new System.Drawing.Point(894, 43);
            this.btnSearchDesc.Name = "btnSearchDesc";
            this.btnSearchDesc.Size = new System.Drawing.Size(72, 34);
            this.btnSearchDesc.TabIndex = 20;
            this.btnSearchDesc.Text = "Description";
            this.btnSearchDesc.UseVisualStyleBackColor = true;
            this.btnSearchDesc.Click += new System.EventHandler(this.btnSearchDesc_Click);
            // 
            // txtComp2
            // 
            this.txtComp2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComp2.Location = new System.Drawing.Point(562, 249);
            this.txtComp2.Multiline = true;
            this.txtComp2.Name = "txtComp2";
            this.txtComp2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtComp2.Size = new System.Drawing.Size(539, 350);
            this.txtComp2.TabIndex = 19;
            // 
            // txtComp1
            // 
            this.txtComp1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComp1.Location = new System.Drawing.Point(8, 249);
            this.txtComp1.Multiline = true;
            this.txtComp1.Name = "txtComp1";
            this.txtComp1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtComp1.Size = new System.Drawing.Size(548, 347);
            this.txtComp1.TabIndex = 18;
            // 
            // gvSummary
            // 
            this.gvSummary.AllowUserToAddRows = false;
            this.gvSummary.BackgroundColor = System.Drawing.Color.LightYellow;
            this.gvSummary.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvSummary.Location = new System.Drawing.Point(17, 126);
            this.gvSummary.Name = "gvSummary";
            this.gvSummary.RowTemplate.Height = 24;
            this.gvSummary.Size = new System.Drawing.Size(976, 117);
            this.gvSummary.TabIndex = 16;
            this.gvSummary.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvSummary_CellContentClick);
            // 
            // btnSummaryCompare
            // 
            this.btnSummaryCompare.Location = new System.Drawing.Point(894, 86);
            this.btnSummaryCompare.Name = "btnSummaryCompare";
            this.btnSummaryCompare.Size = new System.Drawing.Size(72, 34);
            this.btnSummaryCompare.TabIndex = 3;
            this.btnSummaryCompare.Text = "Summary";
            this.btnSummaryCompare.UseVisualStyleBackColor = true;
            this.btnSummaryCompare.Click += new System.EventHandler(this.btnSummaryCompare_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.Location = new System.Drawing.Point(331, 3);
            this.txtSearch.Multiline = true;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(557, 74);
            this.txtSearch.TabIndex = 2;
            // 
            // btnWO1Compare
            // 
            this.btnWO1Compare.Location = new System.Drawing.Point(237, 12);
            this.btnWO1Compare.Name = "btnWO1Compare";
            this.btnWO1Compare.Size = new System.Drawing.Size(88, 31);
            this.btnWO1Compare.TabIndex = 1;
            this.btnWO1Compare.Text = "Detail";
            this.btnWO1Compare.UseVisualStyleBackColor = true;
            this.btnWO1Compare.Click += new System.EventHandler(this.btnWO1Compare_Click);
            // 
            // txtSearchWO
            // 
            this.txtSearchWO.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchWO.Location = new System.Drawing.Point(6, 15);
            this.txtSearchWO.Name = "txtSearchWO";
            this.txtSearchWO.Size = new System.Drawing.Size(225, 24);
            this.txtSearchWO.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1107, 602);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Compare";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnDeleteWOBackLog);
            this.tabPage4.Controls.Add(this.txtDeleteWO);
            this.tabPage4.Controls.Add(this.button7);
            this.tabPage4.Controls.Add(this.gvMail);
            this.tabPage4.Controls.Add(this.panel1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1107, 602);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "email";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btnDeleteWOBackLog
            // 
            this.btnDeleteWOBackLog.Location = new System.Drawing.Point(256, 338);
            this.btnDeleteWOBackLog.Name = "btnDeleteWOBackLog";
            this.btnDeleteWOBackLog.Size = new System.Drawing.Size(81, 22);
            this.btnDeleteWOBackLog.TabIndex = 9;
            this.btnDeleteWOBackLog.Text = "Delete WO";
            this.btnDeleteWOBackLog.UseVisualStyleBackColor = true;
            this.btnDeleteWOBackLog.Click += new System.EventHandler(this.btnDeleteWOBackLog_Click);
            // 
            // txtDeleteWO
            // 
            this.txtDeleteWO.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDeleteWO.Location = new System.Drawing.Point(38, 336);
            this.txtDeleteWO.Name = "txtDeleteWO";
            this.txtDeleteWO.Size = new System.Drawing.Size(203, 24);
            this.txtDeleteWO.TabIndex = 8;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(38, 286);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(72, 30);
            this.button7.TabIndex = 7;
            this.button7.Text = "completed";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // gvMail
            // 
            this.gvMail.AllowUserToAddRows = false;
            this.gvMail.AllowUserToDeleteRows = false;
            this.gvMail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvMail.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.check});
            this.gvMail.Dock = System.Windows.Forms.DockStyle.Top;
            this.gvMail.Location = new System.Drawing.Point(3, 41);
            this.gvMail.Name = "gvMail";
            this.gvMail.RowTemplate.Height = 23;
            this.gvMail.Size = new System.Drawing.Size(1101, 225);
            this.gvMail.TabIndex = 2;
            this.gvMail.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvMail_CellContentClick);
            // 
            // check
            // 
            this.check.HeaderText = "选择";
            this.check.Name = "check";
            this.check.Width = 35;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnMaillist);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1101, 38);
            this.panel1.TabIndex = 1;
            // 
            // btnMaillist
            // 
            this.btnMaillist.Location = new System.Drawing.Point(35, 7);
            this.btnMaillist.Name = "btnMaillist";
            this.btnMaillist.Size = new System.Drawing.Size(72, 23);
            this.btnMaillist.TabIndex = 6;
            this.btnMaillist.Text = "列出";
            this.btnMaillist.UseVisualStyleBackColor = true;
            this.btnMaillist.Click += new System.EventHandler(this.btnMaillist_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(437, 7);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 25);
            this.button5.TabIndex = 5;
            this.button5.Text = "导出选中";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(354, 7);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 25);
            this.button4.TabIndex = 4;
            this.button4.Text = "导出全部";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(163, 7);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 25);
            this.button3.TabIndex = 3;
            this.button3.Text = "發送";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(518, 7);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 25);
            this.button6.TabIndex = 1;
            this.button6.Text = "反选";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.panel2);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1107, 602);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Scripts";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel2.Controls.Add(this.comboPlans);
            this.panel2.Controls.Add(this.txtTableByPlans);
            this.panel2.Controls.Add(this.btnPlansByWO);
            this.panel2.Controls.Add(this.txtWOSetScript);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1101, 63);
            this.panel2.TabIndex = 0;
            // 
            // comboPlans
            // 
            this.comboPlans.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboPlans.FormattingEnabled = true;
            this.comboPlans.Location = new System.Drawing.Point(344, 5);
            this.comboPlans.Name = "comboPlans";
            this.comboPlans.Size = new System.Drawing.Size(120, 24);
            this.comboPlans.TabIndex = 26;
            this.comboPlans.SelectedIndexChanged += new System.EventHandler(this.comboPlans_SelectedIndexChanged);
            // 
            // txtTableByPlans
            // 
            this.txtTableByPlans.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTableByPlans.Location = new System.Drawing.Point(470, 4);
            this.txtTableByPlans.Name = "txtTableByPlans";
            this.txtTableByPlans.Size = new System.Drawing.Size(386, 26);
            this.txtTableByPlans.TabIndex = 22;
            // 
            // btnPlansByWO
            // 
            this.btnPlansByWO.BackColor = System.Drawing.Color.Black;
            this.btnPlansByWO.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnPlansByWO.Location = new System.Drawing.Point(236, 4);
            this.btnPlansByWO.Name = "btnPlansByWO";
            this.btnPlansByWO.Size = new System.Drawing.Size(80, 37);
            this.btnPlansByWO.TabIndex = 2;
            this.btnPlansByWO.Text = "Detail";
            this.btnPlansByWO.UseVisualStyleBackColor = false;
            this.btnPlansByWO.Click += new System.EventHandler(this.btnPlansByWO_Click);
            // 
            // txtWOSetScript
            // 
            this.txtWOSetScript.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWOSetScript.Location = new System.Drawing.Point(5, 3);
            this.txtWOSetScript.Name = "txtWOSetScript";
            this.txtWOSetScript.Size = new System.Drawing.Size(225, 24);
            this.txtWOSetScript.TabIndex = 1;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.panel4);
            this.tabPage6.Controls.Add(this.btnSaveRec);
            this.tabPage6.Controls.Add(this.panel3);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1107, 602);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "RecordItem";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txtRecItem2);
            this.panel4.Controls.Add(this.txtRecDesc2);
            this.panel4.Location = new System.Drawing.Point(0, 315);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1048, 269);
            this.panel4.TabIndex = 21;
            // 
            // txtRecItem2
            // 
            this.txtRecItem2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txtRecItem2.Font = new System.Drawing.Font("SimSun", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtRecItem2.ForeColor = System.Drawing.Color.Black;
            this.txtRecItem2.Location = new System.Drawing.Point(8, 98);
            this.txtRecItem2.Multiline = true;
            this.txtRecItem2.Name = "txtRecItem2";
            this.txtRecItem2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRecItem2.Size = new System.Drawing.Size(1032, 168);
            this.txtRecItem2.TabIndex = 19;
            // 
            // txtRecDesc2
            // 
            this.txtRecDesc2.BackColor = System.Drawing.Color.White;
            this.txtRecDesc2.Font = new System.Drawing.Font("SimSun", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtRecDesc2.ForeColor = System.Drawing.Color.Red;
            this.txtRecDesc2.Location = new System.Drawing.Point(8, 14);
            this.txtRecDesc2.Multiline = true;
            this.txtRecDesc2.Name = "txtRecDesc2";
            this.txtRecDesc2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRecDesc2.Size = new System.Drawing.Size(1021, 64);
            this.txtRecDesc2.TabIndex = 18;
            // 
            // btnSaveRec
            // 
            this.btnSaveRec.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveRec.Location = new System.Drawing.Point(453, 242);
            this.btnSaveRec.Name = "btnSaveRec";
            this.btnSaveRec.Size = new System.Drawing.Size(99, 53);
            this.btnSaveRec.TabIndex = 20;
            this.btnSaveRec.Text = "Save";
            this.btnSaveRec.UseVisualStyleBackColor = true;
            this.btnSaveRec.Click += new System.EventHandler(this.btnSaveRec_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.txtRecItem1);
            this.panel3.Controls.Add(this.txtRecDesc1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1107, 227);
            this.panel3.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 20);
            this.label2.TabIndex = 21;
            this.label2.Text = "From script template";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 20);
            this.label1.TabIndex = 20;
            this.label1.Text = "From WO description";
            // 
            // txtRecItem1
            // 
            this.txtRecItem1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtRecItem1.Font = new System.Drawing.Font("SimSun", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtRecItem1.ForeColor = System.Drawing.Color.Red;
            this.txtRecItem1.Location = new System.Drawing.Point(8, 153);
            this.txtRecItem1.Multiline = true;
            this.txtRecItem1.Name = "txtRecItem1";
            this.txtRecItem1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRecItem1.Size = new System.Drawing.Size(1032, 63);
            this.txtRecItem1.TabIndex = 19;
            // 
            // txtRecDesc1
            // 
            this.txtRecDesc1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtRecDesc1.Font = new System.Drawing.Font("SimSun", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtRecDesc1.ForeColor = System.Drawing.Color.Black;
            this.txtRecDesc1.Location = new System.Drawing.Point(8, 32);
            this.txtRecDesc1.Multiline = true;
            this.txtRecDesc1.Name = "txtRecDesc1";
            this.txtRecDesc1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRecDesc1.Size = new System.Drawing.Size(1032, 79);
            this.txtRecDesc1.TabIndex = 18;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.btnWrite);
            this.tabPage7.Controls.Add(this.btnWriteOnHand);
            this.tabPage7.Controls.Add(this.gvWrite);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1107, 602);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "寫檔案";
            this.tabPage7.UseVisualStyleBackColor = true;
            this.tabPage7.Click += new System.EventHandler(this.tabPage7_Click);
            // 
            // btnWrite
            // 
            this.btnWrite.Location = new System.Drawing.Point(205, 213);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(76, 30);
            this.btnWrite.TabIndex = 29;
            this.btnWrite.Text = "Write";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // btnWriteOnHand
            // 
            this.btnWriteOnHand.Location = new System.Drawing.Point(84, 213);
            this.btnWriteOnHand.Name = "btnWriteOnHand";
            this.btnWriteOnHand.Size = new System.Drawing.Size(75, 31);
            this.btnWriteOnHand.TabIndex = 28;
            this.btnWriteOnHand.Text = "OnHand";
            this.btnWriteOnHand.UseVisualStyleBackColor = true;
            this.btnWriteOnHand.Click += new System.EventHandler(this.btnWriteOnHand_Click);
            // 
            // gvWrite
            // 
            this.gvWrite.AllowUserToAddRows = false;
            this.gvWrite.AllowUserToDeleteRows = false;
            this.gvWrite.BackgroundColor = System.Drawing.Color.LightYellow;
            this.gvWrite.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvWrite.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SEL});
            this.gvWrite.Dock = System.Windows.Forms.DockStyle.Top;
            this.gvWrite.Location = new System.Drawing.Point(3, 3);
            this.gvWrite.Name = "gvWrite";
            this.gvWrite.RowTemplate.Height = 24;
            this.gvWrite.Size = new System.Drawing.Size(1101, 192);
            this.gvWrite.TabIndex = 16;
            // 
            // SEL
            // 
            this.SEL.HeaderText = "SEL";
            this.SEL.Name = "SEL";
            this.SEL.Width = 60;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 658);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1115, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusbar";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1115, 680);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvWO)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvSummary)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvMail)).EndInit();
            this.panel1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gvWrite)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnUnWO;
        private System.Windows.Forms.DataGridView gvWO;
        private System.Windows.Forms.TextBox txtWOdetail;
        private System.Windows.Forms.TextBox txtWOSummary;
        private System.Windows.Forms.TextBox txtGetWO;
        private System.Windows.Forms.Button btnWOavailable;
        private System.Windows.Forms.Button btnNotWork;
        private System.Windows.Forms.Button btnWO1Compare;
        private System.Windows.Forms.TextBox txtSearchWO;
        private System.Windows.Forms.DataGridView gvSummary;
        private System.Windows.Forms.Button btnSummaryCompare;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.TextBox txtComp2;
        private System.Windows.Forms.TextBox txtComp1;
        private System.Windows.Forms.Button btnSearchDesc;
        private System.Windows.Forms.TextBox txtTableName;
        private System.Windows.Forms.TextBox txtPlans;
        private System.Windows.Forms.Button bntSendCompare;
        private System.Windows.Forms.DataGridView gvMail;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button btnAssignMe;
        private System.Windows.Forms.Button btnMaillist;
        private System.Windows.Forms.DataGridViewCheckBoxColumn check;
        private System.Windows.Forms.Button btnRemedy;
        private System.Windows.Forms.ComboBox comboDateDone;
        private System.Windows.Forms.Button btnGetDONE;
        private System.Windows.Forms.Button btnClearDescription;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox comboPlans;
        private System.Windows.Forms.TextBox txtTableByPlans;
        private System.Windows.Forms.Button btnPlansByWO;
        private System.Windows.Forms.TextBox txtWOSetScript;
        private System.Windows.Forms.Button btnToScript;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtRecItem2;
        private System.Windows.Forms.TextBox txtRecDesc2;
        private System.Windows.Forms.Button btnSaveRec;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtRecItem1;
        private System.Windows.Forms.TextBox txtRecDesc1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnCheckPlans;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btnDeleteWOBackLog;
        private System.Windows.Forms.TextBox txtDeleteWO;
        private System.Windows.Forms.Button btnTodayMailed;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.DataGridView gvWrite;
        private System.Windows.Forms.Button btnWriteOnHand;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.DataGridViewCheckBoxColumn SEL;
        private System.Windows.Forms.Button btnShowOlder;
        private System.Windows.Forms.TextBox txtOlderWO;
    }
}

