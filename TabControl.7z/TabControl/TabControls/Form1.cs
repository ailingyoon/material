﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;
using System.IO;
using Utilities;
using BDUScript;

namespace TabControls
{
    public partial class Form1 : Form
    {
        private string WOGet = "";
        clsWO obj;
        public Form1() : base()
        {
            InitializeComponent();
        }
        private Icon icon = null;
        int PageMaxIndex = 0;
        //private void button1_Click(object sender, System.EventArgs e)
        //{
        //    PageMaxIndex++;
        //    tabControl1.TabPages.Add(new TabPage("ABC-" + PageMaxIndex));

        //}

        //关闭区域的宽高
        const int CLOSE_SIZE = 15;
        //重画
        private void tabControl1_DrawItem(object sender, System.Windows.Forms.DrawItemEventArgs e)
        {
            Graphics g = e.Graphics;
            using (Pen p = new Pen(this.ForeColor))
            {
                Rectangle myTabRect = tabControl1.GetTabRect(e.Index);
                //把字写上
                g.DrawString(tabControl1.TabPages[e.Index].Text
                , this.Font
                , SystemBrushes.ControlText
                , myTabRect.X + 2, myTabRect.Y + 2);
                //模拟绘制一个区域表示关闭的的地方（是一个红色的方块区域）
                //当然大多时候画一个图就可以了 12*12的
                myTabRect.Offset(myTabRect.Width - (CLOSE_SIZE + 3), 2);
                myTabRect.Width = CLOSE_SIZE;
                myTabRect.Height = CLOSE_SIZE;
                //g.DrawRectangle(p, myTabRect);
                icon = TabControls.Properties.Resources._3;
                g.DrawIcon(icon, myTabRect);

            }

        }
        private void tabControl1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {

            if (e.Button == MouseButtons.Left)
            {
                int x = e.X, y = e.Y;
                //计算关闭区域
                Rectangle myTabRect = tabControl1.GetTabRect(tabControl1.SelectedIndex);

                myTabRect.Offset(myTabRect.Width - (CLOSE_SIZE + 3), 2);
                myTabRect.Width = CLOSE_SIZE;
                myTabRect.Height = CLOSE_SIZE;

                //如果鼠标在区域内就关闭选项卡
                bool isClose = x > myTabRect.X
                && x < myTabRect.Right
                && y > myTabRect.Y
                && y < myTabRect.Bottom;

                if (isClose)
                {
                    tabControl1.TabPages.Remove(tabControl1.SelectedTab);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //设置若干属性
            tabControl1.DrawMode = TabDrawMode.OwnerDrawFixed;
            tabControl1.Padding = new System.Drawing.Point(15, 0);
            tabControl1.DrawItem += new DrawItemEventHandler(tabControl1_DrawItem);
            tabControl1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tabControl1_MouseDown);
            //var date = DateTime.Now.ToString("ddMMyyyy");
            var date = DateTime.Now;
            System.Object[] ItemObject = new System.Object[10];
            int j = -1;
            for (int i = 0; i < 10; i++)
            {
                j++;
                ItemObject[j] = date.AddDays(-i).ToString("yyyy-MM-dd");
            }
            comboDateDone.Items.AddRange(ItemObject);
        }

        private void btnUnWO_Click(object sender, EventArgs e)
        {
            //len(replace(rtrim(cast(t.Detailed_Description as varchar(max))), char(10), '#')) as lenDesc  ,  
            Cursor.Current = Cursors.WaitCursor;
            string sql = @" select  work_order_id,'NO' AS EXCEL,'' plans,RTRIM(LTRIM(t.[Summary]))  AS summ , 
replace(replace(replace(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(replace(replace(replace(replace(cast(t.Detailed_Description as varchar(Max)), char(13) + char(10),'#'),char(10), '#'),char(13),' '),char(9),' '),CHAR(32),'()'),')(',''),'()',CHAR(32)))), rtrim(t.Summary)+'##', ''),'Hello',''),'##','#') as detail 
      from [dbo].[WOI_WorkOrder] t WITH (NOLOCK)    where   t.Categorization_Tier_2  = 'claims'  and t.[Status]=0  and t.request_assignee is null
      and  cast( DATEADD(SECOND, t.[Submit_Date], '19700101') as date)=cast(getdate()  as date)  
      and t.work_order_id not in (select  work_order_id from   [PlanEDI].[EDI].[stgAuditLog] where wantsta='NO'  and   submitdate= cast(getdate()  as date)  ) order by t.work_order_id";

            DataSet ds1 = Utilities.SqlHelper.ExecuteDataSet(CommandType.Text, sql, null);

            if (ds1 != null && ds1.Tables.Count > 0)
            {
                SetDataToGrid(ds1.Tables[0]);
            }

            ds1 = null;
            Cursor.Current = Cursors.Default;
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
        private void gvWO_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (gvWO.SelectedCells.Count > 0)
            {
                string id = gvWO.SelectedCells[1].Value.ToString();
            }
        }
        private void gvWO_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.ColumnIndex > 0) return;
            try
            {
                var senderGrid = (DataGridView)sender;

                if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
                {
                    //DataGridViewCheckBoxCell checkbox = (DataGridViewCheckBoxCell)gvWO.CurrentCell;
                    //bool isChecked = (bool)checkbox.EditedFormattedValue;
                    //int index = checkbox.RowIndex;
                    int index = e.RowIndex;
                    obj = new clsWO();

                    //if (isChecked)
                    //{
                    DataGridViewRow row = gvWO.Rows[index];
                    //string message = row.Cells["summ"].Value.ToString();
                    obj.summary = row.Cells["summ"].Value.ToString();
                    string detail = row.Cells["detail"].Value.ToString();
                    obj.detail = detail;
                    string[] data = detail.Split('#');
                    string newDetail = "";
                    obj.WO = row.Cells["work_order_id"].Value.ToString();
                    txtGetWO.Text = obj.WO;
                    WOGet = obj.WO;

                    if (detail.Trim().Length > 0)
                    {

                        newDetail = obj.WO + Environment.NewLine;

                        for (int d = 0; d < data.Length; d++)
                        {
                            if (data[d].Trim().Length > 0)
                                newDetail += data[d] + Environment.NewLine;
                        }
                        txtWOdetail.Text = newDetail;
                    }
                    else
                    {
                        txtWOdetail.Text = "No data!" + obj.WO;

                    }

                    obj.SUBMITDATE = DateTime.Now.ToString("yyyy-MM-dd");
                    txtWOSummary.Text = obj.summary;
                    obj.plans = row.Cells["plans"].Value.ToString();


                    bool b = detail.Contains("VOID");
                    if (b)
                    {
                        int index2 = detail.IndexOf("VOID");
                        if (index2 >= 0)
                            MessageBox.Show("VOID begins at character position " + (index2 + 1).ToString());

                    }

                }


                //2019 - 02 - 01
            }
            catch (Exception)
            {
                txtGetWO.Text = "";
                txtWOSummary.Text = "";
                txtWOdetail.Text = "";
                obj = null;
                //throw;
            }



        }

        private void btnWOavailable_Click(object sender, EventArgs e)
        {
            string strA = "Available !";

            string sql = @" select isnull(request_assignee,'')  from [dbo].[WOI_WorkOrder]   WITH (NOLOCK)   where   work_order_id='" + WOGet + "'";

            Cursor.Current = Cursors.WaitCursor;
            object oo = Utilities.SqlHelper.ExecuteScalar(CommandType.Text, sql, null);
            if (!(oo != null && oo.ToString() != string.Empty))
                strA = "Not " + strA;


            Cursor.Current = Cursors.Default;
            MessageBox.Show(strA);
        }

        private void btnNotWork_Click(object sender, EventArgs e)
        {
            if (obj != null)
            {

                string sql = @"INSERT INTO [PlanEDI].[EDI].[stgAuditLog]([work_order_id],[worksta],[wantsta],[submitdate],[Summary])  VALUES('$WO','NO','NO','$A','$C')";
                sql = sql.Replace("$WO", obj.WO);
                sql = sql.Replace("$A", obj.SUBMITDATE);
                sql = sql.Replace("$C", obj.summary);
                //sql = sql.Replace("$D", obj.detail);
                string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
                int ret = Utilities.SqlHelper.ExecteNonQuery(connectionString, CommandType.Text, sql, null);
                if (ret > 0)
                {
                    MessageBox.Show("GOOD !");
                }
                else
                {
                    MessageBox.Show("Failure !");
                }


            }



        }

        private void btnWO1Compare_Click(object sender, EventArgs e)
        {
            txtPlans.Text = "";
            txtTableName.Text = "";
            string compareWO = this.txtSearchWO.Text.Trim();
            if (compareWO == "") return;

            //and t.[Status]=0  and t.request_assignee is null    
            string sql = @" select  work_order_id,RTRIM(LTRIM(t.[Summary]))  AS summ ,
replace(replace(replace(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(replace(replace(replace(replace(cast(t.Detailed_Description as varchar(Max)), char(13) + char(10),'#'), 
char(10), '#'),char(13),' '),char(9),' '),CHAR(32),'()'),')(',''),'()',CHAR(32)))),rtrim(t.Summary)+'##', ''),'Hello',''),'##','#')
   from [dbo].[WOI_WorkOrder] t WITH (NOLOCK)  where   t.Categorization_Tier_2  = 'claims'   and  work_order_id='" + compareWO + "'";

            DataSet ds1 = Utilities.SqlHelper.ExecuteDataSet(CommandType.Text, sql, null);
            obj = new clsWO();
            StringBuilder sb = new StringBuilder();

            if (ds1 != null && ds1.Tables.Count > 0)
            {
                DataTable dt1 = ds1.Tables[0];
                DataRow row = dt1.Rows[0];

                obj.WO = row["work_order_id"].ToString();
                obj.summary = row[1].ToString();
                //obj.detail=row.[2].Value.ToString();
                string detail = row[2].ToString();
                string[] data = detail.Split('#');
                //string newDetail = "";
                sb.Append(obj.WO + Environment.NewLine);
                sb.AppendLine(obj.summary);
                sb.AppendLine("--------------------------------");

                if (detail.Trim().Length > 0)
                {

                    for (int d = 0; d < data.Length - 1; d += 1)
                    {
                        //newDetail += data[d] + Environment.NewLine;
                        sb.AppendLine(data[d]);
                    }
                    //txtComp1.Text = newDetail;
                    txtComp1.Text = sb.ToString();
                }
                else
                {
                    //txtComp1.Text = "No data!" + obj.WO;
                    txtComp1.Text = sb.ToString();
                }
                sb.Clear();


                //sql = @"select t2.SP_Plan  ,'[BDU_TEMP].[EDI].[N314740_' + rtrim(t2.Work_Order_ID) + '_##' + +'_' + replace(CONVERT(VARCHAR(10), getdate(), 101), '/', '') + ']' as tablename
                //from[dbo].[AET_WOI_State_Plan_Join] t2 where  t2.Work_Order_ID = '@WO' and t2.SP_Selected = '0'";
                //sql = sql.Replace("@WO" , obj.WO);
                //const string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
                //ds1 = null;
                //ds1 = Utilities.SqlHelper.ExecuteDataSet(connectionString,CommandType.Text, sql, null);

                //if (ds1 != null && ds1.Tables.Count > 0)
                //{
                //    DataTable dt2 = ds1.Tables[0];
                //    int cnt = dt2.Rows.Count;

                //    for (int i = 0; i <cnt; i++)
                //    {
                //        Console.WriteLine(i);
                //        txtPlans.Text = txtPlans.Text + dt2.Rows[i][0].ToString() + ";";
                //        //txtTableName.Text= txtTableName.Text+ dt2.Rows[i][1].ToString() + ";";
                //    }
                //    txtPlans.Text = txtPlans.Text.TrimEnd(';');
                //    txtTableName.Text = dt2.Rows[0][1].ToString();
                //}



            }
            ds1 = null;

        }

        private void btnSummaryCompare_Click(object sender, EventArgs e)
        {

            //gvWO.DataSource = null;
            gvSummary.DataSource = null;
            gvSummary.Rows.Clear();
            gvSummary.Columns.Clear();

            string sql = @"select work_order_id,substring(Request_Assignee,0,8)  as Assignee ,Summary as summ,detail  
             from [PlanEDI].[EDI].stgVIIARLog where Summary like '%@@%' order by seq, lenDesc";

            sql = sql.Replace("@@", txtSearch.Text.Trim().Replace("'", "''"));
            string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
            DataSet ds1 = Utilities.SqlHelper.ExecuteDataSet(connectionString, CommandType.Text, sql, null);



            if (ds1 != null && ds1.Tables.Count > 0)
            {
                DataTable dt1 = ds1.Tables[0];

                DataGridViewCheckBoxColumn col = new DataGridViewCheckBoxColumn();
                //gvWO.Columns.Add(col);

                gvSummary.DataSource = dt1;

                col.HeaderText = "";
                col.Width = 50;
                col.Name = "checkCol";
                gvSummary.Columns.Insert(0, col);
                gvSummary.AutoResizeColumn(1);
                //gvSummary.AutoResizeColumn(2); 

            }

            ds1 = null;
        }

        private void gvSummary_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex > 0) return;
            try
            {
                DataGridViewCheckBoxCell checkbox = (DataGridViewCheckBoxCell)gvSummary.CurrentCell;
                bool isChecked = (bool)checkbox.EditedFormattedValue;
                int index = checkbox.RowIndex;

                DataGridViewRow row = gvSummary.Rows[index];


                string detail = row.Cells["detail"].Value.ToString();

                StringBuilder sb = new StringBuilder();
                sb.Append(row.Cells["work_order_id"].Value.ToString() + Environment.NewLine);
                sb.AppendLine(row.Cells["summ"].Value.ToString());
                sb.AppendLine("--------------------------------");

                if (detail.Trim().Length > 0)
                {
                    string[] data = detail.Split('#');
                    for (int d = 0; d < data.Length - 1; d += 1)
                    {

                        sb.AppendLine(data[d]);
                    }

                    txtComp2.Text = sb.ToString();
                }
                else
                {

                    txtComp2.Text = sb.ToString();
                }


            }
            catch (Exception ex)
            {
                txtComp2.Text = ex.Message;
            }

        }

        private void btnSearchDesc_Click(object sender, EventArgs e)
        {
            //gvWO.DataSource = null;
            gvSummary.DataSource = null;
            gvSummary.Rows.Clear();
            gvSummary.Columns.Clear();

            //and t.[Status]=0  and t.request_assignee is null   
            string sql = @"select work_order_id,substring(Request_Assignee,0,8)  as Assignee ,Summary as summ,detail   from  [EDI].stgVIIARLog where detail like '%@@%' order by SEQ,lenDesc";

            //string sql = @" select  work_order_id,RTRIM(LTRIM(t.[Summary]))  AS summ ,replace(rtrim(cast(t.Detailed_Description as varchar(max))) ,char(10),'#')  as detail                
            //            from [dbo].[WOI_WorkOrder] t WITH (NOLOCK)  where   t.Categorization_Tier_2  = 'claims'  and t.[Status]>0  and t.request_assignee='Ailing Yoon'  and t.Summary like '%@@%'";

            sql = sql.Replace("@@", txtSearch.Text.Trim().Replace("'", "''"));
            string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
            DataSet ds1 = Utilities.SqlHelper.ExecuteDataSet(connectionString, CommandType.Text, sql, null);
            if (ds1 != null && ds1.Tables.Count > 0)
            {
                DataTable dt1 = ds1.Tables[0];

                DataGridViewCheckBoxColumn col = new DataGridViewCheckBoxColumn();
                //gvWO.Columns.Add(col);

                gvSummary.DataSource = dt1;

                col.HeaderText = "";
                col.Width = 50;
                col.Name = "checkCol";
                gvSummary.Columns.Insert(0, col);
                gvSummary.AutoResizeColumn(1);
                //gvSummary.AutoResizeColumn(2); 

            }



            ds1 = null;
        }

        private void bntSendCompare_Click(object sender, EventArgs e)
        {
            this.txtSearchWO.Text = obj.WO;
            this.tabControl1.SelectedIndex = 1;
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void btnAssignMe_Click(object sender, EventArgs e)
        {
            if (obj != null)
            {

                string sql = @"INSERT INTO  [EDI].[stgAuditLog]([work_order_id],[worksta],[wantsta],[submitdate],[lenDesc],[Summary])  VALUES('$WO','PICK','YES','$A','$C')";
                sql = sql.Replace("$WO", obj.WO);
                sql = sql.Replace("$A", obj.SUBMITDATE);
                sql = sql.Replace("$C", obj.summary);
                //sql = sql.Replace("$D", obj.detail);
                const string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
                int ret = Utilities.SqlHelper.ExecteNonQuery(connectionString, CommandType.Text, sql, null);
                if (ret > 0)
                {
                    MessageBox.Show("GOOD !");
                }
                else
                {
                    MessageBox.Show("Failure !");
                }


            }

        }

        private void btnMaillist_Click(object sender, EventArgs e)
        {
            string sql = @" SELECT w.work_order_id,w.worksta as [status] ,replace(w.summary ,char(10),' ') as eSummary,w.work_order_id+ ': ' + replace(w.summary ,char(10),' ')  as eSubject ,
 	           'Hi  ' + t.First_Name +  + ',$$This request was completed in Production as requested in the instructions. Please verify and approve to close the ticket.$$Req #  : ' +  t.SRID +  '$$Thanks,$Ailing Yoon'  as eBody ,rtrim(cast(t.Internet_E_mail as varchar(200))) as  mail1,
	            case when t.WO_Type_Field_01 is null then '' else rtrim(cast(t.WO_Type_Field_01 as varchar(200))) END AS mail2,w.datalog
              FROM  [PlanEDI].[EDI].[stgAuditLog] w  join  [ARSystem].[dbo].[WOI_WorkOrder] t   on w.work_order_id=t.Work_Order_ID  where w.SUBMITDATE>=cast(getdate()-1  as date) and w.wantsta='YES' AND  w.worksta<>'MAILED'  order by w.work_order_id";


            //<br/>  --line break
            DataSet ds1 = Utilities.SqlHelper.ExecuteDataSet(CommandType.Text, sql, null);
            if (ds1 != null && ds1.Tables.Count > 0)
            {
                DataTable dt1 = ds1.Tables[0];

                this.gvMail.DataSource = dt1;
                gvMail.AutoResizeColumn(0);
                gvMail.AutoResizeColumn(1);
                //gvMail.AutoResizeColumn(2);
                //gvMail.AutoResizeColumn(3);

            }

            ds1 = null;
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (gvMail.DataSource != null && gvMail.Rows.Count > 0)
            {

                for (int i = 0; i < gvMail.Rows.Count; i++)
                {

                    if (Convert.ToBoolean(gvMail.Rows[i].Cells["check"].Value))//获取选中的
                    {
                        bool boSend = false;
                        string WO = gvMail.Rows[i].Cells["work_order_id"].Value.ToString();
                        string eSubject = gvMail.Rows[i].Cells["eSubject"].Value.ToString();
                        string eBody = gvMail.Rows[i].Cells["eBody"].Value.ToString();
                        eBody = eBody.Replace("$", "<br/>");
                        string mail1 = gvMail.Rows[i].Cells["mail1"].Value.ToString();
                        string mail2 = gvMail.Rows[i].Cells["mail2"].Value.ToString();
                        string MailTo = mail1;
                        if (mail2.Length > 0) MailTo = MailTo + ";" + mail2;

                        boSend = SendMail(MailTo, eSubject, eBody, WO);
                        MessageBox.Show("Send completed :" + boSend.ToString());
                    }
                }

            }


        }

        private bool SendMail(string ToEmail, string Subject, string Body, string WO)
        {
            string FromEmail = "YoonA@AETNA.com";
            string FromName = "Ailing Yoon";
            //string Bcc = "";
            string CC = "DL04707@AETNA.com;DL201901170609504863@AETNA.com";
            //string CC = "";
            string FromPassword = "Apple@21";


            string Attachments = "";
            string FromSMTP = "mail.aetna.com";
            int SmtpPort = 25;
            //ToEmail = "YoonA@AETNA.com";

            //Subject = "0";
            //Body = "11";
            //ToEmail = "YoonA@AETNA.com";

            try
            {
                //邮件发送类
                MailMessage mail = new MailMessage();
                //是谁发送的邮件
                mail.From = new MailAddress(FromEmail, FromName);
                mail.Sender = new MailAddress(FromEmail, FromName);

                ////密送
                //foreach (string strToBcc in Bcc.Split(';'))
                //{
                //    if (strToBcc.Length > 0)
                //    {
                //        mail.Bcc.Add(new MailAddress(strToBcc));
                //    }
                //}

                //抄送
                foreach (string strToCC in CC.Split(';'))
                {
                    if (strToCC.Length > 0)
                    {
                        mail.CC.Add(new MailAddress(strToCC));
                    }
                }


                //发送给谁

                foreach (string strToEmail in ToEmail.Split(';'))
                {
                    if (strToEmail.Length > 0)
                    {
                        mail.To.Add(strToEmail);
                    }
                }

                //标题
                mail.Subject = Subject;
                //内容编码
                mail.BodyEncoding = Encoding.Default;
                //发送优先级
                mail.Priority = MailPriority.High;
                //邮件内容
                mail.Body = Body;
                //是否HTML形式发送
                mail.IsBodyHtml = true;

                ////附件

                foreach (string strAttachment in Attachments.Split(';'))
                {
                    if (strAttachment.Length > 0)
                    {
                        mail.Attachments.Add(new Attachment(strAttachment));
                    }
                }

                //邮件服务器和端口
                SmtpClient smtp = new SmtpClient(FromSMTP, SmtpPort);
                smtp.UseDefaultCredentials = true;
                //指定发送方式
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                //指定登录名和密码
                smtp.Credentials = new NetworkCredential(FromEmail, FromPassword);

                //smtp.EnableSsl = Ssl;//SMTP 服务器要求安全连接需要设置此属性

                //超时时间
                smtp.Timeout = 100000;

                smtp.Send(mail);

                #region 异步发送
                //object userToken = mail;
                //smtp.SendAsync(mail, userToken);
                #endregion


                string sql = @"update  [EDI].[stgAuditLog] set worksta='MAILED' where work_order_id='" + WO + "'";
                string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
                int ret = Utilities.SqlHelper.ExecteNonQuery(connectionString, CommandType.Text, sql, null);


                return true;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                return false;
            }
        }

        private void btnRemedy_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            const string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
            string sql = @"INSERT INTO [PlanEDI].[EDI].[stgAuditLog]([work_order_id],[worksta],[wantsta],[submitdate], [Summary],assignToMe,detail)
             select  work_order_id,'PICK','YES' ,  cast(getdate()  as date), RTRIM(LTRIM(t.[Summary]))  , 1,
replace(replace(replace(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(replace(replace(replace(replace(cast(t.Detailed_Description as varchar(Max)), char(13) + char(10),'#'),char(10), '#'),
char(13),' '),char(9),' '),CHAR(32),'()'),')(',''),'()',CHAR(32)))),rtrim(t.summary)+'##', ''),'Hello',''),'##','#')  
   from [ARSystem].[dbo].[WOI_WorkOrder] t WITH (NOLOCK)    where   t.Categorization_Tier_2  = 'claims'  and t.[Status]=0  and t.request_assignee='Ailing Yoon'   
 and  cast( DATEADD(SECOND, t.[Submit_Date], '19700101') as date)=cast(getdate()  as date)    
 and t.work_order_id not in (select  work_order_id from   [PlanEDI].[EDI].[stgAuditLog] where  submitdate>= cast(getdate()-1  as date)) ";

            int ret = Utilities.SqlHelper.ExecteNonQuery(connectionString, CommandType.Text, sql, null);
            if (ret > 0)
            {
                sql = @"UPDATE ce  SET ce.detail = ltrim(rtrim(substring(detail, CHARINDEX('#', detail) + 1, len(detail) - CHARINDEX('#', detail))))   FROM  [EDI].[stgAuditLog]  ce  where assignToMe=1  and len(detail) >70";
                sql = sql + "  UPDATE ce  SET lenDesc=len(detail) , assignToMe=0   FROM  [EDI].[stgAuditLog]  ce  where assignToMe=1 ";
                ret = Utilities.SqlHelper.ExecteNonQuery(connectionString, CommandType.Text, sql, null);

                FillPlanToAudit();
                GC.Collect();
                MessageBox.Show("GOOD !");
            }
            else
            {
                MessageBox.Show("No data !");
            }

            Cursor.Current = Cursors.Default;

        }
        private void FillPlanToAudit()
        {
            int Ret = 0;
            IniFile iniFile = new IniFile("CONFIG.ini");
            string sql = @"select work_order_id  from  [PlanEDI].[EDI].[stgAuditLog] c where   submitdate= cast(getdate()  as date) and wantsta='YES' and  datalog is null ";
            const string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
            StringBuilder sb = new StringBuilder();
            DataSet ds2 = Utilities.SqlHelper.ExecuteDataSet(connectionString, CommandType.Text, sql, null);
            if (ds2 != null && ds2.Tables.Count > 0)
            {
                DataTable dt1 = ds2.Tables[0];
                if (dt1.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt1.Rows)
                    {
                        string WOO = dr[0].ToString();
                        string sql2 = @" select   t2.SP_Plan   from  [ARSystem].[dbo].[AET_WOI_State_Plan_Join] t2  where   t2.SP_Selected = '0' and  t2.Work_Order_ID ='" + WOO + "'";
                        DataTable dt2 = Utilities.SqlHelper.ExecuteDataSet(CommandType.Text, sql2, null).Tables[0];
                        string strPlans = "";
                        List<string> OnlyOne = new List<string>();
                        if (dt2 != null && dt2.Rows.Count > 0)
                        {
                            foreach (DataRow row in dt2.Rows)
                            {
                                //list.Add(row[0].ToString());
                                string PLANNAME = row[0].ToString();
                                string HPID = iniFile.GetString("PLAN", PLANNAME, "");
                                if (!OnlyOne.Contains(HPID))
                                {
                                    OnlyOne.Add(HPID);
                                    strPlans += HPID + ",";
                                }

                            }
                        }
                        dt2 = null;
                        if (strPlans != "")
                        {
                            strPlans = strPlans.TrimEnd(',');
                            string sql3 = "update  [PlanEDI].[EDI].[stgAuditLog] set datalog='" + strPlans + "'  where  work_order_id='" + WOO + "';";
                            sb.Append(sql3);


                        }


                    }

                    if (sb.ToString().Length > 0)
                        Ret = Utilities.SqlHelper.ExecteNonQuery(connectionString, CommandType.Text, sb.ToString(), null);

                }


            }

            ds2 = null;
            sb = null;

        }


        private void btnGetDONE_Click(object sender, EventArgs e)
        {
            //,len(replace(rtrim(cast(t.Detailed_Description as varchar(max))), char(10), '#')) as lenDesc ,     
//            string sql = @" SELECT w.work_order_id,case when w.TransExcel =1 then 'YES' ELSE 'NO' END AS EXCEL ,w.datalog as plans,replace(w.summary, char(10), ' ') as summ,     
//replace(replace(replace(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(replace(replace(replace(replace(cast(t.Detailed_Description as varchar(Max)), char(13) + char(10),'#'), 
//char(10), '#'),char(13),' '),char(9),' '),CHAR(32),'()'),')(',''),'()',CHAR(32)))),t.Summary+'##', ''),'Hello',''),'##','#')   as detail
//       FROM  [PlanEDI].[EDI].[stgAuditLog] w  join  [ARSystem].[dbo].[WOI_WorkOrder] t  WITH(NOLOCK)
//       on w.work_order_id=t.Work_Order_ID  where w.SUBMITDATE='@@@'  and t.request_assignee = 'Ailing Yoon' order by w.work_order_id";
string sql = @"  SELECT w.work_order_id,case when w.TransExcel =1 then 'YES' ELSE 'NO' END AS EXCEL ,w.datalog as plans,replace(w.summary, char(10), ' ') as summ, isnull(w.detail,'') as detail
  FROM  [PlanEDI].[EDI].[stgAuditLog] w  where w.SUBMITDATE='@@@'  AND wantsta='YES'  order by w.work_order_id";

            sql = sql.Replace("@@@", this.comboDateDone.Text);
            //<br/>  --line break
            DataSet ds1 = Utilities.SqlHelper.ExecuteDataSet(CommandType.Text, sql, null);
            if (ds1 != null && ds1.Tables.Count > 0)
            {
                SetDataToGrid(ds1.Tables[0]);
            }

            ds1 = null;

        }

        private void btnClearDescription_Click(object sender, EventArgs e)
        {
            this.txtSearch.Text = "";

        }

        private void btnPlansByWO_Click(object sender, EventArgs e)
        {
            string sWO = txtWOSetScript.Text.Trim().ToUpper();

            string sql = @"select isnull(datalog,'XX') as datalog  from  [PlanEDI].[EDI].[stgAuditLog] t2 where  t2.Work_Order_ID = '@WO'";

            //,'[N314740_' + rtrim(t2.Work_Order_ID) + '_' + isnull(datalog, 'XX') + '_' + replace(CONVERT(VARCHAR(10), getdate(), 101), '/', '') + ']' as tablename
            this.comboPlans.Items.Clear();

            sql = sql.Replace("@WO", sWO);
            const string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
            object oo = Utilities.SqlHelper.ExecuteScalar(connectionString, CommandType.Text, sql, null);
            string Plans = (string)oo;

            if (Plans.Contains(','))
            {
                string[] plan = Plans.Split(',');
                for (int i = 0; i < plan.Length; i++)
                {
                    this.comboPlans.Items.Add((object)plan[i]);
                }

            } else
            {

                this.comboPlans.Items.Add((object)Plans);
                //this.txtTableByPlans.Text = "[N314740_" + sWO + '_' + Plans + '_' + DateTime.Now.ToString("MMddYYYY") + ']';
                this.comboPlans.SelectedIndex = 0;

            }

        }

        private void comboPlans_SelectedIndexChanged(object sender, EventArgs e)
        {
            string plan = comboPlans.Text;
            this.txtTableByPlans.Text = "[N314740_" + txtWOSetScript.Text.Trim().ToUpper() + '_' + plan + '_' + DateTime.Now.ToString("MMddyyyy") + ']';
        }

        private void btnToScript_Click(object sender, EventArgs e)
        {
            this.txtWOSetScript.Text = obj.WO;
            this.tabControl1.SelectedIndex = 4;
        }

        private void gvMail_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex > 0) return;
        }

        private void btnSaveRec_Click(object sender, EventArgs e)
        {
            string var1 = txtRecItem1.Text.Trim();
            string var2 = txtRecItem2.Text.Trim();
            string var3 = txtRecDesc1.Text.Trim();
            string var4 = txtRecDesc2.Text.Trim();

            var1 = Utilities.SqlHelper.SqlFilter(var1);

            if (var2.Length > 0)
                var2 = Utilities.SqlHelper.SqlFilter(var2);

            var3 = Utilities.SqlHelper.SqlFilter(var3);

            if (var4.Length > 0)
                var4 = Utilities.SqlHelper.SqlFilter(var4);

            string sql = @"INSERT INTO [EDI].[stgLogProcessMaster]([item],[item2],[desc1],[desc2]) VALUES ('";
            sql = sql + var1 + "','" + var2 + "','" + var3 + "','" + var4 + "')";

            string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
            int ret = Utilities.SqlHelper.ExecteNonQuery(connectionString, CommandType.Text, sql, null);
            if (ret >= 0)
            {
                MessageBox.Show("GOOD !");
            }
            else
            {
                MessageBox.Show("Failure !");
            }
        }
        private void SetDataToGrid(DataTable dt)
        {
            gvWO.DataSource = null;
            gvWO.Rows.Clear();
            gvWO.Columns.Clear();


            //<br/>  --line break

            if (dt != null)
            {
                DataGridViewButtonColumn col = new DataGridViewButtonColumn();
                gvWO.DataSource = dt;
                col.HeaderText = "Click";
                col.Width = 60;
                //col.Name = "checkCol"; 

                gvWO.Columns.Insert(0, col);
                gvWO.AutoResizeColumn(1);
                gvWO.AutoResizeColumn(2);
                //gvWO.AutoResizeColumn(3);
                gvWO.Columns[4].Width = 450;
                gvWO.Columns[5].Visible = false;

            }
        }

        private void SetDataToWriteGrid(DataTable dt)
        {

            gvWrite.DataSource = null;
            gvWrite.Rows.Clear();

            if (dt != null)
            {
                //DataGridViewButtonColumn col = new DataGridViewButtonColumn();
                gvWrite.DataSource = dt;
                gvWrite.AutoResizeColumn(1);
                gvWrite.AutoResizeColumn(2);
                gvWrite.AutoResizeColumn(3);
                gvWrite.AutoResizeColumn(4);

                gvWrite.Columns[5].Visible = false;

            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            
//            string sql = @" SELECT w.work_order_id,case when w.TransExcel =1 then 'YES' ELSE 'NO' END AS EXCEL ,w.datalog as plans,replace(w.summary, char(10), ' ') as summ,       
//        replace(replace(replace(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(replace(replace(replace(replace(cast(t.Detailed_Description as varchar(Max)), char(13) + char(10),'#'), 
//char(10), '#'),char(13),' '),char(9),' '),CHAR(32),'()'),')(',''),'()',CHAR(32)))), rtrim(t.Summary)+'##', ''),'Hello',''),'##','#')   as detail 
//              FROM  [PlanEDI].[EDI].[stgAuditLog] w  join  [ARSystem].[dbo].[WOI_WorkOrder] t  WITH(NOLOCK)
//              on w.work_order_id=t.Work_Order_ID  where w.SUBMITDATE=cast(getdate() as date) and w.wantsta='YES' AND  w.worksta<>'MAILED' 
//              and t.request_assignee = 'Ailing Yoon' order by w.work_order_id";

            string sql = @"SELECT w.work_order_id,case when w.TransExcel =1 then 'YES' ELSE 'NO' END AS EXCEL ,w.datalog as plans,
  replace(w.summary, char(10), ' ') as summ,isnull(w.detail,'') as detail   FROM  [PlanEDI].[EDI].[stgAuditLog] w   where w.SUBMITDATE>=cast(getdate()-1 as date) 
  and w.wantsta='YES' AND  w.worksta<>'MAILED'   order by w.work_order_id ";


            //<br/>  --line break
            DataSet ds1 = Utilities.SqlHelper.ExecuteDataSet(CommandType.Text, sql, null);
            if (ds1 != null && ds1.Tables.Count > 0)
            {
                SetDataToGrid(ds1.Tables[0]);
            }

            ds1 = null;
        }

        private void btnCheckPlans_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            IniFile iniFile = new IniFile("CONFIG.ini");

            foreach (DataGridViewRow row in gvWO.Rows)
            {
                string WOO = row.Cells["work_order_id"].Value.ToString();

                string sql = @" select    distinct   SP_Plan   from  [ARSystem].[dbo].[AET_WOI_State_Plan_Join]   where  SP_Selected = '0' and   Work_Order_ID ='" + WOO + "'";
                DataTable dt2 = Utilities.SqlHelper.ExecuteDataSet(CommandType.Text, sql, null).Tables[0];

                List<string> OnlyOne = new List<string>();
                if (dt2 != null && dt2.Rows.Count > 0)
                {
                    string strPlans = "";
                    foreach (DataRow DR in dt2.Rows)
                    {
                        //list.Add(row[0].ToString());
                        string PLANNAME = DR[0].ToString();
                        string HPID = iniFile.GetString("PLAN", PLANNAME, "");
                        if (!strPlans.Contains(HPID))
                        {
                            strPlans += HPID + ",";

                        }

                    }
                    row.Cells["plans"].Value = strPlans.TrimEnd(',');
                }



            }
            GC.Collect();

            Cursor.Current = Cursors.Default;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string sql = @"   SELECT w.work_order_id, replace(w.summary ,char(10),' ') as eSummary, w.datalog             
  FROM  [PlanEDI].[EDI].[stgAuditLog] w  join  [ARSystem].[dbo].[WOI_WorkOrder] t   on w.work_order_id=t.Work_Order_ID  where w.SUBMITDATE=cast(getdate() as date) 
  and w.wantsta='YES' AND  w.worksta='MAILED'     order by w.datalog ";
            //<br/>  --line break
            DataSet ds1 = Utilities.SqlHelper.ExecuteDataSet(CommandType.Text, sql, null);
            if (ds1 != null && ds1.Tables.Count > 0)
            {
                DataTable dt1 = ds1.Tables[0];

                this.gvMail.DataSource = dt1;
                gvMail.AutoResizeColumn(0);
                gvMail.AutoResizeColumn(2);
                //gvMail.AutoResizeColumn(2);
                //gvMail.AutoResizeColumn(3);

            }

            ds1 = null;

        }

        private void btnDeleteWOBackLog_Click(object sender, EventArgs e)
        {
            string sql = @" DELETE  FROM  [EDI].[stgAuditLog]  where  work_order_id='" + this.txtDeleteWO.Text.Trim().ToUpper() + "' and worksta<>'MAILED'";

            string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
            int ret = Utilities.SqlHelper.ExecteNonQuery(connectionString, CommandType.Text, sql, null);
            if (ret >= 0)
            {
                MessageBox.Show("GOOD !");
            }
            else
            {
                MessageBox.Show("Failure !");
            }
        }

        private void btnTodayMailed_Click(object sender, EventArgs e)
        {
            string sql = @" SELECT w.work_order_id,case when w.TransExcel =1 then 'YES' ELSE 'NO' END AS EXCEL ,w.datalog as plans,  replace(w.summary, char(10), ' ') as summ,      
replace(replace(replace(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(replace(replace(replace(replace(cast(t.Detailed_Description as varchar(Max)), char(13) + char(10),'#'), 
char(10), '#'),char(13),' '),char(9),' '),CHAR(32),'()'),')(',''),'()',CHAR(32)))), rtrim(t.Summary)+'##', ''),'Hello',''),'##','#')   as detail
              FROM  [PlanEDI].[EDI].[stgAuditLog] w  join  [ARSystem].[dbo].[WOI_WorkOrder] t  WITH(NOLOCK)
              on w.work_order_id=t.Work_Order_ID  where w.SUBMITDATE=cast(getdate() as date) and  w.worksta='MAILED'   order by w.work_order_id";


            //<br/>  --line break
            DataSet ds1 = Utilities.SqlHelper.ExecuteDataSet(CommandType.Text, sql, null);
            if (ds1 != null && ds1.Tables.Count > 0)
            {
                SetDataToGrid(ds1.Tables[0]);
            }


            ds1 = null;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            //StringBuilder sb = new StringBuilder(); 

            //string sql = @"select st.work_order_id,st.detail  from   [PlanEDI].[EDI].stgVIIARLog st";
            //const string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";

            //DataSet ds1 = Utilities.SqlHelper.ExecuteDataSet(connectionString,CommandType.Text, sql, null);

            //if (ds1 != null && ds1.Tables.Count > 0)
            //{
            //    DataTable dt1 = ds1.Tables[0];
            //    ds1 = null;
            //    string strHeader = "insert into [EDI].[stgVIIARLogBK] (WO,vdata) values ";
            //    for (int i = 0; i < dt1.Rows.Count; i++)
            //    {
            //        DataRow dr = dt1.Rows[i];
            //        string[] data = dr[1].ToString().Split('#');
            //        string wo = dr[0].ToString();
            //        sb.Clear();
            //        if (data.Length>0)
            //        {
            //            for (int d = 0; d < data.Length ; d ++)
            //            {
            //                if (data[d].Trim().Length > 0)
            //                {
            //                    sb.Append("('" + wo + "','" + SqlHelper.SqlFilter(data[d].Trim()) + "'),");
            //                }

            //            } 
            //        }

            //        string InsertSql = strHeader + sb.ToString().TrimEnd(','); 
            //        int ret = Utilities.SqlHelper.ExecteNonQuery(connectionString, CommandType.Text, InsertSql, null);


            //    }

            //}

            //MessageBox.Show("GOOD !");

        }

        private void btnWriteOnHand_Click(object sender, EventArgs e)
        {

            string sql = @" SELECT w.work_order_id,case when w.TransExcel =1 then 'YES' ELSE 'NO' END AS EXCEL ,w.datalog as plans,Summary as summ, detail 
   FROM   [EDI].[stgAuditLog] w   where  w.SUBMITDATE=cast(getdate()  as date) and w.wantsta='YES' AND  w.worksta<>'MAILED'  order by w.work_order_id";

            //         string sql = @" SELECT w.work_order_id,case when w.TransExcel =1 then 'YES' ELSE 'NO' END AS EXCEL ,w.datalog as plans,Summary as summ, detail 
            //FROM   [EDI].[stgAuditLog] w   where  w.SUBMITDATE=cast(getdate()-3  as date) and w.wantsta='YES'    order by w.work_order_id";

            const string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
            //<br/>  --line break
            DataSet ds2 = Utilities.SqlHelper.ExecuteDataSet(connectionString, CommandType.Text, sql, null);
            if (ds2 != null && ds2.Tables.Count > 0)
            {
                SetDataToWriteGrid(ds2.Tables[0]);
            }

            ds2 = null;
        }
        private String GetQNXT(string HPID)
        {
            string qnxt = "";
            switch (HPID)
            {
                case "OH":
                    qnxt = "plandata_QNXT_OHIO";
                    break;
                case "TX":
                    qnxt = "plandata_QNXT_TXMS";
                    break;
                default:
                    qnxt = "plandata_QNXT_" + HPID.ToUpper().Trim();
                    break;
            }

            return qnxt;

        }
        private void btnWrite_Click(object sender, EventArgs e)
        {
            IniFile iniFile = new IniFile("CONFIG.ini");

            string strDate = DateTime.Today.ToString("MMddyyyy");
           
            if (this.gvWrite.Rows.Count > 0)
            { 
                for (int i = 0; i < gvWrite.Rows.Count; i++)
                {
                   
                    if (Convert.ToBoolean(this.gvWrite.Rows[i].Cells["SEL"].Value))//获取选中的
                    {
                     

                        string HPID2 = this.gvWrite.Rows[i].Cells["plans"].Value.ToString();
                        string WO = this.gvWrite.Rows[i].Cells["work_order_id"].Value.ToString();
                        string summary = this.gvWrite.Rows[i].Cells["summ"].Value.ToString();
                        string detail = this.gvWrite.Rows[i].Cells["detail"].Value.ToString();

                        string[] arr = new string[] { };
                        var HPID_list = new List<string>();
                        if (HPID2.Contains(","))
                        {
                            arr = HPID2.Split(',');
                            foreach (string s in arr)
                            {

                                if (s.Trim().Length > 0)
                                    HPID_list.Add(s);
                            }

                        } else
                        {

                            HPID_list.Add(HPID2);
                        }

                        foreach (string HPID in HPID_list) // Loop through List with foreach
                        {
                            StringBuilder sb = new StringBuilder();
                            string QNXTDB = GetQNXT(HPID);
                            string PRODUCTION = iniFile.GetString("PRODUCTION", HPID, "");

                            sb.AppendLine("----" + PRODUCTION); 
                            sb.AppendLine("/*");
                            sb.AppendLine("WO#   : " + WO);
                            sb.AppendLine("plans : " + HPID);
                            sb.AppendLine("NID   : N314740");
                            sb.AppendLine("Date  : " + strDate);
                            sb.Append("Title :" + summary + Environment.NewLine);
                            string[] data = detail.Split('#');

                            sb.AppendLine("***Description :----------------------------------------------------------------");
                            sb.AppendLine("");
                            if (detail.Trim().Length > 0)
                            {
                                for (int d = 0; d < data.Length; d++)
                                {
                                    if (data[d].Trim().Length > 0)
                                        sb.Append(data[d] + Environment.NewLine);
                                }
                            }
                            else
                            {
                                sb.Append(detail + Environment.NewLine);
                            }
                            sb.AppendLine("***End Description  -----------------------------------------------------------");
                            sb.AppendLine("*/");

                            summary = summary.ToUpper();
                            string strExcel = "N314740_" + WO + "_" + HPID + "_" + strDate;

                            if (summary.Contains("BDU - MOVE TO C13") || summary.Contains("BDU- VLOOPKUP") || summary.Contains("MOVE CLAIMS TO C13"))
                            {
                                sb.Append(clsExcelCheck.cExcelCheck);
                                clsMoveC13 o13 = new clsMoveC13();
                                sb.Append(o13.clsMoveToC13);
                                sb.Append(new clsTab_Claim().claimStatusToOPEN); 

                            }
                            else if (summary.Contains("UB PROVIDER WATCH SET EDIT 111 TO OK"))
                            {
                                sb.Append(clsExcelCheck.cExcelCheck); 
                                sb.Append(new clsTab_claimpendhistory().Update_913_PEND);
                                sb.Append(new clsTab_Claim().SetToOPEN_forPend_111);
                                string OKEDIT = new clsTab_Claimedit().OKAY_EDIT_forPEND_Status;
                                OKEDIT = OKEDIT.Replace("##", "'111'");
                                sb.Append(OKEDIT);
                                string strMEMO = clsMemo.AddMemoWithNID_NoJoin_FixMessage;
                                strMEMO = strMEMO.Replace("#ME", "Correct Provider Id loaded … Provider on Watch.");
                                strMEMO = strMEMO.Replace("#MO", "Claim Memo");
                                sb.Append(strMEMO);
                                sb.Append(clsMemo.ExecuteMemo);

                            }
                            else if (summary.Contains("CLAIMS BDU - MOVE TO C62"))
                            {
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.Append(new clsTab_Claimedit().PEND913_claimline_0);
                                sb.Append(new clsTab_claimpendhistory().overrider_913_claimline0);
                                sb.Append(new clsSpecial1().memo01);
                                sb.Append(clsMemo.TermMemo);
                                sb.Append(clsMemo.AddMemoWithNID_JoinExist);
                                sb.Append(new clsTab_Claim().claimStatusToOPEN);
                                sb.Append(clsMemo.ExecuteMemo);

                            }
                            else if (summary.Contains("DIALYSIS BDU TO DENY WITH REMIT CODE 97"))
                            {
                                sb.AppendLine("----!!FixMessage--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.AppendLine("USE  @QNXT");
                                clsTab_Claimedit edits = new clsTab_Claimedit();
                                string Deny915=edits.Deny915_Reason97_servcode_revcode;
                                Deny915 = Deny915.Replace("$$$", "08%").Replace("###", "'J0604','J0606'"); 
                                sb.Append(Deny915);                     
                                sb.Append(new clsTab_claimpendhistory().overrider_913_claimline0_OnlyUpdate);
                                sb.Append(edits.OKAY_EDIT_913);
                                sb.Append(new clsTab_Claim().claimStatusToOPEN); 
                      
                                string strMEMO = clsMemo.AddMemoWithNID_NoJoin_FixMessage;
                                strMEMO = strMEMO.Replace("#ME", "BDU DENY Dialysis Ancillary Lines 0");
                                strMEMO = strMEMO.Replace("#MO", "BDU DENY Dialysis Ancillary Lines 0");
                                sb.Append(strMEMO);
                                sb.Append(clsMemo.ExecuteMemo); 

                            }
                            else if (summary.Contains("NJ C96 REPORT"))
                            {
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.AppendLine("USE  @QNXT");
                                sb.Append(new clsTab_Claimedit().PEND913_claimline_0);
                                string str96=new clsTab_claimpendhistory().Rule913_claimline0_FixReasonid;
                                str96 = str96.Replace("##", "'C96'");
                                sb.Append(str96);                               
                                sb.Append(clsMemo.UpdateExistMemoWithNID.Replace("tem.excel_desc","'C96'"));
                                sb.Append(clsMemo.TermMemo);
                                sb.Append(new clsTab_Claim().claimStatusToPEND);
                                sb.Append(clsMemo.AddMemoWithNID_JoinExist.Replace("tem.excel_desc", "'C96'"));
                                sb.Append(clsMemo.ExecuteMemo);

                            } 
                            else if (summary.Contains("BPENDS TO C13"))
                            {
                                sb.AppendLine("---!!!replace description in where for update memo, and SET m.description = 'C13 ' + CAST(m.description AS varchar(MAX))");
                                sb.AppendLine("---!!!replace description to C13 when insert memo");
                                sb.AppendLine("---!!!PLEASE MANUAL DO tab 2 script");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.AppendLine("USE  @QNXT");
                                sb.Append(new clsTab_Claimedit().PEND913_claimline_0);
                                sb.Append(new clsTab_claimpendhistory().overrider_913_claimline0);
                                sb.Append(clsMemo.UpdateExistMemoHasNID_forAllExistMemo);
                                sb.Append(new clsTab_Claim().claimStatusToPEND);
                                //sb.Append(new clsTab_Claimedit().OKAY_EDIT_forPEND_Status);  
                                sb.Append(clsMemo.AddMemoWithNID_JoinExist);
                                sb.Append(clsMemo.ExecuteMemo);
                              

                            }
                            else if (summary.Contains("ATTRIBUTE") && summary.Contains("ADD") && summary.Contains("VA"))
                            {
                                sb.AppendLine("---No Need for  Finalized status claims cleanup!!!!");
                                clsClaimAttribute clsObj = new clsClaimAttribute();
                                sb.Append(clsObj.Add_Update_Attribute);
                                sb.Append(clsMemo.UpdateExistMemoNoNID);
                                sb.Append(clsMemo.TermMemo);
                                sb.Append(clsMemo.AddMemoNoNID_JoinExist);
                                sb.Append(clsMemo.ExecuteMemo);
                                

                            }
                            else if (summary.Contains("MMIC EDIT 101 AND NO PROVIDER ALIGNMENT BY HP"))
                            {
                                sb.AppendLine("----!!FixMessage--");
                                sb.AppendLine("----!!replace clm.provid = '##', clm.affiliationid = '##'--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                string strPendHist = new clsTab_claimpendhistory().Update_913_PEND ;
                                strPendHist = strPendHist.Replace("--AND", " AND ");
                                string strOKEdit = new clsTab_Claimedit().OKAY_EDIT_forPEND_Status;
                                strOKEdit = strOKEdit.Replace("##", "'913','101'"); 
                                sb.Append(strPendHist);
                                sb.Append(strOKEdit);
                                sb.Append(new clsTab_Claim().provid_affilationid);  
                                sb.Append(clsMemo.AddMemoWithNID_NoJoin_FixMessage);
                                sb.Append(clsMemo.ExecuteMemo); 

                            }
                            else if (summary.Contains("ENROLL") && summary.Contains("FLIP"))
                            {
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.AppendLine("USE  @QNXT");
                                clsEnrollFlip clsObj = new clsEnrollFlip();
                                sb.Append(clsObj.strEnrollFlip);
                                sb.Append(clsMemo.AddMemoNoNID_NoJoin);
                                sb.Append(clsMemo.ExecuteMemo);
                              

                            }
                            else if (summary.Contains("ITWR-") && summary.Contains("PEND"))
                            {
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.Append(new clsTab_Claimedit().PEND913_claimline_0);
                                sb.Append(new clsTab_claimpendhistory().overrider_913_claimline0);
                                sb.Append(new clsTab_Claim().claimStatusToPEND);
                                sb.Append(clsMemo.UpdateExistMemoHasNID_forAllExistMemo);
                                sb.Append(clsMemo.AddMemoWithNID_JoinExist);
                                sb.Append(clsMemo.ExecuteMemo);
                               

                            }
                            else if (summary.Contains("EDI NDC REPORT")  || summary.Contains("PM NDC REPORT"))
                            {
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.AppendLine("USE  @QNXT");
                                sb.Append(new clsTab_Claimedit().InsertDeny915);
                                sb.Append(new clsTab_Claim().claimStatusToOPEN);
                                sb.Append(clsMemo.AddMemoNoNID_NoJoin);
                                sb.Append(clsMemo.ExecuteMemo);                                 

                            }
                            else if (summary.Contains("NJ VACCINES FOR PLAN A MEMBERS") )
                            {
                                
                                sb.AppendLine("----!!Fix Memo Message--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.AppendLine("USE  @QNXT");
                                sb.Append(new clsTab_claimdetail().usemanualcontractprice);
                                sb.Append(new clsTab_Claim().claimStatusToOPEN);
                                sb.Append(clsMemo.AddMemoWithNID_NoJoin_FixMessage);
                                sb.Append(clsMemo.ExecuteMemo);

                            }
                            else if (summary.Contains("VA C96"))
                            {
                                 
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.AppendLine("USE  @QNXT");                             
                                sb.Append(new clsTab_Claimedit().PEND913_claimline_0);
                                sb.Append(new clsTab_claimpendhistory().Pend_claim_toSomething.Replace("##","'C96'"));
                                sb.Append(clsMemo.UpdateExistMemoWithNID.Replace("tem.excel_desc", "'C96'"));
                                sb.Append(new clsTab_Claim().claimStatusToOPEN);
                                sb.Append(clsMemo.AddMemoWithNID_JoinExist.Replace("tem.excel_desc", "'C96'"));
                                sb.Append(clsMemo.ExecuteMemo);

                            }
                            else if (summary.Contains("FL H-PEND MOVE TO C-PEND"))
                            {
                                string strKey = string.Empty;
                                if (detail.Contains("C62"))
                                    strKey = "'C62'";
                                else
                                    strKey = "'C13'";
                              
                                sb.AppendLine("----!!m.description LIKE 'H01%'--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.AppendLine("USE  @QNXT");
                                sb.Append(new clsTab_Claimedit().PEND913_claimline_0);
                                sb.Append(new clsTab_claimpendhistory().overrider_913_claimline0.Replace("##", strKey));
                                sb.Append(clsMemo.UpdateExistMemoHasNID_forAllExistMemo.Replace("tem.excel_desc", strKey));
                                sb.Append(new clsTab_Claim().claimStatusToPEND); 
                                sb.Append(clsMemo.AddMemoWithNID_JoinExist.Replace("tem.excel_desc", strKey));
                                sb.Append(clsMemo.ExecuteMemo);

                            }
                            else if (summary.Contains("DENY 226, N705, N202, DSA"))
                            {
                                sb.AppendLine("----!!Fix Memo Message--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.AppendLine("USE  @QNXT");
                                sb.Append(new clsTab_Claimedit().ClearAllEdit);
                                sb.Append(new clsTab_Claimedit().Update_primary_DSA);
                                sb.Append(new clsTab_claimeditmessage().Remit226_N705_N202);                          
                                sb.Append(new clsTab_Claim().claimStatusToOPEN);

                                string strMEMO = clsMemo.AddMemoWithNID_NoJoin_FixMessage;
                                strMEMO = strMEMO.Replace("#ME", "Memo-per SIU deny with DSA");
                                strMEMO = strMEMO.Replace("#MO", "Memo-per SIU deny with DSA");
                                sb.Append(strMEMO);
                                sb.Append(clsMemo.ExecuteMemo);

                            }
                            else if (summary.Contains("DELINK"))
                            {
                                sb.Append(new clsDelink().sDelink);
                               
                            }
                            else if (summary.Contains("ALTCS SNF ISLTC"))
                            {
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.Append(new clsTab_Claim().StatusToOPEN_ISLTC);
                            }
                            else if (summary.Contains("UB LOAD ERROR CLAIMS"))
                            {
                                sb.AppendLine("----!!FixMessage--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.Append(new clsTab_Claim().provid_affilationid);
                                sb.Append(new clsTab_Claimedit().OKAY_PEND_and111);
                                string strMEMO = clsMemo.AddMemoWithNID_NoJoin_FixMessage;
                                if (detail.Contains("CRQ number assigned to this ITWR"))
                                {
                                    strMEMO = strMEMO.Replace("#MO", WO);
                                }
                                sb.Append(strMEMO);

 
                                sb.Append(clsMemo.ExecuteMemo);
                              

                            }                    
                            else if (summary.Contains("MC EDIT 376 ADD CONDITION"))
                            {
                                sb.AppendLine("----!!FixMessage--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.Append(new clsTab_claimcond().UpdateClaimcond);
                                sb.Append(new clsTab_Claim().OPEN_eobreceived);
                                sb.Append(clsMemo.AddMemoWithNID_NoJoin_FixMessage);
                                sb.Append(clsMemo.ExecuteMemo);
                                

                            }
                            else if (summary.Contains("EDI PAY TO SELECTION ERRORS"))
                            {

                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.Append(new clsTab_Claimedit().PEND913_claimline_0);
                                sb.Append(new clsTab_claimpendhistory().overrider_913_claimline0);
                                sb.Append(new clsTab_Claim().claimStatusToPEND);
                                sb.Append(clsMemo.UpdateExistMemoWithNID);
                                sb.Append(clsMemo.TermMemo);
                                sb.Append(clsMemo.AddMemoWithNID_JoinExist);
                                sb.Append(clsMemo.ExecuteMemo);
                                


                            }
                            else if (summary.Contains("C70 SWEEP"))
                            {
                                
                                sb.AppendLine("----!!replace ruleid for OK EDIT--");
                                sb.AppendLine("----!!check excel_desc and excel_message is exist or not--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.AppendLine("USE  @QNXT");
                                sb.Append(new clsTab_claimpendhistory().Update_913_PEND);
                                sb.Append(new clsTab_Claimedit().OKAY_EDIT);
                                sb.Append(new clsTab_Claim().claimStatusToPEND);
                                sb.Append(clsMemo.UpdateExistMemoNoNID);
                                sb.Append(new clsTab_Claim().claimStatusToOPEN);
                               
                            }
                            else if (summary.Contains("OVERRIDE TIMELY FILING SWEEP"))
                            {
                                
                                sb.AppendLine("----!!!replace claimedit.ruleid--");
                                sb.AppendLine("----!!FixMessage--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.AppendLine("USE  @QNXT");
                                sb.Append(new clsTab_Claimedit().OKAY_EDIT);
                                sb.Append(new clsTab_Claim().claimStatusToOPEN);
                                sb.Append(clsMemo.AddMemoWithNID_NoJoin_FixMessage);
                                sb.Append(clsMemo.ExecuteMemo);
                                
                            }
                            else if (summary.Contains("ALTCS AUTH EDITS TO OKAY"))
                            {
                                sb.AppendLine("----!!FixMessage--");
                                sb.AppendLine("----!!REPLACE RULE ID IN OKAY_EDIT--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.AppendLine("USE  @QNXT");
                                string strOKEDIT = new clsTab_Claimedit().OKAY_EDIT;
                                strOKEDIT = strOKEDIT.Replace("##", "'602','609','610','611','612','603'");
                                sb.Append(strOKEDIT);
                                sb.Append(new clsTab_claimdetail().payasprimary);
                                sb.Append(new clsTab_Claim().OPEN_eobreceived);
                                string strMEMO = clsMemo.AddMemoWithNID_NoJoin_FixMessage;
                                strMEMO = strMEMO.Replace("#ME", "Overriding these edits to expedite claims processing turn around time Mercy is primary on these services and auths that are in medreview are due to an issue with Dynamo transfers into QNXT.");
                                strMEMO = strMEMO.Replace("#MO", "BDU to OKAY auth Edits");

                                sb.Append(strMEMO);
                                sb.Append(clsMemo.ExecuteMemo); 

                            }
                            else if (summary.Contains("EDIT 837"))
                            {
                                sb.AppendLine("----!!FixMessage--");
                                sb.AppendLine("----!!replace description for TermAllMemo--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.Append(new clsTab_Claimedit().ClearEdit_forPEND_913);
                                sb.Append(new clsTab_Claimedit().OKAY_EDIT_for837);                    
                                sb.Append(new clsTab_Claim().OPEN_eobreceived);
                                sb.Append(clsMemo.TermAllMemo_WithoutExisting);
                                sb.Append(clsMemo.AddMemoWithNID_NoJoin_FixMessage);
                                sb.Append(clsMemo.ExecuteMemo); 
                            }
                            else if (summary.Contains("205 SWEEP"))
                            {
                                sb.AppendLine("----!!this is for FL , if other 205 SWEEP , you need to compare script--");
                                sb.AppendLine("----!!Edit 913 to first  OKAY statement--");
                                sb.AppendLine("----!!check the ruleid and claimline column name in 2 OKAY--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.Append(new clsTab_Claimedit().OKAY_EDIT);
                                sb.Append(new clsTab_Claimedit().OKAY_EDIT_at_EXCEL_Ruleid_Claimline);                                
                                sb.Append(clsMemo.UpdateExistMemoWithNID); 
                                sb.Append(clsMemo.AddMemoWithNID_JoinExist);
                                sb.Append(clsMemo.ExecuteMemo);
                                sb.Append(new clsTab_Claim().claimStatusToOPEN);
                      

                            }
                            else if (summary.Contains("SETTLEMENT"))
                            {
                                clsClaimAttribute clsObj = new clsClaimAttribute();
                                sb.Append(clsObj.NotAdjust_Settlement);
                                
                            }
                            else if (summary.Contains("BDU TO DENY RC 97"))
                            {
                                sb.AppendLine("----!!FixMessage--");
                                string strAA = new clsTab_Claimedit().Deny915_Reason97_RevcodeNotLike;
                                strAA = strAA.Replace("@REVCODE", "08");
                                strAA = strAA.Replace("@reasonID", "97");
                                string strBB = new clsTab_claimpendhistory().Update_PassRuleid;
                                strBB = strBB.Replace("@RULEID", "913");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.Append(strAA);
                                sb.Append(strBB);
                                sb.Append(new clsTab_Claim().claimStatusToOPEN);
                                sb.Append(clsMemo.AddMemoWithNID_NoJoin_FixMessage);
                                sb.Append(clsMemo.ExecuteMemo);
                                

                            }
                            else if (summary.Contains("ALTCS ENROLLMENT REPORT") || summary.Contains("SNF ENROLLMENT"))
                            {
                                sb.AppendLine("----!!FixMessage--");
                                sb.AppendLine("----!!enrollid,isltc--"); 
                                sb.Append(clsExcelCheck.cExcelCheck); 
                                sb.Append(new clsTab_Claim().OPEN_enrollid_isltc);
                                sb.Append(clsMemo.AddMemoWithNID_NoJoin_FixMessage);
                                sb.Append(clsMemo.ExecuteMemo);
                            }
                            else if (summary.Contains("ATTRIBUTE DELETE"))
                            {                      
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.Append(new clsClaimAttribute().Delete_CLAIMATTRIBUTE);                  
                            }
                            else if (summary.Contains("PSEUDO ID MEMBERS"))
                            {
                                sb.AppendLine("----!!FixMessage--");
                                sb.AppendLine("----!!OKAY EDIT WITH MANY ruleids --");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.Append(new clsTab_Claimedit().OKAY_EDIT);
                                sb.Append(new clsTab_claimpendhistory().Update_913_NoStatus_Noclaimline);
                                sb.Append(new clsTab_Claim().claimStatusToOPEN);
                                sb.Append(clsMemo.AddMemoWithNID_NoJoin_FixMessage);
                                sb.Append(clsMemo.ExecuteMemo);
                            }
                            else if (summary.Contains("MULTIPLE PLANS REMIT COMMENTS BDU"))
                            {
                                sb.AppendLine("----!!Remit comment from excel--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.Append(new clsTab_insertremit().Remit1);
                                sb.Append(new clsTab_insertremit().ExecuteRemit);


                            }
                            else if (summary.Contains("REMIT 23"))
                            {
                                sb.AppendLine("----!!Fix Remit Message--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.Append(new clsTab_insertremit().Remit_23);
                                sb.Append(new clsTab_insertremit().ExecuteRemit);

                            }
                            else if (summary.Contains("ITWR MMIC NDC EDI DENY LINES"))
                            {

                                sb.AppendLine("----!!OK edit rule id 913--");
                                sb.AppendLine("----!!Terminate claimmemo.description like !!! '%C14%'--");
                                sb.AppendLine("----!!FixMessage--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.Append(new clsTab_Claimedit().InsertDeny915);
                                sb.Append(new clsTab_Claimedit().OKAY_EDIT);
                                sb.Append(new clsTab_claimpendhistory().Update_913_NoStatus_Noclaimline);
                                sb.Append(new clsTab_Claim().claimStatusToOPEN);
                                sb.Append(clsMemo.TermAllMemo_WithoutExisting);
                                sb.Append(clsMemo.AddMemoWithNID_NoJoin_FixMessage);
                                sb.Append(clsMemo.ExecuteMemo);
                            }                          
                            else if (summary.Contains("ITWR MCRP NDC VALIDATION") )
                            {
                                sb.AppendLine("----!!Fix Pendreasonid--");
                                sb.AppendLine("----!!ADD  AND clm.status IN ('OPEN','PAY') , for the Claim status to PEND--");
                                
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.AppendLine("USE  @QNXT");
                                sb.Append(new clsTab_Claim().claimStatusToPEND_ifStatus);
                                sb.Append(new clsTab_Claimedit().PEND913_claimline_0);
                                sb.Append(new clsTab_claimpendhistory().Rule913_claimline0_FixReasonid);                             
                                sb.Append(clsMemo.AddMemoNoNID_NoJoin);
                                sb.Append(clsMemo.ExecuteMemo);
                                sb.AppendLine("---UPDATE COL D claimid--");
                                string col_d_toREVSYNCH = @"
SELECT clm.* INTO BDU_Temp.EDI.[@EXCEL_CLM2]
FROM @QNXT..claim clm (NOLOCK) JOIN BDU_Temp.EDI.[@EXCEL] tem 
ON clm.claimid = tem.col_d WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

UPDATE clm SET clm.status = 'REVSYNCH'
FROM @QNXT..claim clm (NOLOCK) JOIN BDU_Temp.EDI.[@EXCEL] tem 
ON clm.claimid = tem.col_d  WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 

SELECT clm.status, COUNT(*), COUNT(DISTINCT clm.claimid)
FROM @QNXT..claim clm (NOLOCK) JOIN BDU_Temp.EDI.[@EXCEL] tem 
ON clm.claimid = tem.col_d WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status";
                                sb.Append(col_d_toREVSYNCH);

                            }
                            else if (summary.Contains("H99 CLAIMS TO OPEN"))
                            {
                                
                                sb.AppendLine("----!!replace ruleie 913 to OKAY_EDIT_forPEND_Status--");
                                sb.AppendLine("----!! in term all memo :add  a.description LIKE 'H99%'    OR a.description LIKE 'B05%' OR a.description LIKE 'B06%");
                                sb.AppendLine("----!!FixMessage--");

                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.AppendLine("USE  @QNXT");
                                sb.Append(new clsTab_Claimedit().H99_CLAIMS); 
                                sb.Append(new clsTab_claimpendhistory().Update_913_NoStatus_Noclaimline);
                                sb.Append(new clsTab_Claimedit().OKAY_EDIT_forPEND_Status);
                                sb.Append(clsMemo.TermAllMemo_WithoutExisting);
                                sb.Append(clsMemo.AddMemoWithNID_NoJoin_FixMessage);
                                sb.Append(clsMemo.ExecuteMemo);
                                sb.Append(new clsTab_Claim().claimStatusToOPEN);

                            }
                            else if (summary.Contains("SET TO OPEN"))
                            {

                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.AppendLine("USE  @QNXT");
                                string okEDIT = new clsTab_Claimedit().OKAY_EDIT;
                                okEDIT = okEDIT.Replace("##", "'913'");
                                sb.Append(okEDIT);
                                sb.Append(new clsTab_Claim().claimStatusToOPEN);

                            }
                            else
                            {

                                sb.AppendLine("----!!Total Script--");
                                sb.AppendLine("----!!Total Script--");
                                sb.AppendLine("----!!Total Script--");
                                sb.Append(clsExcelCheck.cExcelCheck);
                                sb.Append(clsScript.cString);
                                
                            }

                            PushToLog(sb.ToString(), QNXTDB, strExcel, WO, HPID);
                            sb = null; 

                        }




                    }
                }

            }

            MessageBox.Show("Write completed !");


        }
        private void  PushToLog(string LogData,string QNXT, string TableName, string WO,string HPID)
        {
             string sData =LogData.Replace("@QNXT",QNXT).Replace("@EXCEL",TableName).Replace("@WO", WO);         
             string strFileName = WO + "_" + HPID;
             string FilePath = @"C:\Users\n314740\Downloads\LogExcel\" + strFileName+".sql";
              if (File.Exists(FilePath)) File.Delete(FilePath);
              System.Threading.Thread.Sleep(400);
              LogUtility.Log(sData, LogType.SQL, strFileName);

        }

        private void tabPage7_Click(object sender, EventArgs e)
        {

        }

        private void btnShowOlder_Click(object sender, EventArgs e)
        {
            string oldsql = @" SELECT  replace(replace(replace(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(replace(replace(replace(replace(cast(t.Detailed_Description as varchar(Max)), char(13) + char(10),'#'), 
char(10), '#'),char(13),' '),char(9),' '),CHAR(32),'()'),')(',''),'()',CHAR(32)))),rtrim(t.summary)+'##', ''),'Hello',''),'##','#')  as detail 
     from [ARSystem].[dbo].[WOI_WorkOrder] t WITH (NOLOCK)   WHERE  work_order_id='" + this.txtOlderWO.Text.Trim().ToUpper() + "'";

            string detail = string.Empty;

            object  objDetail = Utilities.SqlHelper.ExecuteScalar(CommandType.Text, oldsql, null);
            if (objDetail !=null)
                detail = objDetail.ToString().Trim();
            StringBuilder sb1 = new StringBuilder();
             
            if (detail.Length > 0)
            {
                string[] data = detail.Split('#');
                for (int d = 0; d < data.Length - 1; d += 1)
                {

                    sb1.AppendLine(data[d]);
                }

                txtComp2.Text = sb1.ToString();
            }
            else
            {
                txtComp2.Text = sb1.ToString();
            }


        }
    }
}
