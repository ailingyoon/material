﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        #region 写文件
        /****************************************
         * 函数名称：WriteFile
         * 功能说明：当文件不存时，则创建文件，并追加文件
         * 参    数：Path:文件路径,Strings:文本内容
         * 调用示列：
         *           string Path = Server.MapPath("Default2.aspx");       
         *           string Strings = "这是我写的内容啊";
         *           DotNet.Utilities.FileOperate.WriteFile(Path,Strings);
        *****************************************/
        /// <summary>
        /// 写文件
        /// </summary>
        /// <param name="Path">文件路径</param>
        /// <param name="Strings">文件内容</param>
        public static void WriteFile(string Path, string Strings)
        {

            if (!System.IO.File.Exists(Path))
            {
                System.IO.FileStream f = System.IO.File.Create(Path);
                f.Close();
                f.Dispose();
            }
            System.IO.StreamWriter f2 = new System.IO.StreamWriter(Path, true, System.Text.Encoding.UTF8);
            f2.WriteLine(Strings);
            f2.Close();
            f2.Dispose();


        }
        #endregion
        public static void FileDel(string Path)
        {
            File.Delete(Path);
        }
        #region 追加文件
 
        public static void FileAdd(string Path, string strings)
        {
            StreamWriter sw = File.AppendText(Path);
            sw.Write(strings);
            sw.Flush();
            sw.Close();
            sw.Dispose();
        }
        #endregion
        static DataTable GetTable()
        {
            // Here we create a DataTable with four columns.
            DataTable table = new DataTable();
            table.Columns.Add("Dosage", typeof(int));
            table.Columns.Add("Drug", typeof(string));
            table.Columns.Add("Patient", typeof(string));
            table.Columns.Add("Date", typeof(DateTime));

            // Here we add five DataRows.
            
            table.Rows.Add(25, "Indocin", "David", DateTime.Now);
            table.Rows.Add(50, "Enebrel", "Sam", DateTime.Now);
            table.Rows.Add(10, "Hydralazine", "Christoff", DateTime.Now);
            table.Rows.Add(21, "Combivent", "Janet", DateTime.Now);
            table.Rows.Add(100, "Dilantin", "Melanie", DateTime.Now);
            table.Rows.Add(25, "Indocin", "David", DateTime.Now);
            table.Rows.Add(50, "Enebrel", "Sam", DateTime.Now);
            table.Rows.Add(10, "Hydralazine", "Christoff", DateTime.Now);
            table.Rows.Add(21, "Combivent", "Janet", DateTime.Now);
            table.Rows.Add(100, "Dilantin", "Melanie", DateTime.Now);
            table.Rows.Add(25, "Indocin", "David", DateTime.Now);
            table.Rows.Add(50, "Enebrel", "Sam", DateTime.Now);
            table.Rows.Add(10, "Hydralazine", "Christoff", DateTime.Now);
            table.Rows.Add(21, "Combivent", "Janet", DateTime.Now);
            table.Rows.Add(100, "Dilantin", "Melanie", DateTime.Now);
            return table;
        }
        public static void FileMove(string OrignFile, string NewFile)
        {
            File.Move(OrignFile, NewFile);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            string filename = @"test.txt";
            string filepath = System.IO.Directory.GetCurrentDirectory()  +"\\" + filename;
            FileDel(filepath);
           

            //DataTable dt = GetTable();

            StringBuilder sb = new StringBuilder();

       
            DataTable dt1 = GetTable();
            for (int j = 0; j < dt1.Columns.Count; j++)
            {
                sb.Append(dt1.Columns[j].ColumnName.ToString() + "|");
            }
            WriteFile(filepath, sb.ToString().TrimEnd('|'));
       
            int indoxOfLast = dt1.Columns.Count - 1;
            sb.Clear();

            StreamWriter sw = File.AppendText(filepath);
            for (int i = 0; i < 2000; i++)
            {
                sb.Clear();
                DataTable dt = GetTable();
       
                foreach (DataRow dr in dt.Rows)
                {
                    //sb.Append(dr[0].ToString() + "|" + dr[1].ToString() + "|" + dr[2].ToString() + "|" + dr[3].ToString() + "\r\n");
                    for (int j = 0; j <indoxOfLast ; j++)
                    {
                        sb.Append(dr[j].ToString() + "|");
                    }
                    sb.Append(dr[indoxOfLast].ToString() + "\r\n");
                }
                sw.Write(sb.ToString());
                sw.Flush();

            }
            sw.Close();
            sw.Dispose();

            string NewPath = @"C:\Log\" + filename; 
            File.Copy(filepath, NewPath, true);
            FileDel(filepath);
            //WriteFile(filepath, sb.ToString().TrimEnd('|'));

            //foreach (DataRow dr in dt.Rows)
            //{
            //    sb.Append(dr[0].ToString() + "|" + dr[1].ToString() + "|" + dr[2].ToString() + "|" + dr[3].ToString()  + "\r\n");
            //}

            //FileAdd(filepath, sb.ToString());


        }
    }
}
