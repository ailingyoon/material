USE [QA2]
GO

/****** Object:  Table [dbo].[TempCCD_AthenaHealth]    Script Date: 1/7/2019 9:11:13 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TempCCD_AthenaHealth](
	[data_source] [varchar](50) NULL,
	[emr_generated_date_time] [varchar](50) NULL,
	[record_ID] [varchar](50) NULL,
	[file_row_number] [varchar](50) NULL,
	[file_ID] [varchar](50) NULL,
	[submitter_TIN] [varchar](50) NULL,
	[submitter_ID] [varchar](50) NULL,
	[member_last_name] [varchar](50) NULL,
	[member_first_name] [varchar](50) NULL,
	[member_middle_name] [varchar](50) NULL,
	[member_gender] [varchar](50) NULL,
	[member_date_of_birth] [varchar](50) NULL,
	[encounter_ID] [varchar](50) NULL,
	[carrier_member_ID] [varchar](50) NULL,
	[QNXT_member_ID] [varchar](50) NULL,
	[employment_status] [varchar](50) NULL,
	[guarantor_marital_status_code] [varchar](50) NULL,
	[living_dependency] [varchar](50) NULL,
	[ambulatory_status] [varchar](50) NULL,
	[citizenship] [varchar](50) NULL,
	[religion] [varchar](50) NULL,
	[nationality] [varchar](50) NULL,
	[primary_language] [varchar](50) NULL,
	[member_ethnic_group] [varchar](50) NULL,
	[guarantor_handicap_code] [varchar](50) NULL,
	[guarantor_race] [varchar](50) NULL,
	[race] [varchar](50) NULL,
	[member_marital_status] [varchar](50) NULL,
	[veterans_military_status] [varchar](50) NULL,
	[servicing_provider_QNTX_ID] [varchar](50) NULL,
	[servicing_provider_ID] [varchar](50) NULL,
	[servicing_provider_NPI] [varchar](50) NULL,
	[servicing_provider_type] [varchar](50) NULL,
	[servicing_provider_type_description] [varchar](300) NULL,
	[servicing_provider_last_name] [varchar](50) NULL,
	[servicing_provider_first_name] [varchar](50) NULL,
	[servicing_provider_phone] [varchar](50) NULL,
	[servicing_provider_address] [varchar](50) NULL,
	[servicing_provider_city] [varchar](50) NULL,
	[servicing_provider_state] [varchar](50) NULL,
	[servicing_provider_zip] [varchar](50) NULL,
	[encounter_date] [varchar](50) NULL,
	[date_of_service_end] [varchar](50) NULL,
	[date_of_service_start] [varchar](50) NULL,
	[coding_system] [varchar](50) NULL,
	[code] [varchar](50) NULL,
	[lab_test_desc] [varchar](500) NULL,
	[lab_results] [varchar](50) NULL,
	[lab_results_units] [varchar](50) NULL,
	[lab_text_value] [varchar](50) NULL
)  
GO


