 

Declare @FileName varchar(50)=  'c:\CCD_AthenaHealth_2018-12-14.17.40.16.txt';
exec [dbo].[uspCCD_AthenaHealth] @FileName

alter PROCEDURE [dbo].[uspCCD_AthenaHealth]
    @FileName  varchar(100) 
AS
BEGIN
    SET NOCOUNT ON;
truncate table [dbo].[TempCCD_AthenaHealth] ;
    IF Object_id('dbo.TempUpdate') IS NOT NULL 
      DROP TABLE dbo.tempupdate 

    CREATE TABLE dbo.tempupdate 
      ( 
         [carriermemid]         [VARCHAR](25) NOT NULL, 
         [memid]                [VARCHAR](25) NULL, 
         [member_last_name]     [VARCHAR](30) NULL, 
         [member_first_name]    [VARCHAR](30) NULL, 
         [member_middle_name]   [VARCHAR](10) NULL, 
         [member_date_of_birth] [VARCHAR](15) NULL, 
         [serviceplan]          [VARCHAR](4) NULL, 
         [updflag]              [CHAR](1) CONSTRAINT df_updflag DEFAULT 'N', 
         CONSTRAINT [pk_carriermemid_temp] PRIMARY KEY CLUSTERED ( 
         [carriermemid] 
         ASC )WITH (pad_index = OFF, statistics_norecompute = OFF, 
         ignore_dup_key = 
         OFF, allow_row_locks = on, allow_page_locks = on) ON [PRIMARY] 
      ) ;


 
DECLARE @sql NVARCHAR(300) = 'BULK INSERT [dbo].[TempCCD_AthenaHealth]  FROM ''' + @FileName + ''' WITH ( FIRSTROW = 2,  FIELDTERMINATOR =''|'', ROWTERMINATOR =''\n'' , TABLOCK )';
EXEC(@sql); 

-- INSERT INTO [dbo].[TempUpdate]([carriermemid] ,[member_last_name],[member_first_name] ,[member_middle_name],[member_date_of_birth] ) 
--select   ISNULL([carrier_member_ID],'') , isnull([member_last_name],'') , isnull([member_first_name],'') ,  isnull([member_middle_name],'') , isnull([member_date_of_birth],'') 
--from [dbo].[TempCCD_AthenaHealth] a WHERE   [carrier_member_ID]  IS NOT NULL  and carrier_member_ID  ='00802257575' 
----group by  ISNULL([carrier_member_ID],'')  , [member_first_name] , [member_last_name],[member_middle_name], [member_date_of_birth]  

    INSERT INTO dbo.tempupdate 
                ([carriermemid], 
                 [member_last_name], 
                 [member_first_name], 
                 [member_middle_name], 
                 [member_date_of_birth]) 
    SELECT [carrier_member_id], 
           lastname, 
           firstname, 
           middlename, 
           dob 
    FROM   (SELECT [carrier_member_id], 
                   Isnull([member_last_name], '')     AS lastname, 
                   Isnull([member_first_name], '')    AS firstname, 
                   Isnull([member_middle_name], '')   AS middlename, 
                   Isnull([member_date_of_birth], '') AS DOB, 
                   Row_number() OVER( partition BY carrier_member_id  ORDER BY code ASC )  AS Row1 
            FROM   [dbo].[tempccd_athenahealth] a 
            WHERE  [carrier_member_id] IS NOT NULL) g 
    WHERE  row1 = 1; 

END; 




DECLARE @sqlCommand nvarchar(600),@PlanName varchar(4); 
DECLARE @tablename varchar(50)='dbo.SRVQNXTFLQA_CARRIERMEMREC_FL';
DECLARE @_INDEX int=CHARINDEX('_', @tablename ,25);
set @PlanName= REPLACE(substring(@tablename,@_INDEX+1,len(@tablename)-@_INDEX) ,'_','') ;  
select @PlanName ;

SET @sqlCommand = N'UPDATE   t1  SET   t1.memid = t2.memid,serviceplan= ''@X''  FROM   dbo.TempUpdate t1  INNER JOIN   @tablename   t2 
on  t1.carriermemid=t2.carriermemid where t1.memid is null';
--WHERE carriermemid = @carriermemid 

--EXECUTE sp_executesql @sqlCommand, N'@carriermemid nvarchar(25)', @carriermemid =@carriermemid
 SET @sqlCommand=REPLACE(@sqlCommand,'@X',@PlanName);
 SET @sqlCommand=REPLACE(@sqlCommand,'@tablename',@tablename);


 EXECUTE sp_executesql @sqlCommand

 -- PRINT @sqlCommand;
 --update dbo.TempUpdate set memid=null, serviceplan=null  
 --select * from  dbo.TempUpdate t1 where t1.memid is not null 
 