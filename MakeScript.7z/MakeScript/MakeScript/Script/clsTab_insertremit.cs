﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
   public  class clsTab_insertremit
    {
        public string  Remit1 = @"
----------------------------------------------------------------------------
PRINT 'Claim status to PEND ,If header status anything other than 'Open' or 'Pay', do not update'
----------------------------------------------------------------------------
select row_number() over (order by tem.claimid) as RowNumber,tem.*   
into   [BDU_Temp].[EDI].[@EXCEL_remit] 
from BDU_Temp.EDI.[@EXCEL]  tem 
  
insert into BDU_Temp.EDI.insertremit (environment, claimid, message, upflag_eob)
select '@QNXT', tem.claimid, remit_comment , 'x' 
from [BDU_Temp].[EDI].[@EXCEL_remit]  tem
join @QNXT..claim clm on  tem.claimid = clm.claimid
	left join @QNXT..claimexplain ce (nolock) on tem.claimid= ce.claimid
	where  clm.status in ('PAY', 'DENY')
AND (patindex ('%' + rtrim(remit_comment) + '%', ce.explanation) = 0
	or ce.claimid is NULL ) and tem.RowNumber between 1 and 11000 
";

  public string Remit_23 = @" 
select row_number() over (order by tem.claimid) as RowNumber,tem.*   
into   [BDU_Temp].[EDI].[@EXCEL_remit] 
from BDU_Temp.EDI.[@EXCEL]  tem 

insert into BDU_Temp.edi.insertremit(environment, claimid, message, upflag_eob)
select DISTINCT '@QNXT', tem.claimid, '23 - Payment adjusted because charges have been paid by another payer', 'x' 
from  [BDU_Temp].[edi].[@EXCEL_remit] tem
left join @QNXT..claimexplain ce (nolock) on tem.claimid = ce.claimid
where (patindex ('%23 - Payment%', ce.explanation) = 0
 or ce.claimid is NULL) and tem.RowNumber between 1 and 10000
";

 public string ExecuteRemit = @"
use BDU_Temp
exec dbo.usp_ADHOC_RemitAdditions_claimexplain '@QNXT'
use BDU_Temp
select count (1), upflag, createid
from BDU_Temp.EDI.insertremit r (nolock)
where createdate > getdate()-0.1
and environment = '@QNXT'
group by upflag, createid
";

    }
}
