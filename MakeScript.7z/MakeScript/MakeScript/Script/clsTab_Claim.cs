﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
 public class clsTab_Claim
{
 public string SetToOPEN_forPend_111 = @"
----------------------------------------------------------------------------
PRINT 'Update claim status  to OPEN of those overrode above '
----------------------------------------------------------------------------
-- Count
SELECT clm.status, COUNT(*), COUNT(DISTINCT clm.claimid)
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
join @QNXT..claimedit ce (NOLOCK) ON clm.claimid = ce.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND  ruleid in ('111') AND ce.status='PEND' 
GROUP BY clm.status

-- Backup
SELECT clm.*
INTO BDU_Temp.EDI.[@EXCEL_CLM]
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
join @QNXT..claimedit ce (NOLOCK) ON clm.claimid = ce.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND  ruleid in ('111') AND ce.status='PEND'

-- Update
UPDATE clm SET clm.status = 'OPEN'
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
join @QNXT..claimedit ce (NOLOCK) ON clm.claimid = ce.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND  ruleid in ('111') AND ce.status='PEND'

-- Verify
SELECT clm.status, COUNT(*), COUNT(DISTINCT clm.claimid)
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
join @QNXT..claimedit ce (NOLOCK) ON clm.claimid = ce.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
AND  ruleid in ('111') AND ce.status='PEND'
GROUP BY clm.status
";

        public string claimStatusToPEND = @"
----------------------------------------------------------------------------
PRINT 'Claim status to PEND' 
----------------------------------------------------------------------------
SELECT clm.status, COUNT(1), COUNT(DISTINCT clm.claimid)
FROM BDU_Temp.edi.[@EXCEL] tem  JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status

SELECT clm.* INTO BDU_Temp.edi.[@EXCEL_clm2]
FROM BDU_Temp.edi.[@EXCEL] tem  JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

UPDATE clm SET clm.status ='PEND'
FROM  @QNXT..claim clm (NOLOCK)  JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 

SELECT clm.status, COUNT(1), COUNT(DISTINCT clm.claimid)
FROM BDU_Temp.edi.[@EXCEL] tem  JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status
";

public string claimStatusToPEND_ifStatus = @"
-----------------------------------------------------------------------------------------------
PRINT 'Claim status to PEND ,If header status anything other than  Open  or  Pay , do not update'
-----------------------------------------------------------------------------------------------
SELECT clm.status, COUNT(1), COUNT(DISTINCT clm.claimid)
FROM BDU_Temp.edi.[@EXCEL] tem  JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status

SELECT clm.* INTO BDU_Temp.edi.[@EXCEL_clm3]
FROM BDU_Temp.edi.[@EXCEL] tem  JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND clm.status IN ('##','##')

UPDATE clm SET clm.status ='PEND'
FROM  @QNXT..claim clm (NOLOCK)  JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
AND clm.status IN ('##','##')

SELECT clm.status, COUNT(1), COUNT(DISTINCT clm.claimid)
FROM BDU_Temp.edi.[@EXCEL] tem  JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status
";

 public string claimStatusToOPEN = @"
----------------------------------------------------------------------------
PRINT 'Claim status to OPEN' 
----------------------------------------------------------------------------
SELECT clm.status, COUNT(1), COUNT(DISTINCT clm.claimid)
FROM BDU_Temp.edi.[@EXCEL] tem  JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status

SELECT clm.* INTO BDU_Temp.edi.[@EXCEL_CLM1]
FROM BDU_Temp.edi.[@EXCEL] tem  JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

UPDATE clm SET clm.status ='OPEN'
FROM  @QNXT..claim clm (NOLOCK)  JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 

SELECT clm.status, COUNT(1), COUNT(DISTINCT clm.claimid)
FROM  @QNXT..claim clm (NOLOCK)  JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status
";

 public string  StatusToOPEN_ISLTC = @"
----------------------------------------------------------------------------
PRINT 'Claim status to OPEN, isltc to N' 
----------------------------------------------------------------------------
SELECT clm.status,clm.isltc, COUNT(1), COUNT(DISTINCT clm.claimid)
FROM  @QNXT..claim clm (NOLOCK)  JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status,clm.isltc

SELECT clm.* INTO BDU_Temp.edi.[@EXCEL_CLM1]
FROM  @QNXT..claim clm (NOLOCK)  JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

UPDATE clm SET clm.status ='OPEN',clm.isltc = 'N'
FROM  @QNXT..claim clm (NOLOCK)  JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 

SELECT clm.status,clm.isltc, COUNT(1), COUNT(DISTINCT clm.claimid)
FROM  @QNXT..claim clm (NOLOCK)  JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status,clm.isltc
";


public string provid_affilationid = @"
----------------------------------------------------------------------------
PRINT 'Update claim status, provid and affilationid'
----------------------------------------------------------------------------
-- Backup
SELECT clm.*
INTO BDU_Temp.EDI.[@EXCEL_CLM3]
FROM @QNXT..claim clm (NOLOCK) 
JOIN BDU_Temp.EDI.[@EXCEL] tem ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
 
-- Update
UPDATE clm SET clm.status = 'OPEN', clm.provid = '##', clm.affiliationid = '##'
FROM @QNXT..claim clm (NOLOCK) JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

-- Verify
SELECT COUNT(*) as claimid, COUNT(DISTINCT clm.claimid) as disclaimid, clm.provid, clm.affiliationid, clm.status
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
GROUP BY clm.provid, clm.affiliationid, clm.status
";

 public string OPEN_eobreceived = @"
----------------------------------------------------------------------------
PRINT 'Claim status to OPEN and eobreceived'
----------------------------------------------------------------------------
select clm.status, clm.eobreceived, COUNT(1), COUNT(DISTINCT clm.claimid)
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
GROUP BY clm.status, clm.eobreceived

-- Backup
SELECT clm.* INTO BDU_Temp.EDI.[@EXCEL_CLM3]
FROM @QNXT..claim clm (NOLOCK) 
JOIN BDU_Temp.EDI.[@EXCEL] tem ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
 
-- Update
UPDATE clm SET clm.status = 'OPEN', clm.eobreceived  = 'Y'
FROM @QNXT..claim clm (NOLOCK) JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

-- Verify
select clm.status, clm.eobreceived, COUNT(1), COUNT(DISTINCT clm.claimid)
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
GROUP BY clm.status, clm.eobreceived
";
 public string OPEN_enrollid_isltc= @"
----------------------------------------------------------------------
PRINT '----Claim status to OPEN, enrollid to column and isltc to column'
----------------------------------------------------------------------
SELECT clm.status, clm.enrollid, COUNT(*), COUNT(DISTINCT clm.claimid)
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
GROUP BY clm.status, clm.enrollid 

SELECT clm.*
INTO BDU_Temp.EDI.[@EXCEL_CLM4]
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

UPDATE clm SET clm.status = 'OPEN', clm.enrollid = tem.enrollid,clm.isltc = tem.isltc
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

SELECT clm.status, clm.enrollid, COUNT(*), COUNT(DISTINCT clm.claimid)
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
GROUP BY clm.status, clm.enrollid 
";

public string OPEN_enrollid = @"
----------------------------------------------------------------------
PRINT '----Claim status to OPEN and enrollid to column'
----------------------------------------------------------------------
SELECT clm.status, clm.enrollid,COUNT(DISTINCT clm.claimid)
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status, clm.enrollid

SELECT clm.*
INTO BDU_Temp.EDI.[@EXCEL_CLM]
FROM @QNXT..claim clm (NOLOCK) 
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

UPDATE clm SET clm.status = 'OPEN', clm.enrollid = tem.enrollid
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

SELECT clm.status, clm.enrollid,COUNT(DISTINCT clm.claimid)
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status, clm.enrollid
";
    }
}
