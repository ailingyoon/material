﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
 
public static class clsMemo
{
public static string AddMemoNoNID_NoJoin = @" 
---------------------------------------------------------------
 PRINT 'claim memo does not exist, add a claim from excel'
 ------------------------------------------------------------- 
insert into [BDU_Temp].[EDI].insertmemo (environment, srcid, memoidQual, memotype, [message], source, [description])
select distinct '@QNXT', tem.claimid, 'C', 'WO'+substring('@WO',10,6),tem.excel_message,'claim', tem.excel_desc
from [BDU_Temp].[EDI].[@EXCEL]  tem  JOIN @QNXT..claim clm (NOLOCK) 
ON tem.claimid = clm.claimid ";

 public static string AddMemoNoNID_JoinExist = @" 
---------------------------------------------------------------
 PRINT 'claim memo does not exist, add a claim from excel'
 ------------------------------------------------------------- 
insert into [BDU_Temp].[EDI].insertmemo (environment, srcid, memoidQual, memotype, [message], source, [description])
select distinct '@QNXT', tem.claimid, 'C', 'WO'+substring('@WO',10,6),tem.excel_message,'claim', tem.excel_desc
from [BDU_Temp].[EDI].[@EXCEL]  tem  INNER JOIN  @QNXT..claim clm (NOLOCK) 
ON tem.claimid = clm.claimid 
left join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] em on tem.claimid = em.claimid
where    em.claimid is null  and  tem.claimid IS NOT NULL"; 

  public static string AddMemoWithNID_JoinExist = @"
---------------------------------------------------------------
 PRINT 'claim memo does not exist, add a claim from excel'
 -------------------------------------------------------------
Declare @varInfo2 varchar(40)= '< ' + CONVERT(varchar(10),GETDATE(),101) +STUFF(RIGHT(CONVERT(varchar(26),GETDATE(),109),15),7,7, ' ' )+' – N314740 > '; 
insert into [BDU_Temp].[EDI].insertmemo (environment, srcid, memoidQual, memotype, [message], source, [description])
select distinct '@QNXT', tem.claimid, 'C', 'WO'+substring('@WO',10,6),@varInfo2 + tem.excel_message,'claim', tem.excel_desc
from [BDU_Temp].[EDI].[@EXCEL]  tem  INNER JOIN  @QNXT..claim clm (NOLOCK) 
ON tem.claimid = clm.claimid 
left join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] em on tem.claimid = em.claimid
where    em.claimid is null  AND  tem.claimid IS NOT NULL
";

  public static string AddMemoWithNID_NoJoin = @"
---------------------------------------------------------------
 PRINT 'claim memo does not exist, add a claim from excel'
 -------------------------------------------------------------
Declare @varInfo2 varchar(40)= '< ' + CONVERT(varchar(10),GETDATE(),101) +STUFF(RIGHT(CONVERT(varchar(26),GETDATE(),109),15),7,7, ' ' )+' – N314740 > '; 
insert into [BDU_Temp].[EDI].insertmemo (environment, srcid, memoidQual, memotype, [message], source, [description])
select distinct '@QNXT', tem.claimid, 'C', 'WO'+substring('@WO',10,6),@varInfo2 + tem.excel_message,'claim', tem.excel_desc
from [BDU_Temp].[EDI].[@EXCEL]  tem  INNER JOIN @QNXT..claim clm (NOLOCK) 
ON tem.claimid = clm.claimid
";

public static string AddMemoWithNID_NoJoin_FixMessage = @"
---------------------------------------------------------------
 PRINT 'Insert memo  '
 -------------------------------------------------------------
Declare @varInfo2 varchar(40)= '< ' + CONVERT(varchar(10),GETDATE(),101) +STUFF(RIGHT(CONVERT(varchar(26),GETDATE(),109),15),7,7, ' ' )+' – N314740 > '; 
insert into [BDU_Temp].[EDI].insertmemo (environment, srcid, memoidQual, memotype, [message], source, [description])
select distinct '@QNXT', tem.claimid, 'C', 'WO'+substring('@WO',10,6),
@varInfo2 +'#ME','claim','#MO'
from [BDU_Temp].[EDI].[@EXCEL]  tem  JOIN @QNXT..claim clm (NOLOCK) 
ON tem.claimid = clm.claimid
";

 public static string ExecuteMemo = @"
USE BDU_TEMP
EXEC usp_insertmemo '@QNXT'

USE BDU_TEMP
SELECT COUNT (DISTINCT im.srcid), memoflag, createid
FROM  edi.insertmemo im(NOLOCK)
 JOIN BDU_TEMP.EDI.[@EXCEL] tem  ON tem.claimid= im.srcid
 WHERE createdate > GETDATE() - 0.1
 AND environment = '@QNXT'
 AND memotype = 'WO' + substring('@WO', 10, 6)
 GROUP BY memoflag, createid
"; 

 public static string TermMemo = @"
------------------------------------------------------
PRINT 'Terminate additional memos'
------------------------------------------------------
SELECT m.*  
INTO  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos_term]
FROM  @QNXT..memo m (NOLOCK)
JOIN [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem
ON m.memoid = tem.memoid 
WHERE CreatedOrder> 1

update m set termdate = getdate() 
from  @QNXT..memo m (nolock)
join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem on  m.memoid = tem.memoid
where  CreatedOrder> 1
";

 public static String TermAllMemo_WithoutExisting = @"
------------------------------------------------------
PRINT 'Terminate all memos'
------------------------------------------------------
SELECT a.* INTO BDU_Temp.EDI.[@EXCEL_m] 
FROM @QNXT..memo a (NOLOCK)
JOIN @QNXT..claimmemo b (NOLOCK) ON a.memoid =b.memoid
JOIN BDU_Temp.EDI.[@EXCEL] c 
ON b.claimid = c.claimid 
JOIN @QNXT..claim clm (NOLOCK) ON clm.claimid = c.claimid
--WHERE a.description LIKE '%C14%'  

UPDATE a SET termdate = getdate()
FROM @QNXT..memo a (NOLOCK)
JOIN @QNXT..claimmemo b (NOLOCK) ON a.memoid =b.memoid
JOIN BDU_Temp.EDI.[@EXCEL] c  ON b.claimid = c.claimid 
JOIN @QNXT..claim clm (NOLOCK) ON clm.claimid = c.claimid
--WHERE a.description LIKE '%C14%'
";



 public static string UpdateExistMemoWithNID = @"
------------------------------------------------------
PRINT 'Update existing memos'
------------------------------------------------------

select m.*,tem.*,  row_number() over (partition by cm.claimid order by m.createdate asc) as  CreatedOrder 
  into [BDU_Temp].[EDI].[@EXCEL_ExistingMemos]
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid =cm.memoid
join [BDU_Temp].[EDI].[@EXCEL] tem on cm.claimid = tem.claimid
where  m.termdate =CONVERT(smalldatetime,'2078-12-31 00:00:00')
--and ( m.[description] like 'B01%' or m.[description] like '##%' or m.[description] like '##%' )

select  m.* 
into [BDU_Temp].[EDI].[@EXCEL_memo]
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid =cm.memoid
join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem 
on cm.claimid = tem.claimid and m.memoid =tem.memoid
where CreatedOrder = 1

Declare @NIDInfo varchar(40)= '< ' + CONVERT(varchar(10),GETDATE(),101) +STUFF(RIGHT(CONVERT(varchar(26),GETDATE(),109),15),7,7, ' ' )+' – N314740 > '; 
update m set  m.description = tem.excel_desc +' ' + CAST(m.[description] as varchar(max)), 
m.message = @NIDInfo + tem.excel_message  +' '+  CAST(m.[message] as varchar(max))
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid =cm.memoid
join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem 
on cm.claimid = tem.claimid and m.memoid =tem.memoid
where CreatedOrder= 1
";

public static string UpdateExistMemoNoNID = @"
------------------------------------------------------
PRINT 'Update existing memos'
------------------------------------------------------
select m.*,tem.claimid, tem.excel_desc,tem.excel_message,  row_number() over (partition by cm.claimid order by m.createdate asc) as  CreatedOrder 
  into [BDU_Temp].[EDI].[@EXCEL_ExistingMemos]
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid =cm.memoid
join [BDU_Temp].[EDI].[@EXCEL] tem on cm.claimid = tem.claimid
where  m.termdate =CONVERT(smalldatetime,'2078-12-31 00:00:00')
--and ( m.[description] like 'B01%' or m.[description] like '##%' or m.[description] like '##%' )

select  m.* 
into [BDU_Temp].[EDI].[@EXCEL_memo]
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid =cm.memoid
join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem 
on cm.claimid = tem.claimid and m.memoid =tem.memoid
where CreatedOrder = 1
 
update m set  m.description = tem.excel_desc +' '+ CAST(m.[description] as varchar(max)), 
m.message =   tem.excel_message +' ' + CAST(m.[message] as varchar(max))
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid =cm.memoid
join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem 
on cm.claimid = tem.claimid and m.memoid =tem.memoid
where CreatedOrder= 1
";

  public static string UpdateExistMemoNoNID_forAllExistMemo = @"
------------------------------------------------------
PRINT 'Update existing memos'
------------------------------------------------------
select m.*,tem.claimid, tem.excel_desc,tem.excel_message, row_number() over (partition by cm.claimid order by m.createdate asc) as  CreatedOrder 
  into [BDU_Temp].[EDI].[@EXCEL_ExistingMemos]
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid =cm.memoid
join [BDU_Temp].[EDI].[@EXCEL] tem on cm.claimid = tem.claimid
where  m.termdate =CONVERT(smalldatetime,'2078-12-31 00:00:00')
and (m.description LIKE 'Memo%'
OR m.description LIKE 'B01%'
OR m.description LIKE 'B05%'
OR m.description LIKE 'B06%'
OR m.description LIKE 'C59%'
OR m.description LIKE 'C17%') 

select  m.* 
into [BDU_Temp].[EDI].[@EXCEL_memo]
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid =cm.memoid
join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem 
on cm.claimid = tem.claimid and m.memoid =tem.memoid
---where CreatedOrder = 1
 
update m set  m.description = tem.excel_desc +' '+ CAST(m.[description] as varchar(max)), 
m.message =   tem.excel_message +' ' + CAST(m.[message] as varchar(max))
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid =cm.memoid
join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem 
on cm.claimid = tem.claimid and m.memoid =tem.memoid
---where CreatedOrder= 1";

 public static string UpdateExistMemoHasNID_forAllExistMemo = @"
------------------------------------------------------
PRINT 'Update existing memos'
------------------------------------------------------
select m.*,tem.claimid, tem.excel_desc,tem.excel_message, row_number() over (partition by cm.claimid order by m.createdate asc) as  CreatedOrder 
  into [BDU_Temp].[EDI].[@EXCEL_ExistingMemos]
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid =cm.memoid
join [BDU_Temp].[EDI].[@EXCEL] tem on cm.claimid = tem.claimid
where  m.termdate =CONVERT(smalldatetime,'2078-12-31 00:00:00')
and (m.description LIKE 'Memo%'
OR m.description LIKE 'B01%'
OR m.description LIKE 'B05%'
OR m.description LIKE 'B06%'
OR m.description LIKE 'C59%'
OR m.description LIKE 'C17%') 

select  m.* 
into [BDU_Temp].[EDI].[@EXCEL_memo]
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid =cm.memoid
join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem 
on cm.claimid = tem.claimid and m.memoid =tem.memoid
---where CreatedOrder = 1
 
Declare @NIDInfo varchar(40)= '< ' +CONVERT(varchar(10),GETDATE(),101) +STUFF(RIGHT(CONVERT(varchar(26),GETDATE(),109),15),7,7,' ')+' – N314740 > '; 
update m set  m.description = tem.excel_desc +' '+ CAST(m.[description] as varchar(max)), 
m.message =  @NIDInfo + tem.excel_message  +' '+  CAST(m.[message] as varchar(max))
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid =cm.memoid
join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem 
on cm.claimid = tem.claimid and m.memoid =tem.memoid
---where CreatedOrder= 1";


    }

}
