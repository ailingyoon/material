﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
    public class clsTab_claimeditmessage
    {
 public string Remit226_N705_N202= @"
Declare @Id int=1,  @count int ;
create table #temp1 ( id int identity(1,1) primary key,	messagetype varchar(10) default ('remit'),	messageid varchar(10),	overridemessage varchar(max))

insert  into #temp1(messageid)  select '226' union select 'N705' union select 'N202'

update p  set overridemessage= r.reporttext
from  #temp1 as p   join  @QNXT..rulereason r
on p.messageid=r.reasonid and p.messagetype=r.reasontype 
select @count =count(1) from #temp1
 
While (@Id<= @count)  
Begin
	DECLARE @overridemessage VARCHAR(MAX)
	DECLARE @messageid VARCHAR(10) 
    Select  @overridemessage= overridemessage, @messageid=messageid  From #temp1  Where id=@Id;  
	INSERT INTO [@QNXT].[dbo].[claimeditmessage]
           ([claimid] ,[claimline],[ruleid],[messageid],[messagetype],[overridemessage])
	SELECT DISTINCT [claimid], '0', '915', @messageid,'remit', @overridemessage 
	FROM BDU_TEMP.edi.[@EXCEL]  t join  @QNXT..claim clm on t.claimid=clm.claimid 
	WHERE (t.claimid + cast(@messageid as varchar)) NOT IN
	(
		SELECT cem.claimid + cast( @messageid as varchar) 	FROM BDU_TEMP.edi.[@EXCEL] tem
		JOIN [@QNXT].[dbo].[claimeditmessage] cem 	ON tem.claimid = cem.claimid
		WHERE cem.messageid = @messageid
	)

	SET @Id=@Id+1; 
End
";

    }
}
