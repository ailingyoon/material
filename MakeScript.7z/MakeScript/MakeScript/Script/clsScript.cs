﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
    public static class clsScript
    {

public static string cString = @"
USE @QNXT

 ------ insert deny 915 claim EDITs------- 
select ce.status, Count(*),ce.reason
from @QNXT..claimedit ce (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid = ce.claimid and  tem.claimline = ce.claimline		
join @QNXT..claim clm (nolock) on clm.claimid = tem.claimid
where ruleid in ( '915') and clm.status not in ('PAID','DENIED','VOID', 'REVERSED')  
group by ce.status, ce.reason

select ce.*  
into  [BDU_Temp].[EDI].[@EXCEL_ce]
from @QNXT..claimedit ce (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid = ce.claimid and  tem.claimline = ce.claimline		
join @QNXT..claim clm (nolock) on clm.claimid = tem.claimid
where ruleid in ( '915') and clm.status not in ('PAID','DENIED','VOID', 'REVERSED')  

update ce set status = 'DENY',clearby = 'PHX\EDIUser',cleardate = getdate(), state = 'MANUAL', reason = 'M119'
from @QNXT..claimedit ce (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid = ce.claimid and  tem.claimline = ce.claimline		
join @QNXT..claim clm (nolock) on clm.claimid = tem.claimid
where ruleid in ( '915') and clm.status not in ('PAID','DENIED','VOID', 'REVERSED')  

select ce.status, Count(*),ce.reason
from @QNXT..claimedit ce (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid = ce.claimid and  tem.claimline = ce.claimline		
join @QNXT..claim clm (nolock) on clm.claimid = tem.claimid
where ruleid in ( '915') and clm.status not in ('PAID','DENIED','VOID', 'REVERSED')  
group by ce.status, ce.reason


insert into @QNXT..claimedit (claimid, claimline, ruleid, status, reason,state)
select distinct tem.claimid, tem.claimline,'915','DENY','M119', 'MANUAL' 
from @QNXT..claimedit ce (nolock)
right join [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid = ce.claimid and  tem.claimline = ce.claimline 
and  ruleid in ( '915') and ce.status = 'DENY' and ce.reason = 'M119'
join @QNXT..claim clm (nolock) on clm.claimid = tem.claimid
where  ce.claimid is null and ce.claimline is  null  
and clm.status not in ('PAID','DENIED','VOID', 'REVERSED')  
-- and tem.claimline is not null

------ Okay the claim EDITs----OR below description---
PRINT 'Okay edit where rule id = 913'

select ce.status, Count(*)
from @QNXT..claimedit ce (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline 
where ruleid in ( '913')  
group by ce.status

select ce.* 
into [BDU_Temp].[EDI].[@EXCEL_ce1]
from @QNXT..claimedit ce (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline 
where ruleid in ('913')  

update ce set ce.status = 'OKAY',ce.clearby = 'PHX\EDIUser',ce.cleardate = getdate(), ce.state = 'MANUAL'
from @QNXT..claimedit ce (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline 
where ruleid in ('913')  


select ce.status, Count(*)
from @QNXT..claimedit ce (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline 
where ruleid in ('913')  
group by ce.status

/*------------Delete Edit ---------------------*/

select ce.status,Count(*)
from @QNXT..claimedit ce (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid = ce.claimid
where ce.ruleid in ( '913')
group by ce.status

Select ce.* 
into  [BDU_Temp].[EDI].[@EXCEL_ce2]
from @QNXT..claimedit ce (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid = ce.claimid
where ce.ruleid in ( '913') 
group by ce.status, ce.ruleid

delete ce
from @QNXT..claimedit ce (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid = ce.claimid
where ce.ruleid in ( '913') 

/*------ Update clamipendhistory -------*/
select COUNT(1)
from @QNXT..claimpendhistory cph (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on cph.claimid = tem.claimid
join @QNXT..claimedit ce (nolock) on tem.claimid = ce.claimid 
where  cph.overrider = '' and ce.ruleid in ( '913')
--and ce.status='PEND'

select cph.* 
into [BDU_Temp].[EDI].[@EXCEL_cph]
from @QNXT..claimpendhistory cph (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on cph.claimid = tem.claimid
join @QNXT..claimedit ce (nolock) on tem.claimid = ce.claimid 
where  cph.overrider = '' and ce.ruleid in ( '913')
--and ce.status='PEND'

update cph set overrider = 'PHX\EDIUser', overridedate = getdate()
from @QNXT..claimpendhistory cph (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on cph.claimid = tem.claimid
join @QNXT..claimedit ce (nolock) on tem.claimid = ce.claimid 
where  cph.overrider = '' and ce.ruleid in ( '913')
--and ce.status='PEND' 

/*--------------Insert claimpendhistory -----------------*/

insert  @QNXT..claimpendhistory (claimid, pendreasonid, penddate)
select distinct b.claimid, 'C14', getdate()
from @QNXT..claim clm (nolock)
join [BDU_Temp].[EDI].[@EXCEL] b on clm.claimid = b.claimid
left join @QNXT..claimpendhistory cph on cph.claimid = b.claimid and cph.pendreasonid ='C14' 
where cph.claimid is null  

-------------------------Update existing memo---------------------------------- 

select m.*,tem.*,  row_number() over (partition by cm.claimid order by m.createdate asc) as  CreatedOrder 
  into [BDU_Temp].[EDI].[@EXCEL_ExistingMemos]
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid =cm.memoid
join [BDU_Temp].[EDI].[@EXCEL] tem on cm.claimid = tem.claimid
where  m.termdate =CONVERT(smalldatetime,'2078-12-31 00:00:00')
and ( m.[description] like 'B01%' or m.[description] like 'B05%' or m.[description] like 'B06%' )

select  m.* 
into [BDU_Temp].[EDI].[@EXCEL_memo]
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid =cm.memoid
join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem 
on cm.claimid = tem.claimid and m.memoid =tem.memoid
where CreatedOrder = 1

update m set  m.description = tem.excel_desc +' ' + CAST(m.[description] as varchar(max)), 
m.message = tem.excel_message + CAST(m.[message] as varchar(max))
-- select cm.claimid , m.*
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid =cm.memoid
join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem 
on cm.claimid = tem.claimid and m.memoid =tem.memoid
where CreatedOrder= 1


--------Terminate additional memos--------------------
SELECT  m.*  
INTO  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos_term]
FROM @QNXT..memo m (NOLOCK)
JOIN [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem
ON m.memoid =tem.memoid WHERE CreatedOrder> 1


update m set termdate = getdate()
from @QNXT..memo m (nolock)
join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem on  m.memoid =tem.memoid
where CreatedOrder> 1


/* ---------------- Terminate All Memo -------------- */

select distinct convert(varchar(400), a.[description]) as description 
		from @QNXT..memo a (nolock)
		join @QNXT..claimmemo b (nolock) on a.memoid =b.memoid
		join [BDU_Temp].[EDI].[@EXCEL] c on b.claimid = c.claimid
		join @QNXT..claim clm (nolock) on clm.claimid = c.claimid
		where a.description like '%C14%' 
		and c.claimid is not null
		and clm.status not in ('PAID','DENIED','VOID', 'REVERSED')  
		and a.termdate ='2078-12-31 00:00:00' 

select a.*  into  [BDU_Temp].[EDI].[@EXCEL_m] 
from @QNXT..memo a (nolock)
join @QNXT..claimmemo b (nolock) on a.memoid =b.memoid
join [BDU_Temp].[EDI].[@EXCEL] c on b.claimid = c.claimid 
		join @QNXT..claim clm (nolock) on clm.claimid = c.claimid
where a.description like '%C14%' 
and c.claimid is not null
and clm.status not in ('PAID','DENIED','VOID', 'REVERSED') 

update a set termdate = getdate()
from @QNXT..memo a (nolock)
join @QNXT..claimmemo b (nolock) on a.memoid =b.memoid
join [BDU_Temp].[EDI].[@EXCEL] c on b.claimid = c.claimid 
		join @QNXT..claim clm (nolock) on clm.claimid = c.claimid
where a.description like '%C14%' 
and c.claimid is not null
and clm.status not in ('PAID','DENIED','VOID', 'REVERSED') 


---------claim memo does not exist, add a memo  -----------------------------------
Declare @varInfo varchar(40)= '< ' + CONVERT(varchar(10),GETDATE(),101) +STUFF(RIGHT(CONVERT(varchar(26),GETDATE(),109),15),7,7, ' ' )+' – N314740 > '; 
INSERT INTO  [BDU_Temp].[EDI].insertmemo (source,environment, srcid, memoidQual, memotype, [message],[description]) 
SELECT DISTINCT 'claim','@QNXT',tem.claimid,'C','WO'+substring('@WO',10,6),
@varInfo + '@MESSAGE', 
'@DESCRIPTION'
FROM [BDU_Temp].[EDI].[@EXCEL] (NOLOCK) tem
LEFT JOIN [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] em ON tem.claimid = em.claimid
WHERE em.claimid IS NULL

 
--------claim memo does not exist, add a claim from excel--------------------
insert into [BDU_Temp].[EDI].insertmemo (environment, srcid, memoidQual, memotype, [message], source, [description])
select distinct '@QNXT', tem.claimid, 'C', 'WO'+substring('@WO',10,6), tem.excel_message,'claim', tem.excel_desc 
from [BDU_Temp].[EDI].[@EXCEL] tem
left join [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] em on tem.claimid = em.claimid
where  em.claimid is null


/*------------ Insert Memo ---------------*/
insert into [BDU_Temp].[EDI].insertmemo (source,environment,srcid,memoidQual,memotype,message, description)
select distinct 'claim','@QNXT', tem.claimid, 'C', 'smemo', 
'@MESSAGE',
'@DESCRIPTION'
from [BDU_Temp].[EDI].[@EXCEL] (nolock) tem
join @QNXT..claim clm (nolock) on clm.claimid = tem.claimid 
where clm.status not in ('PAID','DENIED','VOID', 'REVERSED') 
 
use BDU_Temp
exec usp_insertmemo '@QNXT'

 
select count(distinct srcid), memoflag, createid
from edi.insertmemo (nolock) 
join  [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid=edi.insertmemo.srcid
where createdate > getdate()-0.1
and environment = '@QNXT'
and memotype = 'WO'+substring('@WO',10,6)
group by memoflag, createid

/* ------------ Update Claim Status ---------*/
Declare @varStatus varchar(10)='OPEN' ;

select clm.status, Count(*), COUNT(distinct clm.claimid)
from @QNXT..claim clm (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on clm.claimid = tem.claimid
Where clm.status not in ('PAID','DENIED','VOID', 'REVERSED') 
group by clm.status

select clm.* into  [BDU_Temp].[EDI].[@EXCEL_CLM]
from @QNXT..claim clm (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on clm.claimid = tem.claimid
Where clm.status not in ('PAID','DENIED','VOID', 'REVERSED')

update clm set clm.status =@varStatus
from @QNXT..claim clm (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on clm.claimid = tem.claimid
Where clm.status not in ('PAID','DENIED','VOID', 'REVERSED') 

select clm.status, Count(*), COUNT(distinct clm.claimid)
from @QNXT..claim clm (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on clm.claimid = tem.claimid
Where clm.status not in ('PAID','DENIED','VOID', 'REVERSED') 
group by clm.status"; 

    }
}
