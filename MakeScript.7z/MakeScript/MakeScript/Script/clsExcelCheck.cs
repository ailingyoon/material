﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
    public static class clsExcelCheck
    {
public static string cExcelCheck = @"
print 'Validate Excel Data';
USE BDU_Temp 

DELETE FROM  [BDU_Temp].[EDI].[@EXCEL] where claimid is null or claimid='' ;

DELETE [BDU_Temp].[EDI].[@EXCEL]  
FROM   [BDU_Temp].[EDI].[@EXCEL] tem 
WHERE  EXISTS (SELECT c.claimid 
               FROM   @QNXT..claim c  (NOLOCK)
               where    tem.claimid = c.claimid
               and  c.status IN ('PAID','DENIED','VOID','REVERSED')) 

DELETE [BDU_Temp].[EDI].[@EXCEL]  FROM   [BDU_Temp].[EDI].[@EXCEL] tem 
WHERE  NOT EXISTS (SELECT c.claimid 
               FROM   @QNXT..claim c  (NOLOCK)
               WHERE  tem.claimid = c.claimid) 

Declare @Multi int,@disClaim int;
SELECT @Multi=COUNT(1), @disClaim=COUNT(DISTINCT claimid)  FROM [BDU_TEMP].[EDI].[@EXCEL]; 
if (@Multi>@disClaim)
begin
  select distinct *  into  #@WO  FROM [BDU_Temp].[EDI].[@EXCEL] 
   truncate table [BDU_Temp].[EDI].[@EXCEL]; 
   insert into [BDU_Temp].[EDI].[@EXCEL]   select *  FROM  #@WO;
end
print 'Row #:' + cast(@disClaim as varchar);

USE @QNXT

select  clm.status ,count(1) as claim_count
from  [BDU_Temp].[EDI].[@EXCEL] tem  join  @QNXT..claim  clm  (NOLOCK)
on tem.claimid=clm.claimid 
GROUP BY clm.status
---------------------------------------------------------------------
PRINT 'Initial Data Validation END'
---------------------------------------------------------------------
"; 

    }
}
