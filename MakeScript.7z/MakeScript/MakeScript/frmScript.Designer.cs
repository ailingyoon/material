﻿namespace MakeScript
{
    partial class frmScript
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.gvWrite = new System.Windows.Forms.DataGridView();
            this.txtComp2 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.DG2 = new System.Windows.Forms.DataGridView();
            this.DG1 = new System.Windows.Forms.DataGridView();
            this.check1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.chkExcelInit = new System.Windows.Forms.CheckBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.com = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnOnHand = new System.Windows.Forms.Button();
            this.btnGet = new System.Windows.Forms.Button();
            this.btnWrite = new System.Windows.Forms.Button();
            this.txtBoxWO = new System.Windows.Forms.TextBox();
            this.btnOpen2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gvWrite)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DG2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DG1)).BeginInit();
            this.SuspendLayout();
            // 
            // gvWrite
            // 
            this.gvWrite.AllowUserToAddRows = false;
            this.gvWrite.AllowUserToDeleteRows = false;
            this.gvWrite.BackgroundColor = System.Drawing.Color.LightYellow;
            this.gvWrite.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvWrite.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.gvWrite.Location = new System.Drawing.Point(0, 573);
            this.gvWrite.Name = "gvWrite";
            this.gvWrite.RowTemplate.Height = 24;
            this.gvWrite.Size = new System.Drawing.Size(1019, 123);
            this.gvWrite.TabIndex = 17;
            this.gvWrite.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvWrite_CellContentClick);
            // 
            // txtComp2
            // 
            this.txtComp2.Font = new System.Drawing.Font("SimSun", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtComp2.Location = new System.Drawing.Point(0, 346);
            this.txtComp2.Multiline = true;
            this.txtComp2.Name = "txtComp2";
            this.txtComp2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtComp2.Size = new System.Drawing.Size(1012, 221);
            this.txtComp2.TabIndex = 18;
            this.txtComp2.TextChanged += new System.EventHandler(this.txtWOdetail_TextChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.DG2);
            this.panel2.Controls.Add(this.DG1);
            this.panel2.Location = new System.Drawing.Point(0, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(732, 337);
            this.panel2.TabIndex = 20;
            // 
            // DG2
            // 
            this.DG2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DG2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DG2.Location = new System.Drawing.Point(0, 167);
            this.DG2.Name = "DG2";
            this.DG2.Size = new System.Drawing.Size(732, 170);
            this.DG2.TabIndex = 1;
            // 
            // DG1
            // 
            this.DG1.AllowUserToAddRows = false;
            this.DG1.AllowUserToDeleteRows = false;
            this.DG1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DG1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.check1});
            this.DG1.Dock = System.Windows.Forms.DockStyle.Top;
            this.DG1.Location = new System.Drawing.Point(0, 0);
            this.DG1.Name = "DG1";
            this.DG1.Size = new System.Drawing.Size(732, 161);
            this.DG1.TabIndex = 0;
            // 
            // check1
            // 
            this.check1.HeaderText = "Sel";
            this.check1.Name = "check1";
            this.check1.Width = 35;
            // 
            // chkExcelInit
            // 
            this.chkExcelInit.AutoSize = true;
            this.chkExcelInit.Checked = true;
            this.chkExcelInit.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkExcelInit.Location = new System.Drawing.Point(748, 12);
            this.chkExcelInit.Name = "chkExcelInit";
            this.chkExcelInit.Size = new System.Drawing.Size(80, 17);
            this.chkExcelInit.TabIndex = 2;
            this.chkExcelInit.Text = "DataCheck";
            this.chkExcelInit.UseVisualStyleBackColor = true;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(945, 5);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(67, 37);
            this.btnClose.TabIndex = 21;
            this.btnClose.Text = "close";
            this.btnClose.UseVisualStyleBackColor = false;
            // 
            // com
            // 
            this.com.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.com.FormattingEnabled = true;
            this.com.Location = new System.Drawing.Point(738, 76);
            this.com.Name = "com";
            this.com.Size = new System.Drawing.Size(205, 24);
            this.com.TabIndex = 22;
            this.com.SelectedIndexChanged += new System.EventHandler(this.com_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(837, 123);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 26);
            this.button1.TabIndex = 23;
            this.button1.Text = "Clear DG2";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnOnHand
            // 
            this.btnOnHand.Location = new System.Drawing.Point(748, 123);
            this.btnOnHand.Name = "btnOnHand";
            this.btnOnHand.Size = new System.Drawing.Size(61, 41);
            this.btnOnHand.TabIndex = 24;
            this.btnOnHand.Text = "OnHand";
            this.btnOnHand.UseVisualStyleBackColor = true;
            this.btnOnHand.Click += new System.EventHandler(this.btnOnHand_Click);
            // 
            // btnGet
            // 
            this.btnGet.Location = new System.Drawing.Point(748, 179);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(75, 35);
            this.btnGet.TabIndex = 25;
            this.btnGet.Text = "取值";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // btnWrite
            // 
            this.btnWrite.Location = new System.Drawing.Point(844, 179);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(75, 35);
            this.btnWrite.TabIndex = 26;
            this.btnWrite.Text = "Write";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // txtBoxWO
            // 
            this.txtBoxWO.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxWO.Location = new System.Drawing.Point(738, 35);
            this.txtBoxWO.Name = "txtBoxWO";
            this.txtBoxWO.Size = new System.Drawing.Size(205, 24);
            this.txtBoxWO.TabIndex = 27;
            // 
            // btnOpen2
            // 
            this.btnOpen2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnOpen2.Location = new System.Drawing.Point(757, 238);
            this.btnOpen2.Name = "btnOpen2";
            this.btnOpen2.Size = new System.Drawing.Size(80, 36);
            this.btnOpen2.TabIndex = 28;
            this.btnOpen2.Text = "Form 2";
            this.btnOpen2.UseVisualStyleBackColor = false;
            this.btnOpen2.Click += new System.EventHandler(this.btnOpen2_Click);
            // 
            // frmScript
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1019, 696);
            this.Controls.Add(this.btnOpen2);
            this.Controls.Add(this.txtBoxWO);
            this.Controls.Add(this.btnWrite);
            this.Controls.Add(this.btnGet);
            this.Controls.Add(this.btnOnHand);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.chkExcelInit);
            this.Controls.Add(this.com);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txtComp2);
            this.Controls.Add(this.gvWrite);
            this.Name = "frmScript";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmScript_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gvWrite)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DG2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DG1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView gvWrite;
        private System.Windows.Forms.TextBox txtComp2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox chkExcelInit;
        private System.Windows.Forms.DataGridView DG2;
        private System.Windows.Forms.DataGridView DG1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ComboBox com;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn check1;
        private System.Windows.Forms.Button btnOnHand;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.TextBox txtBoxWO;
        private System.Windows.Forms.Button btnOpen2;
    }
}

