﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
 

namespace Utilities
{
    public enum LogType
    {
         
        Trace, 
        Warning, 
        Error, 
        SQL
    }
   
    public static class LogUtility
    {
        private static readonly Thread LogThread;
        private static readonly ConcurrentQueue<string> LogQueue; //自定义线程安全的Queue
        private static readonly object SyncRoot;
        private static readonly string FilePath;
        public static string LogWO;

        /// <summary>
        /// 因为线程是死循环读取队列,在没有日志数据的时候可能会消耗不必要的资源,所有当队列没有数据的时候用该类控制线程的(继续和暂停)
        /// </summary>
        private static readonly AutoResetEvent AutoReset = null;


        static LogUtility()
        {
            AutoReset = new AutoResetEvent(false);
            SyncRoot = new object();
            //FilePath = AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "Log\\";
            FilePath = @"C:\Users\n314740\Downloads\LogExcel\";
            LogThread = new Thread(WriteLog);
            LogQueue = new ConcurrentQueue<string>();
            LogThread.Start();
        }


        /// <summary>
        /// 记录日志
        /// </summary>
        /// <param name="msg">日志内容</param>
        public static void Log(string msg)
        {
            //string _msg = string.Format("{0}:{2}", DateTime.Now.ToString("HH:mm:ss"), msg);
            LogQueue.Enqueue(msg);
            AutoReset.Set();
        }


        /// <summary>
        /// 记录日志
        /// </summary>
        /// <param name="msg">日志内容</param>
        /// <param name="type">日志类型</param>
        public static void Log(string msg, LogType type,  string WO="")
        {
            string _msg = "";
           
            if (type==LogType.SQL)
            {
                _msg =  msg ;
                LogWO = WO;
                string _path = string.Format("{0}{1}.sql", FilePath, LogWO);
                if (CreateFile(_path))
                    ProcessWriteLog(_path, _msg); //写入日志到文本 

            } else 
            {
                 _msg = string.Format("{0} {1}: {2}", DateTime.Now.ToString("HH:mm:ss"), type, msg);
                LogWO = "";
                LogQueue.Enqueue(msg);
                AutoReset.Set();
            } 
        }


        /// <summary>
        /// 记录日志
        /// </summary>
        /// <param name="ex">异常</param>
        public static void Log(Exception ex)
        {
            if (ex != null)
            {
                string _newLine = string.Empty; //Environment.NewLine;
                StringBuilder _builder = new StringBuilder();
                _builder.AppendFormat("{0}: {1}{2}", DateTime.Now.ToString("HH:mm:ss"), ex.Message, _newLine);
                _builder.AppendFormat("{0}{1}", ex.GetType(), _newLine);
                _builder.AppendFormat("{0}{1}", ex.Source, _newLine);
                _builder.AppendFormat("{0}{1}", ex.TargetSite, _newLine);
                _builder.AppendFormat("{0}{1}", ex.StackTrace, _newLine);
                LogQueue.Enqueue(_builder.ToString());
                AutoReset.Set();
            }
        }


        /// <summary>
        /// 写入日志
        /// </summary>
        private static void WriteLog()
        {
            StringBuilder strBuilder = new StringBuilder();
            while (true)
            {
                if (LogQueue.Count() > 0)
                {
                    string _msg;
                    //Console.WriteLine(DateTime.Now.ToString("yyyyMMddhhmmssfff") + "---正在写入");
                    LogQueue.TryDequeue(out _msg);
                    if (!string.IsNullOrWhiteSpace(_msg))
                    {
                        //字符串拼接
                        strBuilder.Append(_msg).AppendLine();
                    }
                }
                else
                {
                    if (!string.IsNullOrWhiteSpace(strBuilder.ToString()))
                    {
                        //Console.WriteLine(DateTime.Now.ToString("yyyyMMddhhmmssfff") + "---Start Append");
                        System.Threading.Monitor.Enter(SyncRoot);
                        string _path;
                        if (!CreateDirectory()) continue;
                        if  (LogWO =="")
                        {
                             _path = string.Format("{0}{1}.txt", FilePath, DateTime.Now.ToString("hhmmss"));
                        } else
                        {
                             _path = string.Format("{0}{1}.sql", FilePath, LogWO);
                         
                        }
                       
                        Monitor.Exit(SyncRoot);
                        lock (SyncRoot)
                        {
                            if (CreateFile(_path))
                                ProcessWriteLog(_path, strBuilder.ToString()); //写入日志到文本
                        }
                        strBuilder.Clear();
                        //Console.WriteLine(DateTime.Now.ToString("yyyyMMddhhmmssfff") + "---写入完毕");
                    }
                    
                    //在这里,线程会被暂停,直到收到信号;
                    AutoReset.WaitOne();
                    
                }
            }
        }


        /// <summary>
        /// 写入文件
        /// </summary>
        /// <param name="path">文件路径返回文件名</param>
        /// <param name="msg">写入内容</param>
        private static void ProcessWriteLog(string path, string msg)
        {
            try
            {
                StreamWriter _sw = File.AppendText(path);
                //_sw.BaseStream.Seek(1, SeekOrigin.Current);
                _sw.WriteLine(msg);
                _sw.Flush();
                _sw.Close();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(string.Format("写入日志失败，原因:{0}", ex.Message));
            }
        }


        /// <summary>
        /// 创建文件
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        private static bool CreateFile(string path)
        {
            bool _result = true;
            try
            {
                if (!File.Exists(path))
                {
                    FileStream _files = File.Create(path);
                    _files.Close();
                } 
            }
            catch (Exception)
            {
                _result = false;
            }
            return _result;
        }


        /// <summary>
        /// 创建文件夹
        /// </summary>
        /// <returns></returns>
        private static bool CreateDirectory()
        {
            bool _result = true;
            try
            {
                if (!Directory.Exists(FilePath))
                {
                    Directory.CreateDirectory(FilePath);
                }
            }
            catch (Exception)
            {
                _result = false;
            }
            return _result;
        }


    }
}
