﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;
using System.IO;
using Utilities;
using BDUScript;

namespace MakeScript
{
    public partial class frmScript : Form
    {
        clsWO obj;
        IniFile iniFile = new IniFile("CONFIG.ini");
        public frmScript()
        {
            InitializeComponent();
        }

        private void frmScript_Load(object sender, EventArgs e)
        {
            FillOptToCom();
            //DG1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        
        }
        private void FillOptToCom()
        {
            com.Items.Add("MEMO");
            com.Items.Add("ClaimEdit");
            //com.Items.Add("ClaimDetail");
            com.Items.Add("Claim");
            //com.Items.Add("ClaimeditMessage");
            com.Items.Add("claimPendHistory");
            com.Items.Add("ClaimDetail");
            //com.Items.Add("Remit");
            //com.Items.Add("ClaimAttribute");
            //com.Items.Add("claimcond");

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

 
        private void Bind(string DTNAME)
        {
            //模拟数据：
            DataTable dt1 = new DataTable();//  
            //dt1.Columns.Add("Sel", typeof(string));
            dt1.Columns.Add("ID", typeof(string));
            dt1.Columns.Add("Description", typeof(string));
            dt1.Columns.Add("script", typeof(string));

            dt1.Rows.Add("1", "天一", "女");
            dt1.Rows.Add("2", "牛二", "男");
            dt1.Rows.Add("3", "张三", "男");
            dt1.Rows.Add("4", "李四", "女");
            dt1.Rows.Add("5", "王五", "男");
            dt1.Rows.Add("6", "赵六", "男");
          
            DG1.DataSource = dt1; 
           
        }
        private  DataTable TClaim()
        {
            //模拟数据：
            DataTable dt1 = new DataTable(); 
            dt1.Columns.Add("ID", typeof(string));
            dt1.Columns.Add("Description", typeof(string));
            dt1.Columns.Add("script", typeof(string));
            clsTab_Claim  T = new clsTab_Claim();
            dt1.Rows.Add("1", "SET to OPEN", T.claimStatusToOPEN);
            dt1.Rows.Add("2", "SET to PEND", T.claimStatusToPEND);
            dt1.Rows.Add("3", "SET to PEND, where  status IN ('##','##')", T.claimStatusToPEND_ifStatus);
            dt1.Rows.Add("4", "SET to OPEN, where ruleid=111 and status=PEND", T.SetToOPEN_forPend_111);            
            dt1.Rows.Add("5", "SET to OPEN, isltc = 'N' ", T.StatusToOPEN_ISLTC);
            dt1.Rows.Add("6", "SET to OPEN, provid = '##',affiliationid = '##'", T.provid_affilationid);
            dt1.Rows.Add("7", "SET to OPEN, eobreceived  = 'Y'", T.OPEN_eobreceived);
            dt1.Rows.Add("8", "SET to OPEN, enrollid  from excel", T.OPEN_enrollid);
            dt1.Rows.Add("9", "SET to OPEN, enrollid , isltc from excel", T.OPEN_enrollid_isltc);
            return dt1;
           
        }
        private DataTable TClaimEdit()
        {
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("ID", typeof(string));
            dt1.Columns.Add("Description", typeof(string));
            dt1.Columns.Add("script", typeof(string));
            clsTab_Claimedit T = new clsTab_Claimedit();
            
            dt1.Rows.Add("1", "OKAY_EDIT, where ruleid in ##", T.OKAY_EDIT);
            dt1.Rows.Add("2", "OKAY_EDIT, where ruleid=913", T.OKAY_EDIT_913);
            dt1.Rows.Add("3", "OKAY_EDIT, where ruleid=837", T.OKAY_EDIT_for837);
            dt1.Rows.Add("4", "OKAY_EDIT, where ruleid in ## and status=PEND", T.OKAY_EDIT_forPEND_Status);
            dt1.Rows.Add("5", "OKAY_EDIT, where claimline and ruleid  from excel", T.OKAY_EDIT_at_EXCEL_Ruleid_Claimline);
            dt1.Rows.Add("6", "H99_CLAIMS,ce.ruleid IN ('154','157','185','208','271','330','155')", T.H99_CLAIMS);
            dt1.Rows.Add("7", "SET to OKAY, where PEND and 111", T.OKAY_PEND_and111);
            dt1.Rows.Add("8", "INSERT & UPDATE Set to PEND,where 913 and claimline 0", T.PEND913_claimline_0);
            dt1.Rows.Add("9", "Clear  edits, where status=PEND and ruleid=913", T.ClearEdit_forPEND_913);
            dt1.Rows.Add("10", "Clear All Edit,where claimid from excel", T.ClearAllEdit);
            dt1.Rows.Add("11", "INSERT deny 915,where claimline from EXCEL", T.InsertDeny915);
            dt1.Rows.Add("12", "INSERT & UPDATE deny 915 ,reason=97 , where REVCODE", T.Deny915_Reason97_RevcodeNotLike);
            dt1.Rows.Add("13", "INSERT & UPDATE deny 915 ,reason=97 , where REVCODE also servcode", T.Deny915_Reason97_servcode_revcode);
        
            dt1.Rows.Add("14", "Update and insert primary reason FOR DSA", T.Update_primary_DSA);
            return dt1;
        }
        private DataTable TMemo()
        {
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("ID", typeof(string));
            dt1.Columns.Add("Description", typeof(string));
            dt1.Columns.Add("script", typeof(string));
            dt1.Rows.Add("1", "Insert FixMessage No Join Existing ", clsMemo.AddMemoWithNID_NoJoin_FixMessage + clsMemo.ExecuteMemo);
            dt1.Rows.Add("2", "Insert MEMO with NID,no Join,data from excel", clsMemo.AddMemoWithNID_NoJoin + clsMemo.ExecuteMemo);      
            dt1.Rows.Add("3", "Update ExistMemo has NID,where CreatedOrder = 1", clsMemo.UpdateExistMemoWithNID);     
            dt1.Rows.Add("4", "Update All ExistMemo,has NID, and description like", clsMemo.UpdateExistMemoHasNID_forAllExistMemo);
            dt1.Rows.Add("5", "Terminate additional memos", clsMemo.TermMemo);
            dt1.Rows.Add("6", "Term All Memo without Existing ", clsMemo.TermAllMemo_WithoutExisting);  
            dt1.Rows.Add("7", "Insert MEMO with NID, Join Exist ", clsMemo.AddMemoWithNID_JoinExist + clsMemo.ExecuteMemo);               
            dt1.Rows.Add("8", "ExecuteMemo", clsMemo.ExecuteMemo);
            return dt1;
        }

        private DataTable Tclaimpendhistory()
        {
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("ID", typeof(string));
            dt1.Columns.Add("Description", typeof(string));
            dt1.Columns.Add("script", typeof(string));
            clsTab_claimpendhistory T = new  clsTab_claimpendhistory();

            dt1.Rows.Add("1", "Pend claim to  ##  Pend Bucket,pendreasonid=##", T.Pend_claim_toSomething);
            dt1.Rows.Add("2", "Insert overrider,where claimline=0,pendreasonid=##", T.Rule913_claimline0_FixReasonid);
            dt1.Rows.Add("3", "Update overrider,where 913 and 0", T.overrider_913_claimline0_OnlyUpdate);
            dt1.Rows.Add("4", "Update and insert  overrider,where 913 and 0", T.overrider_913_claimline0);
            dt1.Rows.Add("5", "Update overrider,where 913 and PEND", T.Update_913_PEND);
            dt1.Rows.Add("6", "Update overrider,where 913 No ClaimLine", T.Update_913_NoStatus_Noclaimline);
            dt1.Rows.Add("7", "Update overrider,where ruleid in ##,pass ruleid", T.Update_PassRuleid);
 
            return dt1;
      
        }
        private DataTable TclaimDetail()
        {
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("ID", typeof(string));
            dt1.Columns.Add("Description", typeof(string));
            dt1.Columns.Add("script", typeof(string));
            clsTab_claimdetail T = new clsTab_claimdetail();
 
            dt1.Rows.Add("1", "claimdetail.payasprimary =  Y ", T.payasprimary);
            dt1.Rows.Add("2", "Update claim detail set manualcontractpriceamt and usemanualcontractprice", T.usemanualcontractprice);
         
            return dt1;

        }


        private void txtWOdetail_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void com_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Bind(this.com.Text);
            string commandName = this.com.Text;
            DataTable dt1 = null;
            switch (commandName)
            {
                case "Claim":                    
                   dt1= TClaim();
                    break;
                case "ClaimEdit":
                    dt1 = TClaimEdit();
                    break;
                case "MEMO":
                    dt1 = TMemo();
                    break;
                case "claimPendHistory":
                  dt1 = Tclaimpendhistory();
                    break;
                case "ClaimDetail":
                    dt1 = TclaimDetail();
                    break;
       
                default:
                    Console.WriteLine(String.Format("Unknown command: {0}", commandName));
                    break;
            }

            DG1.ClearSelection(); 
 
            if (dt1!=null)
            {
                //DG1.Rows.Clear();
                //DG1.Refresh();
                DG1.DataSource = null;
                DG1.DataSource = dt1;
                DataGridViewColumn column1 = DG1.Columns[1];
                DataGridViewColumn column2 = DG1.Columns[2];
                column2.Width = 550;
                column1.Width = 30;
            }
      
        }

        private void btnOnHand_Click(object sender, EventArgs e)
        {
            string sql = @" SELECT w.work_order_id,case when w.TransExcel =1 then 'YES' ELSE 'NO' END AS EXCEL ,w.datalog as plans,Summary as summ, detail 
   FROM   [EDI].[stgAuditLog] w   where   w.wantsta='YES' AND  w.worksta='PICK'  order by w.work_order_id";
 
            const string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
            //<br/>  --line break
            DataSet ds2 = Utilities.SqlHelper.ExecuteDataSet(connectionString, CommandType.Text, sql, null);
            if (ds2 != null && ds2.Tables.Count > 0)
            {
              
                   DataTable dt2 = ds2.Tables[0];
               
                    gvWrite.DataSource = null;
                    gvWrite.Rows.Clear();
                    gvWrite.Columns.Clear(); 
                    //<br/>  --line break

                    if (dt2 != null )
                    {
                        DataGridViewButtonColumn col = new DataGridViewButtonColumn();
                        gvWrite.DataSource = dt2;
                        col.HeaderText = "Click";
                        col.Width = 60;
                    
                         gvWrite.Columns.Insert(0, col);
                  
                       //gvWO.AutoResizeColumn(3);
                       gvWrite.Columns[4].Width = 500;
                       gvWrite.Columns[5].Visible = false; 
                       gvWrite.Columns[1].Width = 120;
                       gvWrite.Columns[2].Width = 50;
                       gvWrite.Columns[3].Width = 70;

                   }



            }
            ds2 = null;
        }

        private void gvWrite_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.ColumnIndex > 0) return;
            try
            {
                var senderGrid = (DataGridView)sender;

                if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
                {
                    //DataGridViewCheckBoxCell checkbox = (DataGridViewCheckBoxCell)gvWO.CurrentCell;
                    //bool isChecked = (bool)checkbox.EditedFormattedValue;
                    //int index = checkbox.RowIndex;
                    int index = e.RowIndex;
                    obj = new clsWO();

                    //if (isChecked)
                    //{
                    DataGridViewRow row = gvWrite.Rows[index];
                    //string message = row.Cells["summ"].Value.ToString();
                    obj.summary = row.Cells["summ"].Value.ToString();
                    string detail = row.Cells["detail"].Value.ToString();
                    obj.detail = detail;
                    string[] data = detail.Split('#');
                    string newDetail = "";
                    obj.WO = row.Cells["work_order_id"].Value.ToString();
                    obj.SUBMITDATE = DateTime.Now.ToString("yyyy-MM-dd");
                    obj.plans = row.Cells["plans"].Value.ToString();
                    this.txtBoxWO.Text = obj.WO;

                    if (detail.Trim().Length > 0)
                    {

                        newDetail = obj.WO + Environment.NewLine;

                        for (int d = 0; d < data.Length; d++)
                        {
                            if (data[d].Trim().Length > 0)
                                newDetail += data[d] + Environment.NewLine;
                        }
                       
                        this.txtComp2.Text = newDetail;
                    }
                    else
                    {
                        this.txtComp2.Text = "No data!" + obj.WO;

                    }


                    bool b = detail.Contains("VOID");
                    if (b)
                    {
                        int index2 = detail.IndexOf("VOID");
                        if (index2 >= 0)
                            MessageBox.Show("VOID begins at character position " + (index2 + 1).ToString());

                    }

                }


                //2019 - 02 - 01
            }
            catch (Exception)
            { 
                obj = null;
                throw;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DG2.Rows.Clear();
            DG2.DataSource = null;
        }

        private void btnGet_Click(object sender, EventArgs e)
        {

            if (DG1.DataSource != null && DG1.Rows.Count > 0)
            { 

                //DataTable dt1 = new DataTable();
                //dt1.Columns.Add("ID", typeof(string));
                //dt1.Columns.Add("Description", typeof(string));
                //dt1.Columns.Add("script", typeof(string));
                DG2.ColumnCount = 3;
                DG2.Columns[0].Name = "ID";
                DG2.Columns[1].Name = "Description";
                DG2.Columns[1].Width = 500;
                DG2.Columns[2].Name = "script";

                for (int i = 0; i < DG1.Rows.Count; i++)
                {
                    if (Convert.ToBoolean(DG1.Rows[i].Cells["check1"].Value))//获取选中的
                    {
                        //dt1.Rows.Add(DG1.Rows[i].Cells["ID"].Value.ToString(),
                        //            DG1.Rows[i].Cells["Description"].Value.ToString(),
                        //            DG1.Rows[i].Cells["script"].Value.ToString());


                      
                        string ID = DG1.Rows[i].Cells["ID"].Value.ToString();
                        string DESC = DG1.Rows[i].Cells["Description"].Value.ToString();
                        string strScript = DG1.Rows[i].Cells["script"].Value.ToString();
                        DG2.Rows.Add(ID,DESC,strScript);

                    }
                }
                
            }
        }
        private String GetQNXT(string HPID)
        {
            string qnxt = "";
            switch (HPID)
            {
                case "OH":
                    qnxt = "plandata_QNXT_OHIO";
                    break;
                case "TX":
                    qnxt = "plandata_QNXT_TXMS";
                    break;
                default:
                    qnxt = "plandata_QNXT_" + HPID.ToUpper().Trim();
                    break;
            }

            return qnxt;

        }
        private void PushToLog(string LogData, string QNXT, string TableName, string WO, string HPID)
        {
            string sData = LogData.Replace("@QNXT", QNXT).Replace("@EXCEL", TableName).Replace("@WO", WO);
            string strFileName = WO + "_XX_" + HPID;
            string FilePath = @"C:\Users\n314740\Downloads\LogExcel\" + strFileName + ".sql";
            if (File.Exists(FilePath)) File.Delete(FilePath);
            System.Threading.Thread.Sleep(300);
            LogUtility.Log(sData, LogType.SQL, strFileName);
        }

        private void btnWrite_Click(object sender, EventArgs e)
        { 
            string strDate = DateTime.Today.ToString("MMddyyyy");
            string HPID2 = obj.plans;
            string WO = obj.WO;
            string summary = obj.summary;
            string detail = obj.detail;

            string[] arr = new string[] { };
            var HPID_list = new List<string>();
            if (HPID2.Contains(","))
            {
                arr = HPID2.Split(',');
                foreach (string s in arr)
                {
                    if (s.Trim().Length > 0)
                        HPID_list.Add(s);
                }

            }
            else
            {
                HPID_list.Add(HPID2);
            }

            foreach (string HPID in HPID_list) // Loop through List with foreach
            {
                StringBuilder sb = new StringBuilder();
                string QNXTDB = GetQNXT(HPID);
                string PRODUCTION = iniFile.GetString("PRODUCTION", HPID, "");

                sb.AppendLine("----" + PRODUCTION);
                sb.AppendLine("/*");
                sb.AppendLine("WO#   : " + WO);
                sb.AppendLine("plans : " + HPID);
                sb.AppendLine("NID   : N314740");
                sb.AppendLine("Date  : " + DateTime.Now.ToString("yyyy-MM-dd"));
                sb.Append("Title :" + summary + Environment.NewLine);
                string[] data = detail.Split('#');

                sb.AppendLine("***Description :----------------------------------------------------------------");
                sb.AppendLine("");
                if (detail.Trim().Length > 0)
                {
                    for (int d = 0; d < data.Length; d++)
                    {
                        if (data[d].Trim().Length > 0)
                            sb.Append(data[d] + Environment.NewLine);
                    }
                }
                else
                {
                    sb.Append(detail + Environment.NewLine);
                }
                sb.AppendLine("***End Description  -----------------------------------------------------------");
                sb.AppendLine("*/");

                summary = summary.ToUpper();
                string strExcel = "N314740_" + WO + "_" + HPID + "_" + strDate;

             
                sb.Append(clsExcelCheck.cExcelCheck);
                for (int i = 0; i < (DG2.Rows.Count-1); i++)
                { 
                        string strScript = DG2.Rows[i].Cells[2].Value.ToString();                            
                        sb.Append(strScript); 
                }


            PushToLog(sb.ToString(), QNXTDB, strExcel, WO, HPID);
            sb = null;

    }
             
            GC.Collect();
            GC.WaitForPendingFinalizers();
            MessageBox.Show("Write completed !");
        }

        private void btnOpen2_Click(object sender, EventArgs e)
        {
           
            List<Form> forms = new List<Form>(); 
            foreach (Form f in Application.OpenForms)
            {
                if (f.Name == "Form2")
                {
                    f.Close();
                    break;
                }
            }

            Form2 nextForm = new Form2();
            this.Hide();
            nextForm.ShowDialog();
            this.Close();
 
        }
    }
}
